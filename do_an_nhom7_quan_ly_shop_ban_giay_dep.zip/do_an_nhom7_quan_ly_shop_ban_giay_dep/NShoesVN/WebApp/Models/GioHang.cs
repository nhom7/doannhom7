﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using WebApp.SanPhamServiceReference;

namespace WebApp.Models
{
    public class GioHang
    {
        private SanPhamServiceClient sanPham_Client = new SanPhamServiceClient();
        public GioHang(int maGiay)
        {
            SanPhamEntity item = sanPham_Client.LayMotSP(maGiay);
            idSP = item.id;
            tenSP = item.tenSP;
            giaNiemYet = item.giaNiemYet;
            giaGiam = item.giaGiam;
            hinhAnh = item.hinhAnh;
            soLuong = 1;
        }

        public int idSP { get; set; }
        public string tenSP { get; set; }
        public decimal giaNiemYet { get; set; }
        public decimal giaGiam { get; set; }
        public string hinhAnh { get; set; }
        public int soLuong { get; set; }

        public decimal tongTien { get { return (giaNiemYet - giaGiam) * soLuong; } }

    }
}