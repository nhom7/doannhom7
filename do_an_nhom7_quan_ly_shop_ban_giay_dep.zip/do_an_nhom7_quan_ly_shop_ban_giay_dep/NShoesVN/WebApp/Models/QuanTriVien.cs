﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApp.Models
{
    public class QuanTriVien
    {
        public string tenDN { get; set; }
        public string matKhau { get; set; }
    }
}