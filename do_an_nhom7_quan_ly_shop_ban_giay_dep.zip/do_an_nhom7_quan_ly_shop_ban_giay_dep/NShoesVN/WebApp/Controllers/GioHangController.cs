﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebApp.Models;
using WebApp.SanPhamServiceReference;
using WebApp.DonHangServiceReference;
using WebApp.KhachHangServiceReference;
using WebApp.CTDHServiceReference;
using System.Text.RegularExpressions;

namespace WebApp.Controllers
{
    public class GioHangController : Controller
    {
        private SanPhamServiceClient sanPham_Client = new SanPhamServiceClient();
        private DonHangServiceClient donHang_Client = new DonHangServiceClient();
        private KhachHangServiceClient khachHang_Client = new KhachHangServiceClient();
        private CTDHServiceClient cTDH_Client = new CTDHServiceClient();

        #region Gio Hang
        public ActionResult GioHang()
        {
            List<GioHang> lstGioHang = LayGioHang();
            ViewBag.TongTienDH = TongTien().ToString();
            return View(lstGioHang);
        }

        public List<GioHang> LayGioHang()
        {
            List<GioHang> lstGioHang = Session["giohang"] as List<GioHang>;
            if(lstGioHang == null)
            {
                lstGioHang = new List<GioHang>();
                Session["giohang"] = lstGioHang;
            }
            return lstGioHang;
        }

        public ActionResult ThemGioHang(int idSP, string strURL)
        {
            if(sanPham_Client.LayDSSP().ToList().Where(p=>p.id == idSP).FirstOrDefault() == null)
            {
                Response.StatusCode = 404;
                return null;
            }

            List<GioHang> lstGioHang = LayGioHang();
            GioHang giay = lstGioHang.Where(p => p.idSP == idSP).FirstOrDefault();
            if(giay == null)
            {
                giay = new GioHang(idSP);
                lstGioHang.Add(giay);
                return Redirect(strURL);
            }
            else
            {
                giay.soLuong++;
                return Redirect(strURL);
            }
        }

        public ActionResult CapNhatGioHang(int idSP, FormCollection f)
        {
            if (sanPham_Client.LayDSSP().ToList().Where(p => p.id == idSP).FirstOrDefault() == null)
            {
                Response.StatusCode = 404;
                return null;
            }

            List<GioHang> lstGioHang = LayGioHang();
            GioHang sanpham = lstGioHang.Where(p => p.idSP == idSP).FirstOrDefault();
            if(sanpham!=null)
            {
                if (f["txtSoLuong"].ToString() == "")
                {
                    return RedirectToAction("GioHang");
                }
                else
                {
                    sanpham.soLuong = int.Parse(f["txtSoLuong"].ToString());
                    lstGioHang.RemoveAll(p => p.idSP == idSP);
                    lstGioHang.Add(sanpham);
                }
            }
            return RedirectToAction("GioHang");
        }

        public ActionResult XoaGioHang(int idSP)
        {
            if(sanPham_Client.LayDSSP().ToList().Where(p=>p.id == idSP).FirstOrDefault() == null)
            {
                Response.StatusCode = 404;
                return null;
            }

            List<GioHang> lstGioHang = LayGioHang();
            GioHang sanpham = lstGioHang.Where(p => p.idSP == idSP).FirstOrDefault();
            if (sanpham != null)
            {
                lstGioHang.RemoveAll(p => p.idSP == idSP);
            }
            return RedirectToAction("GioHang");

        }

        private int TongSoLuong()
        {
            int sum = 0;
            List<GioHang> lstGioHang = Session["giohang"] as List<GioHang>;
            if(lstGioHang != null)
            {
                sum = lstGioHang.Sum(p => p.soLuong);
            }
            return sum;
        }
        private decimal TongTien()
        {
            decimal sum = 0;
            List<GioHang> lstGioHang = Session["giohang"] as List<GioHang>;
            if(lstGioHang != null)
            {
                sum = lstGioHang.Sum(p => p.tongTien);
            }
            return sum;
        }

        public ActionResult GioHangPartial()
        {
            if(TongSoLuong() == 0)
            {
                return PartialView("LogoPartial");
            }
            ViewBag.TongSoLuong = TongSoLuong();
            ViewBag.TongTien = TongTien();
            return PartialView("LogoPartial");
        }

        public ActionResult SuaGioHang()
        {
            if (Session["giohang"] == null)
            {
                return RedirectToAction("Index", "Home");
            }
            List<GioHang> lstGioHang = LayGioHang();
            return View(lstGioHang);
        }
        #endregion

        [HttpPost]
        public ActionResult DatHang()
        {
            if (Session["thongtinKH"] == null || Session["thongtinKH"].ToString() == "")
            {
                return RedirectToAction("DangKy");
            }
            if (Session["giohang"] == null)
            {
                RedirectToAction("Index", "Home");
            }
            DonHangEntity dh = new DonHangEntity();
            KhachHangEntity kh = (KhachHangEntity)Session["thongtinKH"];
            List<GioHang> gh = LayGioHang();
            dh.id = donHang_Client.SoLuong() + 1;
            dh.idKhachHang = kh.id;
            dh.ngayDH = DateTime.Now.Date;
            dh.idTrangThai = 1;
            dh.thanhTien = TongTien();
            dh.tenKH = khachHang_Client.LayTenKH(kh.id);
            donHang_Client.ThemDonHang(dh);
            foreach (var i in gh)
            {
                CTDHEntity item = new CTDHEntity()
                {
                    idDH = dh.id,
                    idSP = i.idSP,
                    soLuong = i.soLuong,
                    tenSanPham = i.tenSP,
                    giaNiemYet = i.giaNiemYet,
                    giaGiam = double.Parse(i.giaGiam.ToString())
                };
                cTDH_Client.ThemChiTiet(item);
            }
            Session["giohang"] = null;
            Session["thongtinKH"] = null;
            return RedirectToAction("Index", "Home");
        }

        public ActionResult ThanhCong()
        {
            if (Session["thongtinKH"] == null || Session["thongtinKH"].ToString() == "")
            {
                return RedirectToAction("DangKy");
            }
            DonHangEntity dh = new DonHangEntity();
            KhachHangEntity kh = (KhachHangEntity)Session["thongtinKH"];
            List<GioHang> gh = LayGioHang();
            dh.id = donHang_Client.SoLuong() + 1;
            dh.idKhachHang = kh.id;
            dh.ngayDH = DateTime.Now.Date;
            dh.idTrangThai = 1;
            dh.thanhTien = TongTien();
            dh.tenKH = khachHang_Client.LayTenKH(kh.id);
            donHang_Client.ThemDonHang(dh);
            foreach (var i in gh)
            {
                CTDHEntity item = new CTDHEntity()
                {
                    idDH = dh.id,
                    idSP = i.idSP,
                    soLuong = i.soLuong,
                    tenSanPham = i.tenSP,
                    giaNiemYet = i.giaNiemYet,
                    giaGiam = double.Parse(i.giaGiam.ToString())
                };
                cTDH_Client.ThemChiTiet(item);
            }
            Session["giohang"] = null;
            Session["thongtinKH"] = null;
            return View();
        }


        [HttpGet]
        public ActionResult DangKy()
        {
            return View();
        }

        [HttpPost]
        public ActionResult DangKy(KhachHangEntity kh)
        {
            if (ModelState.IsValid)
            {
                if (kh.tenKH == null)
                {
                    ViewBag.ketqua = "Tên Khách Hàng Không Được Để Trống!";
                    return View();

                }
                if (kh.sdt == null)
                {
                    ViewBag.ketqua = "Số Điện thoại không được để trống!";
                    return View();
                }
                if (!kiemtraSDT(kh.sdt))
                {
                    ViewBag.ketqua = "Kiểm tra lại sự hợp lệ của số điện thoại";
                    return View();
                }
                if (kh.email == null)
                {
                    ViewBag.ketqua = "Email không được để trống!";
                    return View();
                }
                if (!KiemTraEmail(kh.email))
                {
                    ViewBag.ketqua = "Email Không hợp lệ!";
                    return View();
                }
                if (kh.diaChi == null)
                {
                    ViewBag.ketqua = "Địa chỉ không được để trống!";
                    return View();
                }

                int idKH = khachHang_Client.SoLuongKH() + 1;
                kh.id = idKH;
                khachHang_Client.ThemKhachHang(kh);
                ViewBag.ketqua = "Chúc Mừng Bạn đã đăng ký thành công!";
                Session["thongtinKH"] = kh;
                return RedirectToAction("thanhcong");
            }
            ViewBag.ketqua = "Không Thành Công!";
            return View();
        }

        private bool kiemtraSDT(string sdt)
        {
            Char[] chuoi = sdt.ToArray();
            foreach (var i in chuoi)
            {
                if (!Char.IsNumber(i))
                {
                    return false;
                }
            }
            return true;
        }
        public static bool KiemTraEmail(string email)
        {
            string strRegex = @"^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}" +
         @"\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\" +
         @".)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$";
            Regex re = new Regex(strRegex);
            if (re.IsMatch(email))
                return (true);
            else
                return (false);
        }
    }
}