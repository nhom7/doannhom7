﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebApp.SanPhamServiceReference;
using PagedList.Mvc;
using PagedList;

namespace WebApp.Controllers
{
    public class TimKiemController : Controller
    {
        private SanPhamServiceClient sanPham_Client = new SanPhamServiceClient();
        //
        // GET: /TimKiem/
        public ActionResult KetQuaTimKiem(FormCollection f,int? page)
        {
            string tuKhoa = f["txtTimKiem"].ToString().Trim();
            List<SanPhamEntity> list = sanPham_Client.LayDSSP_TheoTen(tuKhoa).ToList();
            int pageSize = 12;
            int pageNumber = (page ?? 1);
            if(list.Count == 0)
            {
                ViewBag.TimThay = "Không tìm thấy sản phẩm nào!";
                return View(list.ToPagedList(pageNumber, pageSize));
            }
            ViewBag.TimThay = "Tìm Thấy " + list.Count.ToString() + " Sản phẩm";
            return View(list.ToPagedList(pageNumber, pageSize));
        }
	}
}