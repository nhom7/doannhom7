﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebApp.LoaiSanPhamServiceReference;
using WebApp.SanPhamServiceReference;
using WebApp;
using PagedList.Mvc;
using PagedList;

namespace WebApp.Controllers
{
    public class HomeController : Controller
    {
        private LoaiSanPhamServiceClient loaiSP_Client = new LoaiSanPhamServiceClient();
        private SanPhamServiceClient sanPham_Client = new SanPhamServiceClient();
        public ActionResult Index(int? page)
        {
            var list = sanPham_Client.LayDS_Moi().ToList();
            int pageSize = 16;
            int pageNumber = (page ?? 1);
            return View(list.ToPagedList(pageNumber,pageSize));
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }

        public ActionResult DanhMucSanPham()
        {
            var list = loaiSP_Client.LayDSLoaiSP().ToList();
            return PartialView("DanhMucSanPhamPartial",list);
        }

        public ActionResult SanPhamDatBiet()
        {
            var list = sanPham_Client.LayDS_DatBiet().ToList();
            return PartialView("DatBietPartial", list);
        }

        public ActionResult SanPhamKhuyenMai()
        {
            var list = sanPham_Client.LayDS_GiamGia().ToList();
            return PartialView("KhuyenMaiPartial", list);
        }
    }
}