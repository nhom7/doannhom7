﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.Mvc;
using WebApp;
using WebApp.KhachHangServiceReference;

namespace WebApp.Controllers
{
    public class KhachHangController : Controller
    {
        private KhachHangServiceClient khachHang_Client = new KhachHangServiceClient();
        //
        // GET: /KhachHang/
        public ActionResult Index()
        {
            return View();
        }

        [HttpGet]
        public ActionResult DangKy()
        {
            return View();
        }

        [HttpPost]
        public ActionResult DangKy(KhachHangEntity kh)
        {
            if (ModelState.IsValid)
            {
                if(kh.tenKH == null)
                {
                    ViewBag.ketqua = "Tên Khách Hàng Không Được Để Trống!";
                    return View();
                    
                }
                if(kh.sdt == null)
                {
                    ViewBag.ketqua = "Số Điện thoại không được để trống!";
                    return View();
                }
                if(!kiemtraSDT(kh.sdt))
                {
                    ViewBag.ketqua = "Kiểm tra lại sự hợp lệ của số điện thoại";
                    return View();
                }
                if(kh.email == null)
                {
                    ViewBag.ketqua = "Email không được để trống!";
                    return View();
                }
                if(!KiemTraEmail(kh.email))
                {
                    ViewBag.ketqua = "Email Không hợp lệ!";
                    return View();
                }
                if(kh.diaChi == null)
                {
                    ViewBag.ketqua = "Địa chỉ không được để trống!";
                    return View();
                }
                if(kh.tenDN == null)
                {
                    ViewBag.ketqua = "Tên đăng nhập không được để trống!";
                    return View();
                }
                if(!khachHang_Client.KiemTraTenDNHopLe(kh.tenDN.Trim()))
                {
                    ViewBag.ketqua = "Tên đăng nhập đã có người sử dụng!";
                    return View();
                }
                if(kh.matKhau == null)
                {
                    ViewBag.ketqua = "Mật khẩu không được để trống!";
                    return View();
                }

                int idKH = khachHang_Client.SoLuongKH() + 1;
                kh.id = idKH;
                khachHang_Client.ThemKhachHang(kh);
                ViewBag.ketqua = "Chúc Mừng Bạn đã đăng ký thành công!";
                return View("ThanhCong");
            }
            ViewBag.ketqua = "Khong Thanh Cong!";
            return View();
        }

        [HttpGet]
        public ActionResult DangNhap()
        {
            return View();
        }

        [HttpPost]
        public ActionResult DangNhap(FormCollection f)
        {
            string taiKhoan = f["txtTaiKhoan"].ToString();
            string matKhau = f.Get("password").ToString();
            
            if (khachHang_Client.KiemTraDN(taiKhoan,matKhau))
            {
                ViewBag.ThongBao = "Chúc mừng bạn đăng nhập thành công !";
                Session["taikhoan"] = khachHang_Client.LayMotDTKhachHang(taiKhoan,matKhau);
                return RedirectToAction("Index");
            }
            ViewBag.ThongBao = "Tên tài khoản hoặc mật khẩu không đúng!";
            return View();
        }

        public ActionResult ThanhCong()
        {
            return View();
        }


        private bool kiemtraSDT(string sdt)
        {
            Char[] chuoi = sdt.ToArray();
            foreach(var i in chuoi)
            {
                if(!Char.IsNumber(i))
                {
                    return false;
                }
            }
            return true;
        }
        public static bool KiemTraEmail(string email)
        {
            string strRegex = @"^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}" +
         @"\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\" +
         @".)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$";
            Regex re = new Regex(strRegex);
            if (re.IsMatch(email))
                return (true);
            else
                return (false);
        }
	}
}