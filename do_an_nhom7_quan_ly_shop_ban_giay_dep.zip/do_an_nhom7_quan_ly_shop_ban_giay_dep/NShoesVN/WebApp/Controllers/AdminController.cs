﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebApp.SanPhamServiceReference;
using WebApp.LoaiSanPhamServiceReference;
using WebApp.LoaiMauServiceReference;
using WebApp.DonHangServiceReference;
using WebApp.CTDHServiceReference;
using WebApp.Models;
using System.IO;
using PagedList.Mvc;
using PagedList;

namespace WebApp.Controllers
{
    public class AdminController : Controller
    {
        private SanPhamServiceClient sanPham_Client = new SanPhamServiceClient();
        private LoaiMauServiceClient loaiMau_Client = new LoaiMauServiceClient();
        private LoaiSanPhamServiceClient loaiSP_Client = new LoaiSanPhamServiceClient();
        private DonHangServiceClient donHang_Client = new DonHangServiceClient();
        private CTDHServiceClient cTDH_Client = new CTDHServiceClient();

        public ActionResult Index()
        {
            return RedirectToAction("DangNhap");
        }

        [HttpGet]
        public ActionResult DangNhap()
        {
            return View();
        }

        [HttpPost]
        public ActionResult DangNhap(FormCollection f)
        {
            string taiKhoan = f["txtTaiKhoan"].ToString();
            string matKhau = f.Get("password").ToString();
            if (taiKhoan== "admin" && matKhau == "123")
            {
                QuanTriVien qtv = new QuanTriVien()
                {
                    tenDN = taiKhoan,
                    matKhau = matKhau
                };
                Session["admin"] = qtv;
                ViewBag.ThongBao = "Chúc mừng bạn đăng nhập thành công !";
                return RedirectToAction("DanhSachSanPham");
            }
            ViewBag.ThongBao = "Tên tài khoản hoặc mật khẩu không đúng!";
            return View();
        }
        public ActionResult DangXuat()
        {
            Session["admin"] = null;
            return RedirectToAction("DangNhap");
        }

        public ActionResult DanhSachSanPham(int? page)
        {
            if(Session["admin"] == null)
            {
                return RedirectToAction("DangNhap");
            }
            var list = sanPham_Client.LayDSSP().ToList();
            int pageSize = 15;
            int pageNumber = (page ?? 1);
            return View(list.ToPagedList(pageNumber, pageSize));
        }

        public ActionResult DanhSachDonHang(int? page)
        {
            if (Session["admin"] == null)
            {
                return RedirectToAction("DangNhap");
            }
            var list = donHang_Client.LayDS_DonHang().ToList();
            int pageSize = 15;
            int pageNumber = (page ?? 1);
            return View(list.ToPagedList(pageNumber, pageSize));
        }

        [HttpGet]
        public ActionResult ThemMoiSanPham()
        {
            ViewBag.LoaiSP = new SelectList(loaiSP_Client.LayDSLoaiSP().ToList(), "id", "tenLoaiSP");
            ViewBag.LoaiMau = new SelectList(loaiMau_Client.LayDS_MauSac().ToList(), "id", "tenMauSac");
            return View();
        }

        [HttpPost]
        public ActionResult ThemMoiSanPham(SanPhamEntity obj, HttpPostedFileBase fileUpload)
        {
            ViewBag.LoaiSP = new SelectList(loaiSP_Client.LayDSLoaiSP().ToList(), "id", "tenLoaiSP");
            ViewBag.LoaiMau = new SelectList(loaiMau_Client.LayDS_MauSac().ToList(), "id", "tenMauSac");
            if (fileUpload == null)
            {
                ViewBag.ThongBao = "Chọn hình ảnh";
                return View();
            }
            if (ModelState.IsValid)
            {
                var fileName = Path.GetFileName(fileUpload.FileName);
                ViewBag.ThongBao = fileName;
                var path = Path.Combine(Server.MapPath("~/Content/sanpham"), fileName);
                if (System.IO.File.Exists(path))
                {
                    ViewBag.ThongBao = "Hình ảnh đã tồn tại";
                }
                else
                {
                    fileUpload.SaveAs(path);
                }
                obj.id = sanPham_Client.SoLuongSP() + 1;
                obj.idLoaiSP++;
                obj.idMauSac++;
                obj.hinhAnh = fileUpload.FileName;
                sanPham_Client.ThemSP(obj);
            }
            return RedirectToAction("DanhSachSanPham");
        }


        [HttpGet]
        public ActionResult ChinhSua(int idSP)
        {
            SanPhamEntity sp = sanPham_Client.LayMotSP(idSP);
            if (sp == null)
            {
                Response.StatusCode = 404;
                return null;
            }
            ViewBag.LoaiSP = new SelectList(loaiSP_Client.LayDSLoaiSP().ToList(), "id", "tenLoaiSP");
            ViewBag.LoaiMau = new SelectList(loaiMau_Client.LayDS_MauSac().ToList(), "id", "tenMauSac");
            return View(sp);
        }
        [HttpPost]
        [ValidateInput(false)]
        public ActionResult ChinhSua(SanPhamEntity obj, FormCollection f)
        {
            ViewBag.LoaiSP = new SelectList(loaiSP_Client.LayDSLoaiSP().ToList(), "id", "tenLoaiSP");
            ViewBag.LoaiMau = new SelectList(loaiMau_Client.LayDS_MauSac().ToList(), "id", "tenMauSac");

            if (ModelState.IsValid)
            {
                obj.idLoaiSP = int.Parse(f["LoaiSP"].ToString());
                obj.idMauSac = int.Parse(f["LoaiMau"].ToString());
                sanPham_Client.SuaSP(obj);
            }
            

            return RedirectToAction("DanhSachSanPham");

        }
	}
}