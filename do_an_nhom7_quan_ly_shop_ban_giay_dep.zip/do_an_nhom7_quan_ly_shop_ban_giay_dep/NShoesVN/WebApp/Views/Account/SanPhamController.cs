﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebApp.SanPhamServiceReference;
using WebApp;
using WebApp.LoaiMauServiceReference;
using WebApp.LoaiSanPhamServiceReference;

namespace WebApp.Controllers
{
    public class SanPhamController : Controller
    {
        private SanPhamServiceClient sanPham_Client = new SanPhamServiceClient();
        private LoaiMauServiceClient loaiMau_Client = new LoaiMauServiceClient();
        private LoaiSanPhamServiceClient loaiSanPham_Client = new LoaiSanPhamServiceClient();
        //
        // GET: /SanPham/
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult ChiTiet(int idSanPham)
        {
            SanPhamEntity model = sanPham_Client.LayMotSP(idSanPham);
            ViewBag.TenMau = loaiMau_Client.LayTenMau(model.idMauSac).ToString();
            ViewBag.LoaiSP = loaiSanPham_Client.LayMotLoaiSP(model.idLoaiSP).tenLoaiSP.ToString();
            ViewBag.DS = sanPham_Client.LayDS_LienQuan(model.idLoaiSP).ToList();
            return View(model);
        }

        public ActionResult DanhMuc(int idLoaiSP)
        {
            var list = sanPham_Client.LayDSSP_TheoLoai(idLoaiSP).ToList();
            return View(list);
        }

       
	}
}