﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WinFormQuanLy.SanPhamServiceReference;
using WinFormQuanLy.LoaiSanPhamServiceReference;
using WinFormQuanLy.KhachHangServiceReference;
using WinFormQuanLy.DonHangServiceReference;
using WinFormQuanLy.LoaiMauServiceReference;
using WinFormQuanLy.NhapKhoServiceReference;
using WinFormQuanLy.CTDHServiceReference;

namespace WinFormQuanLy
{
    public partial class GiaoDien : Form
    {
        private SanPhamServiceClient sanPham_Client = new SanPhamServiceClient();
        private LoaiSanPhamServiceClient loaiSanPham_Client = new LoaiSanPhamServiceClient();
        private KhachHangServiceClient khachHang_Client = new KhachHangServiceClient();
        private DonHangServiceClient donHang_Client = new DonHangServiceClient();
        private LoaiMauServiceClient mauSac_Client = new LoaiMauServiceClient();
        private NhapKhoServiceClient nhapKho_Client = new NhapKhoServiceClient();
        private CTDHServiceClient cTDH_Client = new CTDHServiceClient();

        public GiaoDien()
        {
            InitializeComponent();
            LoadSanPham();
        }

        private void tabControl_TabIndexChanged(object sender, EventArgs e)
        {
            switch (tabControl.SelectedIndex)
            {
                case 0: LoadSanPham(); break;
                case 1: LoadLoaiSanPham(); break;
                case 2: LoadDonHang(); break;
                case 3: LoadKhachHang(); break;
                case 4: LoadNhapKho(); break;
                case 5: LoadThongKe(); break;
                default: LoadSanPham(); break;
            }
        }
        private void KhongNhapChu(object sender, KeyPressEventArgs e)
        {
            Common.Business.KhongChoNhapChu(sender, e);
        }



        #region Sản Phẩm
        public void LoadSanPham()
        {
            SP_txt_TenSP.Text = "";
            SP_cb_LoaiSP.DataSource = loaiSanPham_Client.LayDSLoaiSP().ToList();
            SP_cb_LoaiSP.ValueMember = "id";
            SP_cb_LoaiSP.DisplayMember = "tenLoaiSP";
            SP_cb_LoaiSP.SelectedIndex = -1;
            SP_cb_MauSac.DataSource = mauSac_Client.LayDS_MauSac().ToList();
            SP_cb_MauSac.ValueMember = "id";
            SP_cb_MauSac.DisplayMember = "tenMauSac";
            SP_cb_MauSac.SelectedIndex = -1;

            SP_cb_Gia.SelectedIndex = -1;
            SP_txt_KichThuoc.Text = "";

            List<SanPhamEntity> list = sanPham_Client.LayDSSP().ToList();
            dataSanPham.DataSource = list;
        }

        /// <summary>
        /// Thêm Sản Phẩm Mới
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void SP_btn_Them_Click(object sender, EventArgs e)
        {
            FormThemSanPham form = new FormThemSanPham();
            form.ShowDialog();
        }

        /// <summary>
        /// Cập Nhật thông tin sản phẩm
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dataSanPham_CellMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {

            var row = dataSanPham.CurrentRow;
            int idSP = int.Parse(row.Cells[0].Value.ToString());
            SanPhamEntity item = sanPham_Client.LayMotSP(idSP);

            FormSuaSanPham form = new FormSuaSanPham(item);
            form.ShowDialog();
        }

        /// <summary>
        /// Tìm Kiếm Sản Phẩm
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void SP_btn_TimKiem_Click(object sender, EventArgs e)
        {
            string tenSanPham = "";
            int loaiSanPham = -1;
            int mucGia = -1;
            int mauSac = -1;
            int kichThuoc = -1;

            if (SP_txt_TenSP.Text.Trim() != "")
            {
                tenSanPham = SP_txt_TenSP.Text.Trim();
            }
            if (SP_cb_LoaiSP.SelectedIndex != -1)
            {
                loaiSanPham = int.Parse(SP_cb_LoaiSP.SelectedValue.ToString());
            }
            if (SP_cb_Gia.SelectedIndex != -1)
            {
                mucGia = SP_cb_Gia.SelectedIndex;
            }
            if (SP_cb_MauSac.SelectedIndex != -1)
            {
                mauSac = int.Parse(SP_cb_MauSac.SelectedValue.ToString());
            }
            if (SP_txt_KichThuoc.Text.Trim() != "" && int.Parse(SP_txt_KichThuoc.Text.Trim().ToString()) > 0)
            {
                kichThuoc = int.Parse(SP_txt_KichThuoc.Text.Trim().ToString());
            }
            List<SanPhamEntity> list = sanPham_Client.TimKiem(tenSanPham, loaiSanPham, mucGia, mauSac, kichThuoc).ToList();
            dataSanPham.DataSource = null;
            dataSanPham.DataSource = list;
        }

        private void SP_btn_Refresh_Click(object sender, EventArgs e)
        {
            LoadSanPham();
        }

        #endregion




        #region Loại Sản Phẩm
        private void LoadLoaiSanPham()
        {
            List<LoaiSanPhamEntity> list = loaiSanPham_Client.LayDSLoaiSP().ToList();
            dataLoaiSP.DataSource = list;
            LoaiSP_txt_TenLoaiSP.Text = "";
        }

        /// <summary>
        /// Thêm Loại Sản Phẩm Mới
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void LoaiSP_btn_Them_Click(object sender, EventArgs e)
        {
            FormThemLoaiSanPham form = new FormThemLoaiSanPham();
            form.ShowDialog();
        }

        /// <summary>
        /// Cập Nhật thông tin loại sản phẩm
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dataLoaiSP_CellMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            var row = dataLoaiSP.CurrentRow;
            int idLoaiSP = int.Parse(row.Cells[0].Value.ToString());
            LoaiSanPhamEntity obj = loaiSanPham_Client.LayMotLoaiSP(idLoaiSP);

            FormCapNhatLoaiSanPham form = new FormCapNhatLoaiSanPham(obj);
            form.ShowDialog();
        }

        /// <summary>
        /// Tìm loại sản phẩm theo tên
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void LoaiSP_btn_Tim_Click(object sender, EventArgs e)
        {
            string tenLoaiSP = LoaiSP_txt_TenLoaiSP.Text.Trim();
            if(tenLoaiSP == null)
            {
                return;
            }
            List<LoaiSanPhamEntity> list = loaiSanPham_Client.TimKiem(tenLoaiSP).ToList();
            dataLoaiSP.DataSource = null;
            dataLoaiSP.DataSource = list;
        }

        private void LoaiSP_btn_Refresh_Click(object sender, EventArgs e)
        {
            LoadLoaiSanPham();
        }

        #endregion




        #region Khách Hàng

        private void LoadKhachHang()
        {
            List<KhachHangEntity> list = khachHang_Client.LayDSKhachHang().ToList();
            dataKhachHang.DataSource = list;

            KH_txt_TenKH.Text = "";
            KH_txt_SDT.Text = "";
            KH_txt_Email.Text = "";
        }

        /// <summary>
        /// Thêm Mới 1 Khách Hàng
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void KH_btn_Them_Click(object sender, EventArgs e)
        {
            FormThemKhachHang form = new FormThemKhachHang();
            form.ShowDialog();
        }

        /// <summary>
        /// Cập Nhật thông tin khách hàng
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dataKhachHang_CellMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            var row = dataKhachHang.CurrentRow;
            int idKhachHang = int.Parse(row.Cells[0].Value.ToString());

            KhachHangEntity item = khachHang_Client.LayMotKhachHang(idKhachHang);
            FormCapNhatKhachHang form = new FormCapNhatKhachHang(item);
            form.ShowDialog();
        }

        /// <summary>
        /// Tìm Kiếm Thông tin Khách Hàng
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void KH_btn_TimKiem_Click(object sender, EventArgs e)
        {
            string tenKhachHang = KH_txt_TenKH.Text.Trim();
            string sdt = KH_txt_SDT.Text.Trim();
            string email = KH_txt_Email.Text.Trim();

            List<KhachHangEntity> list = khachHang_Client.TimKhachHang(tenKhachHang,sdt,email).ToList();
            dataKhachHang.DataSource = null;
            dataKhachHang.DataSource = list;
        }
        private void KH_btn_Refresh_Click(object sender, EventArgs e)
        {
            LoadKhachHang();
        }

        #endregion Khách Hàng


        #region Đơn Hàng
        private void LoadDonHang()
        {
            List<DonHangEntity> list = donHang_Client.LayDS_DonHang().ToList();
            dataDonHang.DataSource = list;
        }

        // Tạo Đơn Hàng
        private void DH_btn_TaoHoaDon_Click(object sender, EventArgs e)
        {
            FormThemDonHang form = new FormThemDonHang();
            form.ShowDialog();
        }

        /// <summary>
        /// Cập Nhật Đơn Hàng
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dataDonHang_CellMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            var row = dataDonHang.CurrentRow;
            int idDH = int.Parse(row.Cells[0].Value.ToString());
            var item = donHang_Client.LayMotDonHang(idDH);
            if (item.idTrangThai == 1)
            {
                FormSuaDonhang form = new FormSuaDonhang(item);
                form.ShowDialog();
            }
            else
            {
                FormChiTietDonHang form = new FormChiTietDonHang(item);
                form.ShowDialog();
            }
        }

        /// <summary>
        /// Tìm Kiếm Đơn Hàng
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void DH_btn_TimKiem_Click(object sender, EventArgs e)
        {
            string tenKH = "";
            if (DH_txt_TenKH.Text.Trim() != "")
            {
                tenKH = DH_txt_TenKH.Text.Trim();
            }
            DateTime tuNgay = DH_dtp_TuNgay.Value.Date;
            DateTime denNgay = DH_dtp_DenNgay.Value.Date;
            int trangthai = 0;
            if (tuNgay > denNgay)
            {
                MessageBox.Show("Từ Ngày không được lớn hơn Đến Ngày");
                return;
            }
            if (DH_chk_ChoXL.Checked && !DH_chk_DaXL.Checked)
            {
                trangthai = 1;
            }
            else
            {
                if (!DH_chk_ChoXL.Checked && DH_chk_DaXL.Checked)
                {
                    trangthai = 2;
                }
            }
            timHD(tenKH, tuNgay, denNgay, trangthai);
        }

        private void timHD(string tenKH, DateTime tuNgay, DateTime denNgay, int trangThai)
        {
            var list = donHang_Client.LayDS_DonHang().ToList();
            if (tenKH != "")
            {
                List<DonHangEntity> listnew = new List<DonHangEntity>();
                foreach (var i in list)
                {
                    if (i.tenKH == tenKH)
                    {
                        listnew.Add(i);
                    }
                }
                list = listnew;
            }
            {
                List<DonHangEntity> listnew = new List<DonHangEntity>();
                foreach (var i in list)
                {
                    if (tuNgay <= i.ngayDH && i.ngayDH <= denNgay)
                    {
                        listnew.Add(i);
                    }
                }
                list = listnew;
            }
            if (trangThai != 0)
            {
                List<DonHangEntity> listnew = new List<DonHangEntity>();
                foreach (var i in list)
                {
                    if (trangThai == i.idTrangThai)
                    {
                        listnew.Add(i);
                    }
                }
                list = listnew;
            }

            dataDonHang.DataSource = list;

        }
        private void DH_btn_Refresh_Click(object sender, EventArgs e)
        {
            LoadDonHang();
        }
        #endregion


        #region Nhap Kho
        private void LoadNhapKho()
        {
            dataNhapKho.DataSource = null;
            List<NhapKhoEntity> list = nhapKho_Client.LayDS_PhieuNhap().ToList();
            dataNhapKho.DataSource = list;
        }
        private void NK_btn_Refresh_Click(object sender, EventArgs e)
        {
            LoadNhapKho();
        }

        private void NK_btn_Them_Click(object sender, EventArgs e)
        {
            FormThemPhieuNhap form = new FormThemPhieuNhap();
            form.ShowDialog();
        }

        private void dataNhapKho_CellMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            var row = dataNhapKho.CurrentRow;
            if(row== null)
            {
                MessageBox.Show("Bạn Chưa Chọn Phiếu Nhập");
                return;
            }
            int idNK = int.Parse(row.Cells[0].Value.ToString());
            NhapKhoEntity objNK = nhapKho_Client.LayMotPhieuNhap(idNK);
            FormChiTietPhieuNhap form = new FormChiTietPhieuNhap(objNK);
            form.ShowDialog();
           
        }
        #endregion

        #region Thong Ke
        private void LoadThongKe()
        {
            var listDSSP = sanPham_Client.LayDSSP().ToList();
            var listCTHD = cTDH_Client.LayToanBoDS();
            List<SanPhamEntity> result = new List<SanPhamEntity>();
            foreach (var i in listDSSP)
            {
                i.soLuong = 0;
                foreach (var j in listCTHD)
                {
                    if(i.id == j.idSP)
                    {
                        i.soLuong += j.soLuong;
                    }
                }
                if(i.soLuong>0)
                {
                    result.Add(i);
                }
            }
            dataThongKe.DataSource = result;

        }

        private void TK_btn_thongke_Click(object sender, EventArgs e)
        {
            DateTime tuNgay = TK_dtp_TuNgay.Value.Date;
            DateTime denNgay = TK_dtp_DenNgay.Value.Date;
            if(tuNgay>denNgay)
            {
                MessageBox.Show("Từ Ngày phải nhỏ hơn Đến Ngày");
                return;
            }

            var listDSSP = sanPham_Client.LayDSSP().ToList();
            var listCTHD = cTDH_Client.LayDSTheoNgay(tuNgay, denNgay);
            List<SanPhamEntity> result = new List<SanPhamEntity>();
            foreach (var i in listDSSP)
            {
                i.soLuong = 0;
                foreach (var j in listCTHD)
                {
                    
                    if (i.id == j.idSP)
                    {
                        i.soLuong += j.soLuong;
                    }
                }
                if (i.soLuong > 0)
                {
                    result.Add(i);
                }
            }
            dataThongKe.DataSource = result;

        }

        private void TK_btn_Refresh_Click(object sender, EventArgs e)
        {
            LoadThongKe();
        }
        #endregion

       


    }
}
