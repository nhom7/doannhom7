﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WinFormQuanLy.LoaiMauServiceReference;
using WinFormQuanLy.SanPhamServiceReference;
using WinFormQuanLy.LoaiSanPhamServiceReference;

namespace WinFormQuanLy
{
    public partial class FormSuaSanPham : Form
    {
        private LoaiSanPhamServiceClient loaiSanPham_Client = new LoaiSanPhamServiceClient();
        private SanPhamServiceClient sanPham_Client = new SanPhamServiceClient();
        private LoaiMauServiceClient mau_Client= new LoaiMauServiceClient();
        private SanPhamEntity obj = new SanPhamEntity();
        public FormSuaSanPham(SanPhamEntity obj)
        {
            this.obj = obj;
            InitializeComponent();
            LoadTrang();
        }


        
        private void LoadTrang()
        {
            cb_LoaiSP.DataSource = loaiSanPham_Client.LayDSLoaiSP().ToList();
            cb_LoaiSP.ValueMember = "id";
            cb_LoaiSP.DisplayMember = "tenLoaiSP";
            cb_MauSac.DataSource = mau_Client.LayDS_MauSac().ToList();
            cb_MauSac.ValueMember = "id";
            cb_MauSac.DisplayMember = "tenMauSac";

            txt_TenSP.Text = obj.tenSP.ToString();
            txt_KichThuoc.Text = obj.kichThuoc.ToString();
            rtxt_MoTa.Text = obj.mieuTa.ToString();
            txt_GiamGia.Text = obj.giaGiam.ToString();
            txt_GiaThanh.Text = obj.giaNiemYet.ToString();
            txtSoLuong.Text = obj.soLuong.ToString();
            txt_HinhAnh.Text = obj.hinhAnh.ToString();

            cb_LoaiSP.SelectedValue = obj.idLoaiSP;
            cb_MauSac.SelectedValue = obj.idMauSac;

            cb_SPDB.SelectedIndex = 0;
            if(obj.spDB == false)
            {
                cb_SPDB.SelectedIndex = 1;
            }
            cb_SPMoi.SelectedIndex = 0;
            if(obj.spMoi == false)
            {
                cb_SPMoi.SelectedIndex = 1;
            }
            pictureSanPham.Image = Image.FromFile((@"D:\Demo\NShoesVN\WebApp\Content\sanpham\" + obj.hinhAnh).ToString());

        }

        // Chọn Hình Ảnh
        private void btn_HinhAnh_Click(object sender, EventArgs e)
        {
            openFileHinhAnh.Filter = " All Files (*.*)|*.*| PNG (.png)|*.png| JPEG (*.jpeg)|*.jpeg| JPG (*.jpg)|*.jpg";
            DialogResult result = openFileHinhAnh.ShowDialog();
            if (result == DialogResult.OK)
            {
                string file = openFileHinhAnh.FileName;
                openFileHinhAnh.InitialDirectory = @"D:\Demo\NShoesVN\WebApp\Content\sanpham";
                pictureSanPham.Image = Image.FromFile(openFileHinhAnh.FileName);
                txt_HinhAnh.Text = Common.Business.tenHinhSP(file);
            }
        }

        // Làm Lại
        private void btn_LamLai_Click(object sender, EventArgs e)
        {
            LoadTrang();
        }

        private void KhongNhapChu(object sender, KeyPressEventArgs e)
        {
            Common.Business.KhongChoNhapChu(sender,e);
        }

        /// <summary>
        /// Thêm Sản phẩm
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btn_Luu_Click(object sender, EventArgs e)
        {
            if (txt_TenSP.Text.Trim() == "")
            {
                MessageBox.Show("Tên Sản Phẩm không được để trống!");
                return;
            }
            if (txt_GiaThanh.Text.Trim() == "" || double.Parse(txt_GiaThanh.Text.Trim()) == 0.0)
            {
                MessageBox.Show("Giá Sản Phẩm Không Được Để trống!");
                return;
            }
            if (cb_MauSac.SelectedValue == "")
            {
                MessageBox.Show("Bạn Chưa chọn Màu cho Sản Phẩm!");
                return;
            }
            if (txt_KichThuoc.Text.Trim() == "" || double.Parse(txt_KichThuoc.Text.Trim()) == 0.0)
            {
                MessageBox.Show("Kích Thước không được để trống!");
                return;
            }
            if (rtxt_MoTa.Text.Trim() == "")
            {
                MessageBox.Show("Mô tả không được để trống!");
                return;
            }
            if (cb_LoaiSP.SelectedValue == "")
            {
                MessageBox.Show("Chưa Chọn loại sản phẩm!");
                return;
            }
            if (txtSoLuong.Text.Trim() == "" || int.Parse(txtSoLuong.Text.Trim()) == 0)
            {
                MessageBox.Show("Chưa nhập số lượng!");
                return;
            }
            if (txt_HinhAnh.Text.Trim() == "")
            {
                MessageBox.Show("Bạn Chưa chọn hình ảnh!");
                return;
            }

            SanPhamEntity item = new SanPhamEntity();
            {
                item.id = obj.id;
                item.tenSP = txt_TenSP.Text.Trim();
                item.idLoaiSP = int.Parse(cb_LoaiSP.SelectedValue.ToString());
                item.giaNiemYet = decimal.Parse(txt_GiaThanh.Text.Trim());
                item.giaGiam = decimal.Parse(txt_GiamGia.Text.Trim());
                item.idMauSac = int.Parse(cb_MauSac.SelectedValue.ToString());
                item.kichThuoc = int.Parse(txt_KichThuoc.Text.Trim());
                item.mieuTa = rtxt_MoTa.Text;
                item.hinhAnh = txt_HinhAnh.Text;
                item.soLuong = int.Parse(txtSoLuong.Text.Trim());
                item.spDB = false;
                if (cb_SPDB.SelectedItem.ToString() == "Có")
                {
                    item.spDB = true;
                }
                item.spMoi = false;
                if (cb_SPMoi.SelectedItem.ToString() == "Có")
                {
                    item.spMoi = true;
                }
                //if (item.giaGiam > item.giaNiemYet)
                //{
                //    MessageBox.Show("Số Tiền giảm không được vượt quá giá thành!");
                //    return;
                //}
                if(item.giaGiam>item.giaNiemYet)
                {
                    MessageBox.Show("Loi khi gia");
                    return;
                }
            }

            try
            {
                sanPham_Client.SuaSP(item);
                MessageBox.Show("Cập Nhật Sản Phẩm Thành Công!");
                CapNhatXong();
            }
            catch
            {
                MessageBox.Show("Lỗi Khi Lưu Sản Phẩm");
            }
        }

        private void CapNhatXong()
        {
            txt_TenSP.Text = "";
            txt_GiamGia.Text = "";
            txt_GiaThanh.Text = "";
            txt_HinhAnh.Text = "";
            txt_KichThuoc.Text = "";
            txtSoLuong.Text = "";
            rtxt_MoTa.Text = "";
            cb_LoaiSP.SelectedIndex = 0;
            cb_MauSac.SelectedIndex = 0;
            cb_SPDB.SelectedIndex = 0;
            cb_SPMoi.SelectedIndex = 0;
        }

       
    }
}
