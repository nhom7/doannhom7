﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WinFormQuanLy.KhachHangServiceReference;

namespace WinFormQuanLy
{
    public partial class FormCapNhatKhachHang : Form
    {
        private KhachHangServiceClient khachHang_Client = new KhachHangServiceClient();
        private KhachHangEntity obj = new KhachHangEntity();
        public FormCapNhatKhachHang(KhachHangEntity obj)
        {
            this.obj = obj;
            InitializeComponent();
            LoadTrang();
        }

        private void KhongNhapChu(object sender, KeyPressEventArgs e)
        {
            Common.Business.KhongChoNhapChu(sender, e);
        }

        // Load Dữ Liệu về 1 Khách Hàng Lên
        private void LoadTrang()
        {
            txt_TenKH.Text = obj.tenKH;
            txt_DiaChi.Text = obj.diaChi;
            txt_Email.Text = obj.email;
            txt_SDT.Text = obj.sdt;
        }

        /// <summary>
        /// Lưu Thông tin Cập nhật Mới Khách Hàng
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btn_Luu_Click(object sender, EventArgs e)
        {
            if (txt_TenKH.Text.Trim() == "")
            {
                MessageBox.Show("Tên Khách Hàng không được để trống!");
                return;
            }
            if (txt_SDT.Text.Trim() == "")
            {
                MessageBox.Show("Số Điện Thoại không được để trống!");
                return;
            }
            if (txt_Email.Text.Trim() == "")
            {
                MessageBox.Show("Email Không được để trống!");
                return;
            }
            if (Common.Business.KiemTraEmail(txt_Email.Text.Trim()) == false)
            {
                MessageBox.Show("Email không hợp lệ!");
                return;
            }
            if (txt_DiaChi.Text.Trim() == "")
            {
                MessageBox.Show("Địa Chỉ không được để trống!");
                return;
            }

            KhachHangEntity item = new KhachHangEntity()
            {
                id = obj.id,
                tenKH = txt_TenKH.Text.Trim(),
                diaChi = txt_DiaChi.Text.Trim(),
                email = txt_Email.Text.Trim(),
                sdt = txt_SDT.Text.Trim()
            };

            try
            {
                khachHang_Client.CapNhatKhachHang(item);
                MessageBox.Show("Cập Nhật khách hàng Thành công!");
                txt_TenKH.Text = "";
                txt_SDT.Text = "";
                txt_DiaChi.Text = "";
                txt_Email.Text = "";
            }
            catch
            {
                MessageBox.Show("Lỗi khi Cập Nhật thông tin khách hàng!");
            }
        }

        private void btn_LamLai_Click(object sender, EventArgs e)
        {
            LoadTrang();
        }
    }
}
