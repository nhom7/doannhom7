﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WinFormQuanLy.SanPhamServiceReference;
using WinFormQuanLy.NhapKhoServiceReference;
using WinFormQuanLy.CTNKServiceReference;


namespace WinFormQuanLy
{
    public partial class FormThemPhieuNhap : Form
    {
        private CTNKServiceClient cTNK_Client = new CTNKServiceClient();
        private NhapKhoServiceClient nhapKho_Client = new NhapKhoServiceClient();
        private SanPhamServiceClient sanPham_Client = new SanPhamServiceClient();
        private List<CTNKEntity> list = new List<CTNKEntity>();
        public FormThemPhieuNhap()
        {
            InitializeComponent();
            LoadTrang();
        }

        public void LoadTrang()
        {
            cb_SanPham.DataSource = sanPham_Client.LayDSSP().ToList();
            cb_SanPham.ValueMember = "id";
            cb_SanPham.DisplayMember = "tenSP";
            cb_SanPham.SelectedIndex = 0;

            txt_GiaNhap.Text = "";
            txt_SoLuong.Text = "";
            dataCTNK.DataSource = null;
            lbl_TongTien.Text = "";
        }

        private void KhongNhapChu(object sender, KeyPressEventArgs e)
        {
            Common.Business.KhongChoNhapChu(sender, e);
        }

        private void btn_Them_Click(object sender, EventArgs e)
        {
            CTNKEntity item = new CTNKEntity();
            item.idNK = nhapKho_Client.SoLuongPhieuNhap() + 1;
            item.idMucLoi = 1;
            item.idSP = int.Parse(cb_SanPham.SelectedValue.ToString());
            item.soLuong = int.Parse(txt_SoLuong.Text);
            item.tenSP = sanPham_Client.LayTenSP(item.idSP);
            item.giaNhap = decimal.Parse(txt_GiaNhap.Text);

            foreach(var i in list)
            {
                if(i.idSP == item.idSP)
                {
                    i.soLuong = item.soLuong;
                    i.giaNhap = item.giaNhap;
                    LoadLai();
                    return;
                }
            }

            list.Add(item);
            LoadLai();
        }

        private void LoadLai()
        {
            dataCTNK.DataSource = null;
            dataCTNK.DataSource = list;
            lbl_TongTien.Text = TongTienNhap().ToString();
        }

        private decimal TongTienNhap()
        {
            decimal sum = 0;
            foreach(var i in list)
            {
                sum += (decimal.Parse(i.giaNhap.ToString()) * i.soLuong);
            }
            return sum;
        }

        private void btn_Xoa_Click(object sender, EventArgs e)
        {
            var row = dataCTNK.CurrentRow;
            if (row != null)
            {
                int idSP = int.Parse(row.Cells[0].Value.ToString());
                list.RemoveAll(p => p.idSP == idSP);
                LoadLai();
            }

        }

        private void btn_Luu_Click(object sender, EventArgs e)
        {
            if(list == null)
            {
                MessageBox.Show("Không Có Dữ Liệu!");
                return;
            }
            NhapKhoEntity item = new NhapKhoEntity();
            item.id = nhapKho_Client.SoLuongPhieuNhap() + 1;
            item.ngayNhapKho = dateTime.Value;
            item.tongTien = TongTienNhap();
            nhapKho_Client.ThemPhieuNhap(item);

            foreach(var i in list)
            {
                cTNK_Client.ThemCTNK(i);
            }

            MessageBox.Show("Thêm Phiếu Nhập thành CÔng!");

        }
    }
}
