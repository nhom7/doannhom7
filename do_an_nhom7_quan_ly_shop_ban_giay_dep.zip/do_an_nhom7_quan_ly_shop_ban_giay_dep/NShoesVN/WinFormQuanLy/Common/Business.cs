﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormQuanLy.Common
{
    public static class Business
    {
        /// <summary>
        /// Lấy Tên Hình
        /// </summary>
        /// <param name="path"></param>
        /// <returns></returns>
        public static string tenHinhSP(string path)
        {
            char[] chuoi = path.ToCharArray();
            Array.Reverse(chuoi);
            string result = "";
            foreach (char i in chuoi)
            {
                if (i == '\\')
                {
                    break;
                }
                result += i.ToString();
            }
            char[] filename = result.ToCharArray();
            Array.Reverse(filename);

            return new string(filename);
        }

        public static List<int> ChuoiSoLuong(int max)
        {
            List<int> list = new List<int>();
            for (int i = 1; i <= max; i++)
            {
                list.Add(i);
            }
            return list;
        }

        /// <summary>
        /// Kiểm Tra Email hợp lệ
        /// </summary>
        /// <param name="email"></param>
        /// <returns></returns>
        public static bool KiemTraEmail(string email)
        {
            string strRegex = @"^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}" +
         @"\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\" +
         @".)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$";
            Regex re = new Regex(strRegex);
            if (re.IsMatch(email))
                return (true);
            else
                return (false);
        }

        /// <summary>
        /// Chỉ Cho Nhập Số
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public static void KhongChoNhapChu(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsDigit(e.KeyChar) && !Char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }
    }
}
