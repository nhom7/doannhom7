﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WinFormQuanLy.DonHangServiceReference;
using WinFormQuanLy.KhachHangServiceReference;
using WinFormQuanLy.SanPhamServiceReference;
using WinFormQuanLy.CTDHServiceReference;
using WinFormQuanLy.TrangThaiDHServiceReference;

namespace WinFormQuanLy
{
    public partial class FormThemDonHang : Form
    {
        private KhachHangServiceClient khachHang_Client = new KhachHangServiceClient();
        private SanPhamServiceClient sanPham_Client = new SanPhamServiceClient();
        private DonHangServiceClient donHang_Client = new DonHangServiceClient();
        private CTDHServiceClient cTDH_Client = new CTDHServiceClient();
        private TrangThaiDHServiceClient trangThai_Client = new TrangThaiDHServiceClient();
        private List<CTDHEntity> listCTHD = new List<CTDHEntity>();
        public FormThemDonHang()
        {
           InitializeComponent();
           LoadTrang();
        }

        /// <summary>
        /// Load Data Vào Form
        /// </summary>
        private void LoadTrang()
        {
            List<KhachHangEntity> listKH = khachHang_Client.LayDSKhachHang().ToList();
            cbo_KhachHang.DataSource = listKH;
            cbo_KhachHang.ValueMember = "id";
            cbo_KhachHang.DisplayMember = "tenKH";
            cbo_KhachHang.SelectedIndex = 0;

            List<SanPhamEntity> listSP = sanPham_Client.LayDSSP().ToList();
            cbo_SanPham.DataSource = listSP;
            cbo_SanPham.ValueMember = "id";
            cbo_SanPham.DisplayMember = "tenSP";
            cbo_SanPham.SelectedIndex = 0;

            cbo_SoLuong.DataSource = Common.Business.ChuoiSoLuong(sanPham_Client.SoLuongDVSP(1));
            dtp_NgayDH.Value = DateTime.Now.Date;
            dataCTDH.DataSource = null;
            listCTHD.Clear();
            lblTongTien.Text = "0 ";
            lblSoTienGiam.Text = "0 ";
            lblThanhTien.Text = "0 ";

        }

        /// <summary>
        /// Thêm Sản Phẩm Vào Chi Tiết Đơn Hàng
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btn_ThemSP_Click(object sender, EventArgs e)
        {
            CTDHEntity item = new CTDHEntity()
            {
                
                idDH = donHang_Client.SoLuong() + 1,
                idSP = int.Parse(cbo_SanPham.SelectedValue.ToString()),
                tenSanPham = sanPham_Client.LayTenSP(int.Parse(cbo_SanPham.SelectedValue.ToString())),
                giaNiemYet = sanPham_Client.LayGiaSP(int.Parse(cbo_SanPham.SelectedValue.ToString())),
                giaGiam = sanPham_Client.LayGiaGiam(int.Parse(cbo_SanPham.SelectedValue.ToString())),
                soLuong = int.Parse(cbo_SoLuong.SelectedValue.ToString())
            };
            foreach(var i in listCTHD)
            {
                if(i.idSP == item.idSP)
                {
                    i.soLuong += item.soLuong;
                    if(i.soLuong > sanPham_Client.SoLuongDVSP(i.idSP))
                    {
                        MessageBox.Show("Số Lượng Bạn Thêm Đã Vượt Quá Trong Kho!");
                        return;
                    }
                    LoadDaTaCT();
                    return;
                }
            }

            listCTHD.Add(item);
            LoadDaTaCT();
        }

        // Load Lại Danh Sách Chi Tiết Đơn Hàng
        private void LoadDaTaCT()
        {
            dataCTDH.DataSource = null;
            dataCTDH.DataSource = listCTHD;
            lblTongTien.Text = TinhTien_TongTien().ToString();
            lblSoTienGiam.Text = TinhTien_DuocGiam().ToString();
            lblThanhTien.Text = TinhTien_ThanhTien().ToString();
        }

        // Tính [Lại] Tiền Đơn Hàng
        private decimal TinhTien_ThanhTien()
        {
            return TinhTien_TongTien() - TinhTien_DuocGiam();
        }
        private decimal TinhTien_TongTien()
        {
            decimal sum = 0;
            foreach(var i in listCTHD)
            {
                sum += i.giaNiemYet * i.soLuong;
            }
            return sum;
        }
        private decimal TinhTien_DuocGiam()
        {
            decimal sum = 0;
            foreach(var i in listCTHD)
            {
                sum += decimal.Parse((i.giaGiam * i.soLuong).ToString());
            }
            return sum;
        }

        // Thay đổi số Lượng trong Combobox theo Sản Phẩm
        private void cbo_SanPham_SelectedIndexChanged(object sender, EventArgs e)
        {
            int kt;
            if (int.TryParse(cbo_SanPham.SelectedValue.ToString(), out kt))
            {
                int idSP = int.Parse(cbo_SanPham.SelectedValue.ToString());
                cbo_SoLuong.DataSource = Common.Business.ChuoiSoLuong(sanPham_Client.SoLuongDVSP(idSP));
            }
           
        }


        /// <summary>
        /// Thêm Đơn Hàng Vào CSDL
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btn_ThemDH_Click(object sender, EventArgs e)
        {
            if(listCTHD.Count == 0)
            {
                MessageBox.Show("Bạn Chưa thêm Sản phẩm vào đơn hàng!");
                return;
            }
            try
            {
                DonHangEntity item = new DonHangEntity();
                item.id = donHang_Client.SoLuong() + 1;
                item.idKhachHang = int.Parse(cbo_KhachHang.SelectedValue.ToString());
                item.ngayDH = dtp_NgayDH.Value.Date;
                item.tenKH = khachHang_Client.LayTenKH(item.idKhachHang);
                item.thanhTien = TinhTien_ThanhTien();
                item.idTrangThai = 1;
                donHang_Client.ThemDonHang(item);
                foreach (var i in listCTHD)
                {
                    cTDH_Client.ThemChiTiet(i);
                }
                MessageBox.Show("Thêm Chi Tiết Hóa Đơn Thành Công!");
                LoadTrang();
                return;
            }
            catch
            {
                MessageBox.Show("Lỗi Khi Thêm Chi Tiết Hóa Đơn!");
            }

        }


        private void btn_LamLaiDH_Click(object sender, EventArgs e)
        {
            LoadTrang();
        }

    }
}
