﻿namespace WinFormQuanLy
{
    partial class FormChiTietPhieuNhap
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.label7 = new System.Windows.Forms.Label();
            this.lbl_TongTien = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.dataCTNK = new System.Windows.Forms.DataGridView();
            this.dateTime = new System.Windows.Forms.DateTimePicker();
            this.label1 = new System.Windows.Forms.Label();
            this.idSPDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.idNKDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tenSPDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.soLuongDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.giaNhapDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nhapKhoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sanPhamDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.idMucLoiDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.mucLoiDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cTNKEntityBindingSource = new System.Windows.Forms.BindingSource(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.dataCTNK)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cTNKEntityBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Blue;
            this.label7.Location = new System.Drawing.Point(274, 315);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(43, 20);
            this.label7.TabIndex = 33;
            this.label7.Text = "VNĐ";
            // 
            // lbl_TongTien
            // 
            this.lbl_TongTien.AutoSize = true;
            this.lbl_TongTien.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_TongTien.Location = new System.Drawing.Point(110, 402);
            this.lbl_TongTien.Name = "lbl_TongTien";
            this.lbl_TongTien.Size = new System.Drawing.Size(0, 20);
            this.lbl_TongTien.TabIndex = 32;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(72, 315);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(83, 20);
            this.label5.TabIndex = 31;
            this.label5.Text = "Tổng Tiền:";
            // 
            // dataCTNK
            // 
            this.dataCTNK.AutoGenerateColumns = false;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataCTNK.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dataCTNK.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataCTNK.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idSPDataGridViewTextBoxColumn,
            this.idNKDataGridViewTextBoxColumn,
            this.tenSPDataGridViewTextBoxColumn,
            this.soLuongDataGridViewTextBoxColumn,
            this.giaNhapDataGridViewTextBoxColumn,
            this.nhapKhoDataGridViewTextBoxColumn,
            this.sanPhamDataGridViewTextBoxColumn,
            this.idMucLoiDataGridViewTextBoxColumn,
            this.mucLoiDataGridViewTextBoxColumn});
            this.dataCTNK.DataSource = this.cTNKEntityBindingSource;
            this.dataCTNK.Enabled = false;
            this.dataCTNK.Location = new System.Drawing.Point(25, 78);
            this.dataCTNK.Name = "dataCTNK";
            this.dataCTNK.Size = new System.Drawing.Size(349, 219);
            this.dataCTNK.TabIndex = 27;
            // 
            // dateTime
            // 
            this.dateTime.Enabled = false;
            this.dateTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTime.Location = new System.Drawing.Point(174, 24);
            this.dateTime.Name = "dateTime";
            this.dateTime.Size = new System.Drawing.Size(200, 26);
            this.dateTime.TabIndex = 22;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(21, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(134, 20);
            this.label1.TabIndex = 19;
            this.label1.Text = "Ngày Nhập Hàng:";
            // 
            // idSPDataGridViewTextBoxColumn
            // 
            this.idSPDataGridViewTextBoxColumn.DataPropertyName = "idSP";
            this.idSPDataGridViewTextBoxColumn.HeaderText = "idSP";
            this.idSPDataGridViewTextBoxColumn.Name = "idSPDataGridViewTextBoxColumn";
            this.idSPDataGridViewTextBoxColumn.Visible = false;
            // 
            // idNKDataGridViewTextBoxColumn
            // 
            this.idNKDataGridViewTextBoxColumn.DataPropertyName = "idNK";
            this.idNKDataGridViewTextBoxColumn.HeaderText = "idNK";
            this.idNKDataGridViewTextBoxColumn.Name = "idNKDataGridViewTextBoxColumn";
            this.idNKDataGridViewTextBoxColumn.Visible = false;
            // 
            // tenSPDataGridViewTextBoxColumn
            // 
            this.tenSPDataGridViewTextBoxColumn.DataPropertyName = "tenSP";
            this.tenSPDataGridViewTextBoxColumn.FillWeight = 110F;
            this.tenSPDataGridViewTextBoxColumn.HeaderText = "Tên Sản Phẩm";
            this.tenSPDataGridViewTextBoxColumn.Name = "tenSPDataGridViewTextBoxColumn";
            this.tenSPDataGridViewTextBoxColumn.Width = 110;
            // 
            // soLuongDataGridViewTextBoxColumn
            // 
            this.soLuongDataGridViewTextBoxColumn.DataPropertyName = "soLuong";
            this.soLuongDataGridViewTextBoxColumn.HeaderText = "Số Lượng";
            this.soLuongDataGridViewTextBoxColumn.Name = "soLuongDataGridViewTextBoxColumn";
            // 
            // giaNhapDataGridViewTextBoxColumn
            // 
            this.giaNhapDataGridViewTextBoxColumn.DataPropertyName = "giaNhap";
            this.giaNhapDataGridViewTextBoxColumn.HeaderText = "Giá Nhập";
            this.giaNhapDataGridViewTextBoxColumn.Name = "giaNhapDataGridViewTextBoxColumn";
            // 
            // nhapKhoDataGridViewTextBoxColumn
            // 
            this.nhapKhoDataGridViewTextBoxColumn.DataPropertyName = "NhapKho";
            this.nhapKhoDataGridViewTextBoxColumn.HeaderText = "NhapKho";
            this.nhapKhoDataGridViewTextBoxColumn.Name = "nhapKhoDataGridViewTextBoxColumn";
            this.nhapKhoDataGridViewTextBoxColumn.Visible = false;
            // 
            // sanPhamDataGridViewTextBoxColumn
            // 
            this.sanPhamDataGridViewTextBoxColumn.DataPropertyName = "SanPham";
            this.sanPhamDataGridViewTextBoxColumn.HeaderText = "SanPham";
            this.sanPhamDataGridViewTextBoxColumn.Name = "sanPhamDataGridViewTextBoxColumn";
            this.sanPhamDataGridViewTextBoxColumn.Visible = false;
            // 
            // idMucLoiDataGridViewTextBoxColumn
            // 
            this.idMucLoiDataGridViewTextBoxColumn.DataPropertyName = "idMucLoi";
            this.idMucLoiDataGridViewTextBoxColumn.HeaderText = "idMucLoi";
            this.idMucLoiDataGridViewTextBoxColumn.Name = "idMucLoiDataGridViewTextBoxColumn";
            this.idMucLoiDataGridViewTextBoxColumn.Visible = false;
            // 
            // mucLoiDataGridViewTextBoxColumn
            // 
            this.mucLoiDataGridViewTextBoxColumn.DataPropertyName = "MucLoi";
            this.mucLoiDataGridViewTextBoxColumn.HeaderText = "MucLoi";
            this.mucLoiDataGridViewTextBoxColumn.Name = "mucLoiDataGridViewTextBoxColumn";
            this.mucLoiDataGridViewTextBoxColumn.Visible = false;
            // 
            // cTNKEntityBindingSource
            // 
            this.cTNKEntityBindingSource.DataSource = typeof(WinFormQuanLy.CTNKServiceReference.CTNKEntity);
            // 
            // FormChiTietPhieuNhap
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(394, 363);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.lbl_TongTien);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.dataCTNK);
            this.Controls.Add(this.dateTime);
            this.Controls.Add(this.label1);
            this.Name = "FormChiTietPhieuNhap";
            this.Text = "Chi Tiết Phiếu Nhập";
            ((System.ComponentModel.ISupportInitialize)(this.dataCTNK)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cTNKEntityBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridViewTextBoxColumn mucLoiDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn sanPhamDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nhapKhoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn giaNhapDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn soLuongDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn tenSPDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn idNKDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn idSPDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource cTNKEntityBindingSource;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label lbl_TongTien;
        private System.Windows.Forms.DataGridViewTextBoxColumn idMucLoiDataGridViewTextBoxColumn;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.DataGridView dataCTNK;
        private System.Windows.Forms.DateTimePicker dateTime;
        private System.Windows.Forms.Label label1;
    }
}