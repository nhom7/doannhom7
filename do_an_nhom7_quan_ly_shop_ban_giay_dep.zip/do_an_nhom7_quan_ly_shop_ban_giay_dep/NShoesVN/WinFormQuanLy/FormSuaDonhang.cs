﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WinFormQuanLy.SanPhamServiceReference;
using WinFormQuanLy.DonHangServiceReference;
using WinFormQuanLy.CTDHServiceReference;

namespace WinFormQuanLy
{
    public partial class FormSuaDonhang : Form
    {
        private DonHangServiceClient donHang_Client = new DonHangServiceClient();
        private CTDHServiceClient cTDH_Client = new CTDHServiceClient();
        private SanPhamServiceClient sanPham_Client = new SanPhamServiceClient();
        private DonHangEntity obj = new DonHangEntity();
        private List<CTDHEntity> listnew = new List<CTDHEntity>();
        public FormSuaDonhang(DonHangEntity obj)
        {
            this.obj = obj;
            InitializeComponent();
            LoadTrang();
        }

        private void LoadTrang()
        {
            txt_TenKH.Text = obj.tenKH.ToString();
            txt_NgayDat.Text = obj.ngayDH.ToShortDateString();

            var listSP = sanPham_Client.LayDSSP().ToList();
            cb_DanhSachSP.DataSource = listSP;
            cb_DanhSachSP.ValueMember = "id";
            cb_DanhSachSP.DisplayMember = "tenSP";
            cb_DanhSachSP.SelectedIndex = 0;

            var listSoLuong = Common.Business.ChuoiSoLuong(sanPham_Client.SoLuongDVSP(1));
            cb_SoLuongSP.DataSource = listSoLuong;
            cb_SoLuongSP.SelectedIndex = 0;

            listnew.Clear();
            listnew = cTDH_Client.LayDSChiTiet(obj.id).ToList();
            dataChiTietDH.DataSource = listnew;
            lbl_TongTien.Text = TinhTien_TongTien().ToString();
            lbl_TienGiam.Text = TinhTien_DuocGiam().ToString();
            lbl_ThanhTien.Text = TinhTien_ThanhTien().ToString();

        }

        // Tính [Lại] Tiền Đơn Hàng
        private decimal TinhTien_ThanhTien()
        {
            return TinhTien_TongTien() - TinhTien_DuocGiam();
        }
        private decimal TinhTien_TongTien()
        {
            decimal sum = 0;
            foreach (var i in listnew)
            {
                sum += i.giaNiemYet * i.soLuong;
            }
            return sum;
        }
        private decimal TinhTien_DuocGiam()
        {
            decimal sum = 0;
            foreach (var i in listnew)
            {
                sum += decimal.Parse((i.giaGiam * i.soLuong).ToString());
            }
            return sum;
        }

        /// <summary>
        /// Thêm Sản Phẩm vào Đơn Hàng
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btn_ThemSP_Click(object sender, EventArgs e)
        {
            CTDHEntity item = new CTDHEntity()
            {

                idDH = obj.id,
                idSP = int.Parse(cb_DanhSachSP.SelectedValue.ToString()),
                tenSanPham = sanPham_Client.LayTenSP(int.Parse(cb_DanhSachSP.SelectedValue.ToString())),
                giaNiemYet = sanPham_Client.LayGiaSP(int.Parse(cb_DanhSachSP.SelectedValue.ToString())),
                giaGiam = sanPham_Client.LayGiaGiam(int.Parse(cb_DanhSachSP.SelectedValue.ToString())),
                soLuong = int.Parse(cb_SoLuongSP.SelectedValue.ToString())
            };
            foreach (var i in listnew)
            {
                if (i.idSP == item.idSP)
                {
                    i.soLuong += item.soLuong;
                    if (i.soLuong > sanPham_Client.SoLuongDVSP(i.idSP))
                    {
                        MessageBox.Show("Số Lượng Bạn Thêm Đã Vượt Quá Trong Kho!");
                        return;
                    }
                    LoadDaTaCT();
                    return;
                }
            }

            listnew.Add(item);
            LoadDaTaCT();
        }

        private void LoadDaTaCT()
        {
            dataChiTietDH.DataSource = null;
            dataChiTietDH.DataSource = listnew;
            lbl_TongTien.Text = TinhTien_TongTien().ToString();
            lbl_TienGiam.Text = TinhTien_DuocGiam().ToString();
            lbl_ThanhTien.Text = TinhTien_ThanhTien().ToString();
        }

        /// <summary>
        /// Xóa Sản Phẩm Khỏi ĐƠn Hàng
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btn_Xoa_Click(object sender, EventArgs e)
        {
            var row = dataChiTietDH.CurrentRow;
            if(row!= null)
            {
                int idDH = int.Parse(row.Cells[0].Value.ToString());
                int idSP = int.Parse(row.Cells[1].Value.ToString());
                listnew.RemoveAll(p => p.idDH == idDH && p.idSP == idSP);
                LoadDaTaCT();
            }
            else
            {
                MessageBox.Show("Loi");
            }

        }

        private void btn_LamLai_Click(object sender, EventArgs e)
        {
            LoadTrang();
        }

        /// <summary>
        /// Cập nhật thông tin đơn hàng
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btn_Luu_Click(object sender, EventArgs e)
        {
            cTDH_Client.XoaCTDH(obj.id);
            DonHangEntity item = new DonHangEntity();
            item.id = obj.id;
            item.idKhachHang = obj.idKhachHang;
            item.ngayDH = obj.ngayDH;
            item.tenKH = obj.tenKH;
            item.thanhTien = TinhTien_ThanhTien();
            item.idTrangThai = 1;
            if(chk_DaXuLy.Checked)
            {
                item.idTrangThai = 2;
            }
            donHang_Client.CapNhatDonHang(item);

            // Cap Nhat Lai Chi Tiet Don Hang
            foreach(var i in listnew)
            {
                cTDH_Client.ThemChiTiet(i);
            }
            MessageBox.Show("Cập Nhật ĐƠn Hàng Thành Công!");
        }
    }
}
