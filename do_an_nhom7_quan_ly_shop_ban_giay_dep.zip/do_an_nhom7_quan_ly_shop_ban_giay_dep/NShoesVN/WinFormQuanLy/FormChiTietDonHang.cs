﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WinFormQuanLy.DonHangServiceReference;
using WinFormQuanLy.CTDHServiceReference;

namespace WinFormQuanLy
{
    public partial class FormChiTietDonHang : Form
    {
        private CTDHServiceClient cTDH_Client = new CTDHServiceClient();
        private List<CTDHEntity> list = new List<CTDHEntity>();
        private DonHangEntity obj = new DonHangEntity();
        public FormChiTietDonHang(DonHangEntity obj)
        {
            this.obj = obj;
            InitializeComponent();
            LoadTrang();
        }
        private void LoadTrang()
        {
            txt_TenKH.Text = obj.tenKH;
            txt_NgayDat.Text = obj.ngayDH.ToShortDateString();
            list = cTDH_Client.LayDSChiTiet(obj.id).ToList();
            dataChiTietDH.DataSource = list;
            lbl_TongTien.Text = TinhTien_TongTien().ToString();
            lbl_TienGiam.Text = TinhTien_DuocGiam().ToString();
            lbl_ThanhTien.Text = TinhTien_ThanhTien().ToString();
        }

        // Tính [Lại] Tiền Đơn Hàng
        private decimal TinhTien_ThanhTien()
        {
            return TinhTien_TongTien() - TinhTien_DuocGiam();
        }
        private decimal TinhTien_TongTien()
        {
            decimal sum = 0;
            foreach (var i in list)
            {
                sum += i.giaNiemYet * i.soLuong;
            }
            return sum;
        }
        private decimal TinhTien_DuocGiam()
        {
            decimal sum = 0;
            foreach (var i in list)
            {
                sum += decimal.Parse((i.giaGiam * i.soLuong).ToString());
            }
            return sum;
        }
    }
}
