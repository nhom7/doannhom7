﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormQuanLy
{
    public partial class DangNhap : Form
    {
        public DangNhap()
        {
            InitializeComponent();
        }

        private void btnDangNhap_Click(object sender, EventArgs e)
        {
            string tenDN = txtDN.Text.Trim();
            string matkhau = txtPW.Text.Trim();

            if(tenDN=="admin"&&matkhau=="123")
            {
                this.Hide();
                GiaoDien form = new GiaoDien();
                form.ShowDialog();
                this.Show();
            }
            lblCanhBao.Visible = true;
            txtDN.Text = "";
            txtPW.Text = "";
        }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
