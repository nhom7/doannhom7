﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WinFormQuanLy.NhapKhoServiceReference;
using WinFormQuanLy.CTNKServiceReference;

namespace WinFormQuanLy
{
    public partial class FormChiTietPhieuNhap : Form
    {
        private CTNKServiceClient cTNK_Client = new CTNKServiceClient();
        private List<CTNKEntity> list = new List<CTNKEntity>();
        private NhapKhoEntity obj = new NhapKhoEntity();
        
        public FormChiTietPhieuNhap(NhapKhoEntity obj)
        {
            this.obj = obj;
            InitializeComponent();
            LoadTrang();
        }

        private void LoadTrang()
        {
            dateTime.Value = obj.ngayNhapKho;
            list = cTNK_Client.LayDS_NK(obj.id).ToList();
            dataCTNK.DataSource = list;
            lbl_TongTien.Text = TongTienNhap().ToString();
        }
        private decimal TongTienNhap()
        {
            decimal sum = 0;
            foreach (var i in list)
            {
                sum += (decimal.Parse(i.giaNhap.ToString()) * i.soLuong);
            }
            return sum;
        }
    }
}
