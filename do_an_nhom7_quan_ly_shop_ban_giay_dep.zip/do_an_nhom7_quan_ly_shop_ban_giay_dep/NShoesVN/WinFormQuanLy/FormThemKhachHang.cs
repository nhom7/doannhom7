﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WinFormQuanLy.KhachHangServiceReference;

namespace WinFormQuanLy
{
    public partial class FormThemKhachHang : Form
    {
        private KhachHangServiceClient khachHang_Client = new KhachHangServiceClient();
        public FormThemKhachHang()
        {
            InitializeComponent();
        }

        private void KhongNhapChu(object sender, KeyPressEventArgs e)
        {
            Common.Business.KhongChoNhapChu(sender, e);
        }

        private void btn_Luu_Click(object sender, EventArgs e)
        {
            if(txt_TenKH.Text.Trim()=="")
            {
                MessageBox.Show("Tên Khách Hàng không được để trống!");
                return;
            }
            if(txt_SDT.Text.Trim()=="")
            {
                MessageBox.Show("Số Điện Thoại không được để trống!");
                return;
            }
            if(txt_Email.Text.Trim()=="")
            {
                MessageBox.Show("Email Không được để trống!");
                return;
            }
            if(Common.Business.KiemTraEmail(txt_Email.Text.Trim())==false)
            {
                MessageBox.Show("Email không hợp lệ!");
                return;
            }
            if(txt_DiaChi.Text.Trim()=="")
            {
                MessageBox.Show("Địa Chỉ không được để trống!");
                return;
            }

            KhachHangEntity item = new KhachHangEntity()
            {
                id = khachHang_Client.SoLuongKH() + 1,
                tenKH = txt_TenKH.Text.Trim(),
                diaChi = txt_DiaChi.Text.Trim(),
                email = txt_Email.Text.Trim(),
                sdt = txt_SDT.Text.Trim()
            };

            try
            {
                khachHang_Client.ThemKhachHang(item);
                MessageBox.Show("Thêm Mới khách hàng Thành công!");
                btn_LamLai_Click(this, e);
            }
            catch
            {
                MessageBox.Show("Lỗi khi thêm mới khách hàng!");
            }
        }

        private void btn_LamLai_Click(object sender, EventArgs e)
        {
            txt_TenKH.Text = "";
            txt_DiaChi.Text = "";
            txt_Email.Text = "";
            txt_SDT.Text = "";
        }
    }
}
