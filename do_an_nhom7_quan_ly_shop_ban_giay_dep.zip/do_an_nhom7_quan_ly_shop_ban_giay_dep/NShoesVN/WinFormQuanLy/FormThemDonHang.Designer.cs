﻿namespace WinFormQuanLy
{
    partial class FormThemDonHang
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.cbo_SoLuong = new System.Windows.Forms.ComboBox();
            this.btn_LamLaiDH = new System.Windows.Forms.Button();
            this.btn_ThemDH = new System.Windows.Forms.Button();
            this.lbl_Gia = new System.Windows.Forms.Label();
            this.dataCTDH = new System.Windows.Forms.DataGridView();
            this.btn_ThemSP = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.cbo_SanPham = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.cbo_KhachHang = new System.Windows.Forms.ComboBox();
            this.dtp_NgayDH = new System.Windows.Forms.DateTimePicker();
            this.label1 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.cTDHEntityBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.idDHDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.idSPDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tenSanPhamDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.soLuongDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.giaNiemYetDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.giaGiamDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.donHangDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sanPhamDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lblTongTien = new System.Windows.Forms.Label();
            this.lblSoTienGiam = new System.Windows.Forms.Label();
            this.lblThanhTien = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataCTDH)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cTDHEntityBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // cbo_SoLuong
            // 
            this.cbo_SoLuong.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbo_SoLuong.FormattingEnabled = true;
            this.cbo_SoLuong.Location = new System.Drawing.Point(192, 178);
            this.cbo_SoLuong.Name = "cbo_SoLuong";
            this.cbo_SoLuong.Size = new System.Drawing.Size(90, 28);
            this.cbo_SoLuong.TabIndex = 28;
            // 
            // btn_LamLaiDH
            // 
            this.btn_LamLaiDH.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_LamLaiDH.Location = new System.Drawing.Point(251, 540);
            this.btn_LamLaiDH.Name = "btn_LamLaiDH";
            this.btn_LamLaiDH.Size = new System.Drawing.Size(112, 35);
            this.btn_LamLaiDH.TabIndex = 27;
            this.btn_LamLaiDH.Text = "Làm Lại";
            this.btn_LamLaiDH.UseVisualStyleBackColor = true;
            this.btn_LamLaiDH.Click += new System.EventHandler(this.btn_LamLaiDH_Click);
            // 
            // btn_ThemDH
            // 
            this.btn_ThemDH.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ThemDH.Location = new System.Drawing.Point(105, 540);
            this.btn_ThemDH.Name = "btn_ThemDH";
            this.btn_ThemDH.Size = new System.Drawing.Size(112, 35);
            this.btn_ThemDH.TabIndex = 26;
            this.btn_ThemDH.Text = "Thêm";
            this.btn_ThemDH.UseVisualStyleBackColor = true;
            this.btn_ThemDH.Click += new System.EventHandler(this.btn_ThemDH_Click);
            // 
            // lbl_Gia
            // 
            this.lbl_Gia.AutoSize = true;
            this.lbl_Gia.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Gia.ForeColor = System.Drawing.Color.Blue;
            this.lbl_Gia.Location = new System.Drawing.Point(315, 496);
            this.lbl_Gia.Name = "lbl_Gia";
            this.lbl_Gia.Size = new System.Drawing.Size(43, 20);
            this.lbl_Gia.TabIndex = 25;
            this.lbl_Gia.Text = "VNĐ";
            // 
            // dataCTDH
            // 
            this.dataCTDH.AutoGenerateColumns = false;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataCTDH.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dataCTDH.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataCTDH.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idDHDataGridViewTextBoxColumn,
            this.idSPDataGridViewTextBoxColumn,
            this.tenSanPhamDataGridViewTextBoxColumn,
            this.soLuongDataGridViewTextBoxColumn,
            this.giaNiemYetDataGridViewTextBoxColumn,
            this.giaGiamDataGridViewTextBoxColumn,
            this.donHangDataGridViewTextBoxColumn,
            this.sanPhamDataGridViewTextBoxColumn});
            this.dataCTDH.DataSource = this.cTDHEntityBindingSource;
            this.dataCTDH.Location = new System.Drawing.Point(18, 223);
            this.dataCTDH.Name = "dataCTDH";
            this.dataCTDH.Size = new System.Drawing.Size(453, 192);
            this.dataCTDH.TabIndex = 23;
            // 
            // btn_ThemSP
            // 
            this.btn_ThemSP.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ThemSP.Location = new System.Drawing.Point(324, 178);
            this.btn_ThemSP.Name = "btn_ThemSP";
            this.btn_ThemSP.Size = new System.Drawing.Size(74, 28);
            this.btn_ThemSP.TabIndex = 22;
            this.btn_ThemSP.Text = "Thêm";
            this.btn_ThemSP.UseVisualStyleBackColor = true;
            this.btn_ThemSP.Click += new System.EventHandler(this.btn_ThemSP_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(44, 129);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(129, 20);
            this.label4.TabIndex = 21;
            this.label4.Text = "Chọn Sản Phẩm:";
            // 
            // cbo_SanPham
            // 
            this.cbo_SanPham.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbo_SanPham.FormattingEnabled = true;
            this.cbo_SanPham.Location = new System.Drawing.Point(192, 126);
            this.cbo_SanPham.Name = "cbo_SanPham";
            this.cbo_SanPham.Size = new System.Drawing.Size(206, 28);
            this.cbo_SanPham.TabIndex = 20;
            this.cbo_SanPham.SelectedIndexChanged += new System.EventHandler(this.cbo_SanPham_SelectedIndexChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(65, 496);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(96, 20);
            this.label3.TabIndex = 19;
            this.label3.Text = "Thành Tiền: ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(44, 71);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(126, 20);
            this.label2.TabIndex = 18;
            this.label2.Text = "Ngày Đơn Hàng:";
            // 
            // cbo_KhachHang
            // 
            this.cbo_KhachHang.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbo_KhachHang.FormattingEnabled = true;
            this.cbo_KhachHang.Location = new System.Drawing.Point(192, 18);
            this.cbo_KhachHang.Name = "cbo_KhachHang";
            this.cbo_KhachHang.Size = new System.Drawing.Size(206, 28);
            this.cbo_KhachHang.TabIndex = 17;
            // 
            // dtp_NgayDH
            // 
            this.dtp_NgayDH.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtp_NgayDH.Location = new System.Drawing.Point(192, 66);
            this.dtp_NgayDH.Name = "dtp_NgayDH";
            this.dtp_NgayDH.Size = new System.Drawing.Size(206, 26);
            this.dtp_NgayDH.TabIndex = 16;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(44, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(101, 20);
            this.label1.TabIndex = 15;
            this.label1.Text = "Khách Hàng:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(88, 181);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(82, 20);
            this.label5.TabIndex = 24;
            this.label5.Text = "Số Lượng:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(65, 429);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(83, 20);
            this.label6.TabIndex = 29;
            this.label6.Text = "Tổng Tiền:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(65, 463);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(109, 20);
            this.label7.TabIndex = 30;
            this.label7.Text = "Số Tiền Giảm:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Blue;
            this.label8.Location = new System.Drawing.Point(315, 429);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(43, 20);
            this.label8.TabIndex = 31;
            this.label8.Text = "VNĐ";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Blue;
            this.label9.Location = new System.Drawing.Point(315, 463);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(43, 20);
            this.label9.TabIndex = 32;
            this.label9.Text = "VNĐ";
            // 
            // cTDHEntityBindingSource
            // 
            this.cTDHEntityBindingSource.DataSource = typeof(WinFormQuanLy.CTDHServiceReference.CTDHEntity);
            // 
            // idDHDataGridViewTextBoxColumn
            // 
            this.idDHDataGridViewTextBoxColumn.DataPropertyName = "idDH";
            this.idDHDataGridViewTextBoxColumn.HeaderText = "idDH";
            this.idDHDataGridViewTextBoxColumn.Name = "idDHDataGridViewTextBoxColumn";
            this.idDHDataGridViewTextBoxColumn.Visible = false;
            // 
            // idSPDataGridViewTextBoxColumn
            // 
            this.idSPDataGridViewTextBoxColumn.DataPropertyName = "idSP";
            this.idSPDataGridViewTextBoxColumn.FillWeight = 50F;
            this.idSPDataGridViewTextBoxColumn.HeaderText = "Mã Sản Phẩm";
            this.idSPDataGridViewTextBoxColumn.Name = "idSPDataGridViewTextBoxColumn";
            this.idSPDataGridViewTextBoxColumn.Width = 50;
            // 
            // tenSanPhamDataGridViewTextBoxColumn
            // 
            this.tenSanPhamDataGridViewTextBoxColumn.DataPropertyName = "tenSanPham";
            this.tenSanPhamDataGridViewTextBoxColumn.FillWeight = 150F;
            this.tenSanPhamDataGridViewTextBoxColumn.HeaderText = "Tên Sản Phẩm";
            this.tenSanPhamDataGridViewTextBoxColumn.Name = "tenSanPhamDataGridViewTextBoxColumn";
            this.tenSanPhamDataGridViewTextBoxColumn.Width = 150;
            // 
            // soLuongDataGridViewTextBoxColumn
            // 
            this.soLuongDataGridViewTextBoxColumn.DataPropertyName = "soLuong";
            this.soLuongDataGridViewTextBoxColumn.FillWeight = 50F;
            this.soLuongDataGridViewTextBoxColumn.HeaderText = "Số Lượng";
            this.soLuongDataGridViewTextBoxColumn.Name = "soLuongDataGridViewTextBoxColumn";
            this.soLuongDataGridViewTextBoxColumn.Width = 50;
            // 
            // giaNiemYetDataGridViewTextBoxColumn
            // 
            this.giaNiemYetDataGridViewTextBoxColumn.DataPropertyName = "giaNiemYet";
            this.giaNiemYetDataGridViewTextBoxColumn.HeaderText = "Giá Niêm Yết";
            this.giaNiemYetDataGridViewTextBoxColumn.Name = "giaNiemYetDataGridViewTextBoxColumn";
            // 
            // giaGiamDataGridViewTextBoxColumn
            // 
            this.giaGiamDataGridViewTextBoxColumn.DataPropertyName = "giaGiam";
            this.giaGiamDataGridViewTextBoxColumn.FillWeight = 75F;
            this.giaGiamDataGridViewTextBoxColumn.HeaderText = "Số Tiền Giảm";
            this.giaGiamDataGridViewTextBoxColumn.Name = "giaGiamDataGridViewTextBoxColumn";
            this.giaGiamDataGridViewTextBoxColumn.Width = 75;
            // 
            // donHangDataGridViewTextBoxColumn
            // 
            this.donHangDataGridViewTextBoxColumn.DataPropertyName = "DonHang";
            this.donHangDataGridViewTextBoxColumn.HeaderText = "DonHang";
            this.donHangDataGridViewTextBoxColumn.Name = "donHangDataGridViewTextBoxColumn";
            this.donHangDataGridViewTextBoxColumn.Visible = false;
            // 
            // sanPhamDataGridViewTextBoxColumn
            // 
            this.sanPhamDataGridViewTextBoxColumn.DataPropertyName = "SanPham";
            this.sanPhamDataGridViewTextBoxColumn.HeaderText = "SanPham";
            this.sanPhamDataGridViewTextBoxColumn.Name = "sanPhamDataGridViewTextBoxColumn";
            this.sanPhamDataGridViewTextBoxColumn.Visible = false;
            // 
            // lblTongTien
            // 
            this.lblTongTien.AutoSize = true;
            this.lblTongTien.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTongTien.ForeColor = System.Drawing.Color.Blue;
            this.lblTongTien.Location = new System.Drawing.Point(205, 429);
            this.lblTongTien.Name = "lblTongTien";
            this.lblTongTien.Size = new System.Drawing.Size(60, 20);
            this.lblTongTien.TabIndex = 33;
            this.lblTongTien.Text = "label10";
            // 
            // lblSoTienGiam
            // 
            this.lblSoTienGiam.AutoSize = true;
            this.lblSoTienGiam.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSoTienGiam.ForeColor = System.Drawing.Color.Blue;
            this.lblSoTienGiam.Location = new System.Drawing.Point(205, 463);
            this.lblSoTienGiam.Name = "lblSoTienGiam";
            this.lblSoTienGiam.Size = new System.Drawing.Size(60, 20);
            this.lblSoTienGiam.TabIndex = 34;
            this.lblSoTienGiam.Text = "label11";
            // 
            // lblThanhTien
            // 
            this.lblThanhTien.AutoSize = true;
            this.lblThanhTien.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblThanhTien.ForeColor = System.Drawing.Color.Blue;
            this.lblThanhTien.Location = new System.Drawing.Point(205, 496);
            this.lblThanhTien.Name = "lblThanhTien";
            this.lblThanhTien.Size = new System.Drawing.Size(60, 20);
            this.lblThanhTien.TabIndex = 35;
            this.lblThanhTien.Text = "label12";
            // 
            // FormThemDonHang
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(493, 587);
            this.Controls.Add(this.lblThanhTien);
            this.Controls.Add(this.lblSoTienGiam);
            this.Controls.Add(this.lblTongTien);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.cbo_SoLuong);
            this.Controls.Add(this.btn_LamLaiDH);
            this.Controls.Add(this.btn_ThemDH);
            this.Controls.Add(this.lbl_Gia);
            this.Controls.Add(this.dataCTDH);
            this.Controls.Add(this.btn_ThemSP);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.cbo_SanPham);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.cbo_KhachHang);
            this.Controls.Add(this.dtp_NgayDH);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label5);
            this.Name = "FormThemDonHang";
            this.Text = "FormThemDonHang";
            ((System.ComponentModel.ISupportInitialize)(this.dataCTDH)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cTDHEntityBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cbo_SoLuong;
        private System.Windows.Forms.Button btn_LamLaiDH;
        private System.Windows.Forms.Button btn_ThemDH;
        private System.Windows.Forms.Label lbl_Gia;
        private System.Windows.Forms.DataGridView dataCTDH;
        private System.Windows.Forms.Button btn_ThemSP;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox cbo_SanPham;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cbo_KhachHang;
        private System.Windows.Forms.DateTimePicker dtp_NgayDH;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.BindingSource cTDHEntityBindingSource;
        private System.Windows.Forms.DataGridViewTextBoxColumn idDHDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn idSPDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn tenSanPhamDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn soLuongDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn giaNiemYetDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn giaGiamDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn donHangDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn sanPhamDataGridViewTextBoxColumn;
        private System.Windows.Forms.Label lblTongTien;
        private System.Windows.Forms.Label lblSoTienGiam;
        private System.Windows.Forms.Label lblThanhTien;
    }
}