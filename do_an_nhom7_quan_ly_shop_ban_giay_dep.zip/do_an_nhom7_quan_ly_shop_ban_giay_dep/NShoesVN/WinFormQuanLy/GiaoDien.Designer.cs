﻿namespace WinFormQuanLy
{
    partial class GiaoDien
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.tabControl = new System.Windows.Forms.TabControl();
            this.tabSanPham = new System.Windows.Forms.TabPage();
            this.SP_btn_Them = new System.Windows.Forms.Button();
            this.SP_btn_Refresh = new System.Windows.Forms.Button();
            this.dataSanPham = new System.Windows.Forms.DataGridView();
            this.idDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.idLoaiSPDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.idMauSacDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tenSPDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.giaNiemYetDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.giaGiamDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.kichThuocDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.soLuongDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.hinhAnhDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.spDBDataGridViewCheckBoxColumn = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.spMoiDataGridViewCheckBoxColumn = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.loaiSanPhamDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sanPhamEntityBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.SP_btn_TimKiem = new System.Windows.Forms.Button();
            this.SP_cb_MauSac = new System.Windows.Forms.ComboBox();
            this.SP_cb_Gia = new System.Windows.Forms.ComboBox();
            this.SP_cb_LoaiSP = new System.Windows.Forms.ComboBox();
            this.SP_txt_KichThuoc = new System.Windows.Forms.TextBox();
            this.SP_txt_TenSP = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tabLoaiSP = new System.Windows.Forms.TabPage();
            this.LoaiSP_btn_Refresh = new System.Windows.Forms.Button();
            this.LoaiSP_btn_Them = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.LoaiSP_btn_Tim = new System.Windows.Forms.Button();
            this.LoaiSP_txt_TenLoaiSP = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.dataLoaiSP = new System.Windows.Forms.DataGridView();
            this.idDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tenLoaiSPDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.loaiSanPhamEntityBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tabDonHang = new System.Windows.Forms.TabPage();
            this.dataDonHang = new System.Windows.Forms.DataGridView();
            this.idDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.idKhachHangDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tenKHDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ngayDHDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.idTrangThaiDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.thanhTienDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.trangThaiDHDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.khachHangDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.donHangEntityBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.DH_btn_Refresh = new System.Windows.Forms.Button();
            this.DH_btn_TaoHoaDon = new System.Windows.Forms.Button();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.DH_btn_TimKiem = new System.Windows.Forms.Button();
            this.DH_chk_DaXL = new System.Windows.Forms.CheckBox();
            this.DH_chk_ChoXL = new System.Windows.Forms.CheckBox();
            this.DH_dtp_DenNgay = new System.Windows.Forms.DateTimePicker();
            this.DH_dtp_TuNgay = new System.Windows.Forms.DateTimePicker();
            this.DH_txt_TenKH = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.tabKhachHang = new System.Windows.Forms.TabPage();
            this.dataKhachHang = new System.Windows.Forms.DataGridView();
            this.idDataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tenKHDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sdtDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.diaChiDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.emailDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tenDNDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.matKhauDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.khachHangEntityBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.KH_btn_Refresh = new System.Windows.Forms.Button();
            this.KH_btn_Them = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.KH_btn_TimKiem = new System.Windows.Forms.Button();
            this.KH_txt_Email = new System.Windows.Forms.TextBox();
            this.KH_txt_SDT = new System.Windows.Forms.TextBox();
            this.KH_txt_TenKH = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.tabNhapKho = new System.Windows.Forms.TabPage();
            this.NK_btn_Them = new System.Windows.Forms.Button();
            this.dataNhapKho = new System.Windows.Forms.DataGridView();
            this.idDataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ngayNhapKhoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tongTienDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nhapKhoEntityBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.NK_btn_Tim = new System.Windows.Forms.Button();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.NK_btn_Refresh = new System.Windows.Forms.Button();
            this.tabThongKe = new System.Windows.Forms.TabPage();
            this.TK_btn_Refresh = new System.Windows.Forms.Button();
            this.dataThongKe = new System.Windows.Forms.DataGridView();
            this.idDataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.idLoaiSPDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.idMauSacDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tenSPDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.soLuongDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.giaNiemYetDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.giaGiamDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.hinhAnhDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.kichThuocDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.spDBDataGridViewCheckBoxColumn1 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.spMoiDataGridViewCheckBoxColumn1 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.loaiSanPhamDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sanPhamEntityBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.TK_btn_thongke = new System.Windows.Forms.Button();
            this.TK_dtp_DenNgay = new System.Windows.Forms.DateTimePicker();
            this.TK_dtp_TuNgay = new System.Windows.Forms.DateTimePicker();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.tabControl.SuspendLayout();
            this.tabSanPham.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataSanPham)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sanPhamEntityBindingSource)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.tabLoaiSP.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataLoaiSP)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.loaiSanPhamEntityBindingSource)).BeginInit();
            this.tabDonHang.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataDonHang)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.donHangEntityBindingSource)).BeginInit();
            this.groupBox4.SuspendLayout();
            this.tabKhachHang.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataKhachHang)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.khachHangEntityBindingSource)).BeginInit();
            this.groupBox3.SuspendLayout();
            this.tabNhapKho.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataNhapKho)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nhapKhoEntityBindingSource)).BeginInit();
            this.groupBox5.SuspendLayout();
            this.tabThongKe.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataThongKe)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sanPhamEntityBindingSource1)).BeginInit();
            this.groupBox6.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl
            // 
            this.tabControl.Controls.Add(this.tabSanPham);
            this.tabControl.Controls.Add(this.tabLoaiSP);
            this.tabControl.Controls.Add(this.tabDonHang);
            this.tabControl.Controls.Add(this.tabKhachHang);
            this.tabControl.Controls.Add(this.tabNhapKho);
            this.tabControl.Controls.Add(this.tabThongKe);
            this.tabControl.ItemSize = new System.Drawing.Size(58, 30);
            this.tabControl.Location = new System.Drawing.Point(1, 1);
            this.tabControl.Name = "tabControl";
            this.tabControl.SelectedIndex = 0;
            this.tabControl.Size = new System.Drawing.Size(1001, 480);
            this.tabControl.TabIndex = 0;
            this.tabControl.SelectedIndexChanged += new System.EventHandler(this.tabControl_TabIndexChanged);
            this.tabControl.TabIndexChanged += new System.EventHandler(this.tabControl_TabIndexChanged);
            // 
            // tabSanPham
            // 
            this.tabSanPham.Controls.Add(this.SP_btn_Them);
            this.tabSanPham.Controls.Add(this.SP_btn_Refresh);
            this.tabSanPham.Controls.Add(this.dataSanPham);
            this.tabSanPham.Controls.Add(this.groupBox1);
            this.tabSanPham.Location = new System.Drawing.Point(4, 34);
            this.tabSanPham.Name = "tabSanPham";
            this.tabSanPham.Padding = new System.Windows.Forms.Padding(3);
            this.tabSanPham.Size = new System.Drawing.Size(993, 442);
            this.tabSanPham.TabIndex = 0;
            this.tabSanPham.Text = "Sản Phẩm";
            this.tabSanPham.UseVisualStyleBackColor = true;
            // 
            // SP_btn_Them
            // 
            this.SP_btn_Them.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SP_btn_Them.Location = new System.Drawing.Point(18, 22);
            this.SP_btn_Them.Name = "SP_btn_Them";
            this.SP_btn_Them.Size = new System.Drawing.Size(124, 41);
            this.SP_btn_Them.TabIndex = 6;
            this.SP_btn_Them.Text = "Thêm";
            this.SP_btn_Them.UseVisualStyleBackColor = true;
            this.SP_btn_Them.Click += new System.EventHandler(this.SP_btn_Them_Click);
            // 
            // SP_btn_Refresh
            // 
            this.SP_btn_Refresh.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SP_btn_Refresh.Location = new System.Drawing.Point(180, 22);
            this.SP_btn_Refresh.Name = "SP_btn_Refresh";
            this.SP_btn_Refresh.Size = new System.Drawing.Size(127, 41);
            this.SP_btn_Refresh.TabIndex = 4;
            this.SP_btn_Refresh.Text = "Refresh";
            this.SP_btn_Refresh.UseVisualStyleBackColor = true;
            this.SP_btn_Refresh.Click += new System.EventHandler(this.SP_btn_Refresh_Click);
            // 
            // dataSanPham
            // 
            this.dataSanPham.AutoGenerateColumns = false;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.RoyalBlue;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataSanPham.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dataSanPham.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataSanPham.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idDataGridViewTextBoxColumn,
            this.idLoaiSPDataGridViewTextBoxColumn,
            this.idMauSacDataGridViewTextBoxColumn,
            this.tenSPDataGridViewTextBoxColumn,
            this.giaNiemYetDataGridViewTextBoxColumn,
            this.giaGiamDataGridViewTextBoxColumn,
            this.kichThuocDataGridViewTextBoxColumn,
            this.dataGridViewTextBoxColumn2,
            this.soLuongDataGridViewTextBoxColumn,
            this.hinhAnhDataGridViewTextBoxColumn,
            this.spDBDataGridViewCheckBoxColumn,
            this.spMoiDataGridViewCheckBoxColumn,
            this.loaiSanPhamDataGridViewTextBoxColumn,
            this.dataGridViewTextBoxColumn1});
            this.dataSanPham.DataSource = this.sanPhamEntityBindingSource;
            this.dataSanPham.Location = new System.Drawing.Point(347, 22);
            this.dataSanPham.Name = "dataSanPham";
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.Desktop;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataSanPham.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dataSanPham.Size = new System.Drawing.Size(638, 409);
            this.dataSanPham.TabIndex = 3;
            this.dataSanPham.CellMouseDoubleClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dataSanPham_CellMouseDoubleClick);
            // 
            // idDataGridViewTextBoxColumn
            // 
            this.idDataGridViewTextBoxColumn.DataPropertyName = "id";
            this.idDataGridViewTextBoxColumn.HeaderText = "id";
            this.idDataGridViewTextBoxColumn.Name = "idDataGridViewTextBoxColumn";
            this.idDataGridViewTextBoxColumn.Visible = false;
            // 
            // idLoaiSPDataGridViewTextBoxColumn
            // 
            this.idLoaiSPDataGridViewTextBoxColumn.DataPropertyName = "idLoaiSP";
            this.idLoaiSPDataGridViewTextBoxColumn.HeaderText = "idLoaiSP";
            this.idLoaiSPDataGridViewTextBoxColumn.Name = "idLoaiSPDataGridViewTextBoxColumn";
            this.idLoaiSPDataGridViewTextBoxColumn.Visible = false;
            // 
            // idMauSacDataGridViewTextBoxColumn
            // 
            this.idMauSacDataGridViewTextBoxColumn.DataPropertyName = "idMauSac";
            this.idMauSacDataGridViewTextBoxColumn.HeaderText = "idMauSac";
            this.idMauSacDataGridViewTextBoxColumn.Name = "idMauSacDataGridViewTextBoxColumn";
            this.idMauSacDataGridViewTextBoxColumn.Visible = false;
            // 
            // tenSPDataGridViewTextBoxColumn
            // 
            this.tenSPDataGridViewTextBoxColumn.DataPropertyName = "tenSP";
            this.tenSPDataGridViewTextBoxColumn.FillWeight = 150F;
            this.tenSPDataGridViewTextBoxColumn.HeaderText = "Tên Sản Phẩm";
            this.tenSPDataGridViewTextBoxColumn.Name = "tenSPDataGridViewTextBoxColumn";
            this.tenSPDataGridViewTextBoxColumn.Width = 150;
            // 
            // giaNiemYetDataGridViewTextBoxColumn
            // 
            this.giaNiemYetDataGridViewTextBoxColumn.DataPropertyName = "giaNiemYet";
            this.giaNiemYetDataGridViewTextBoxColumn.HeaderText = "Giá Niêm Yết";
            this.giaNiemYetDataGridViewTextBoxColumn.Name = "giaNiemYetDataGridViewTextBoxColumn";
            // 
            // giaGiamDataGridViewTextBoxColumn
            // 
            this.giaGiamDataGridViewTextBoxColumn.DataPropertyName = "giaGiam";
            this.giaGiamDataGridViewTextBoxColumn.HeaderText = "Giá Giảm";
            this.giaGiamDataGridViewTextBoxColumn.Name = "giaGiamDataGridViewTextBoxColumn";
            // 
            // kichThuocDataGridViewTextBoxColumn
            // 
            this.kichThuocDataGridViewTextBoxColumn.DataPropertyName = "kichThuoc";
            this.kichThuocDataGridViewTextBoxColumn.HeaderText = "Kích Thước";
            this.kichThuocDataGridViewTextBoxColumn.Name = "kichThuocDataGridViewTextBoxColumn";
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "mieuTa";
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.Black;
            this.dataGridViewTextBoxColumn2.DefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridViewTextBoxColumn2.HeaderText = "Mô Tả";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // soLuongDataGridViewTextBoxColumn
            // 
            this.soLuongDataGridViewTextBoxColumn.DataPropertyName = "soLuong";
            this.soLuongDataGridViewTextBoxColumn.HeaderText = "Số Lượng";
            this.soLuongDataGridViewTextBoxColumn.Name = "soLuongDataGridViewTextBoxColumn";
            // 
            // hinhAnhDataGridViewTextBoxColumn
            // 
            this.hinhAnhDataGridViewTextBoxColumn.DataPropertyName = "hinhAnh";
            this.hinhAnhDataGridViewTextBoxColumn.HeaderText = "Hình Ảnh";
            this.hinhAnhDataGridViewTextBoxColumn.Name = "hinhAnhDataGridViewTextBoxColumn";
            // 
            // spDBDataGridViewCheckBoxColumn
            // 
            this.spDBDataGridViewCheckBoxColumn.DataPropertyName = "spDB";
            this.spDBDataGridViewCheckBoxColumn.FillWeight = 50F;
            this.spDBDataGridViewCheckBoxColumn.HeaderText = "Đặc Biệt";
            this.spDBDataGridViewCheckBoxColumn.Name = "spDBDataGridViewCheckBoxColumn";
            this.spDBDataGridViewCheckBoxColumn.Width = 50;
            // 
            // spMoiDataGridViewCheckBoxColumn
            // 
            this.spMoiDataGridViewCheckBoxColumn.DataPropertyName = "spMoi";
            this.spMoiDataGridViewCheckBoxColumn.FillWeight = 50F;
            this.spMoiDataGridViewCheckBoxColumn.HeaderText = "Mới";
            this.spMoiDataGridViewCheckBoxColumn.Name = "spMoiDataGridViewCheckBoxColumn";
            this.spMoiDataGridViewCheckBoxColumn.Width = 50;
            // 
            // loaiSanPhamDataGridViewTextBoxColumn
            // 
            this.loaiSanPhamDataGridViewTextBoxColumn.DataPropertyName = "LoaiSanPham";
            this.loaiSanPhamDataGridViewTextBoxColumn.HeaderText = "LoaiSanPham";
            this.loaiSanPhamDataGridViewTextBoxColumn.Name = "loaiSanPhamDataGridViewTextBoxColumn";
            this.loaiSanPhamDataGridViewTextBoxColumn.Visible = false;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "MauSac";
            this.dataGridViewTextBoxColumn1.HeaderText = "MauSac";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.Visible = false;
            // 
            // sanPhamEntityBindingSource
            // 
            this.sanPhamEntityBindingSource.DataSource = typeof(WinFormQuanLy.SanPhamServiceReference.SanPhamEntity);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.SP_btn_TimKiem);
            this.groupBox1.Controls.Add(this.SP_cb_MauSac);
            this.groupBox1.Controls.Add(this.SP_cb_Gia);
            this.groupBox1.Controls.Add(this.SP_cb_LoaiSP);
            this.groupBox1.Controls.Add(this.SP_txt_KichThuoc);
            this.groupBox1.Controls.Add(this.SP_txt_TenSP);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(7, 90);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(320, 341);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Tìm Kiếm Sản Phẩm";
            // 
            // SP_btn_TimKiem
            // 
            this.SP_btn_TimKiem.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SP_btn_TimKiem.Location = new System.Drawing.Point(115, 277);
            this.SP_btn_TimKiem.Name = "SP_btn_TimKiem";
            this.SP_btn_TimKiem.Size = new System.Drawing.Size(115, 41);
            this.SP_btn_TimKiem.TabIndex = 14;
            this.SP_btn_TimKiem.Text = "Tìm Kiếm";
            this.SP_btn_TimKiem.UseVisualStyleBackColor = true;
            this.SP_btn_TimKiem.Click += new System.EventHandler(this.SP_btn_TimKiem_Click);
            // 
            // SP_cb_MauSac
            // 
            this.SP_cb_MauSac.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SP_cb_MauSac.FormattingEnabled = true;
            this.SP_cb_MauSac.Items.AddRange(new object[] {
            "Đen",
            "Đỏ",
            "Xám",
            "Xanh Dương",
            "Vàng",
            "Tím",
            "Trắng",
            "Nâu",
            "Xanh Lá Cây"});
            this.SP_cb_MauSac.Location = new System.Drawing.Point(115, 187);
            this.SP_cb_MauSac.Name = "SP_cb_MauSac";
            this.SP_cb_MauSac.Size = new System.Drawing.Size(185, 28);
            this.SP_cb_MauSac.TabIndex = 13;
            // 
            // SP_cb_Gia
            // 
            this.SP_cb_Gia.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SP_cb_Gia.FormattingEnabled = true;
            this.SP_cb_Gia.Items.AddRange(new object[] {
            "100 VND >",
            "100 - 200 VND",
            "200 - 300 VND",
            "300 - 400 VND",
            "400 - 500 VND",
            "> 500 VND"});
            this.SP_cb_Gia.Location = new System.Drawing.Point(115, 137);
            this.SP_cb_Gia.Name = "SP_cb_Gia";
            this.SP_cb_Gia.Size = new System.Drawing.Size(185, 28);
            this.SP_cb_Gia.TabIndex = 12;
            // 
            // SP_cb_LoaiSP
            // 
            this.SP_cb_LoaiSP.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SP_cb_LoaiSP.FormattingEnabled = true;
            this.SP_cb_LoaiSP.Location = new System.Drawing.Point(115, 88);
            this.SP_cb_LoaiSP.Name = "SP_cb_LoaiSP";
            this.SP_cb_LoaiSP.Size = new System.Drawing.Size(185, 28);
            this.SP_cb_LoaiSP.TabIndex = 11;
            // 
            // SP_txt_KichThuoc
            // 
            this.SP_txt_KichThuoc.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SP_txt_KichThuoc.Location = new System.Drawing.Point(115, 232);
            this.SP_txt_KichThuoc.Name = "SP_txt_KichThuoc";
            this.SP_txt_KichThuoc.Size = new System.Drawing.Size(185, 26);
            this.SP_txt_KichThuoc.TabIndex = 7;
            this.SP_txt_KichThuoc.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.KhongNhapChu);
            // 
            // SP_txt_TenSP
            // 
            this.SP_txt_TenSP.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SP_txt_TenSP.Location = new System.Drawing.Point(115, 40);
            this.SP_txt_TenSP.Name = "SP_txt_TenSP";
            this.SP_txt_TenSP.Size = new System.Drawing.Size(185, 26);
            this.SP_txt_TenSP.TabIndex = 5;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(14, 230);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(95, 20);
            this.label5.TabIndex = 4;
            this.label5.Text = "Kích Thước: ";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(15, 185);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(80, 20);
            this.label4.TabIndex = 3;
            this.label4.Text = "Màu Sắc: ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(14, 135);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(72, 20);
            this.label3.TabIndex = 2;
            this.label3.Text = "Mức Giá:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(14, 89);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(79, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "Loại Giày:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(14, 40);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(80, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Tên Giày: ";
            // 
            // tabLoaiSP
            // 
            this.tabLoaiSP.Controls.Add(this.LoaiSP_btn_Refresh);
            this.tabLoaiSP.Controls.Add(this.LoaiSP_btn_Them);
            this.tabLoaiSP.Controls.Add(this.groupBox2);
            this.tabLoaiSP.Controls.Add(this.dataLoaiSP);
            this.tabLoaiSP.Location = new System.Drawing.Point(4, 34);
            this.tabLoaiSP.Name = "tabLoaiSP";
            this.tabLoaiSP.Padding = new System.Windows.Forms.Padding(3);
            this.tabLoaiSP.Size = new System.Drawing.Size(993, 442);
            this.tabLoaiSP.TabIndex = 1;
            this.tabLoaiSP.Text = "Loại Sản Phẩm";
            this.tabLoaiSP.UseVisualStyleBackColor = true;
            // 
            // LoaiSP_btn_Refresh
            // 
            this.LoaiSP_btn_Refresh.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LoaiSP_btn_Refresh.Location = new System.Drawing.Point(586, 77);
            this.LoaiSP_btn_Refresh.Name = "LoaiSP_btn_Refresh";
            this.LoaiSP_btn_Refresh.Size = new System.Drawing.Size(75, 32);
            this.LoaiSP_btn_Refresh.TabIndex = 3;
            this.LoaiSP_btn_Refresh.Text = "Refresh";
            this.LoaiSP_btn_Refresh.UseVisualStyleBackColor = true;
            this.LoaiSP_btn_Refresh.Click += new System.EventHandler(this.LoaiSP_btn_Refresh_Click);
            // 
            // LoaiSP_btn_Them
            // 
            this.LoaiSP_btn_Them.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LoaiSP_btn_Them.Location = new System.Drawing.Point(586, 28);
            this.LoaiSP_btn_Them.Name = "LoaiSP_btn_Them";
            this.LoaiSP_btn_Them.Size = new System.Drawing.Size(75, 33);
            this.LoaiSP_btn_Them.TabIndex = 2;
            this.LoaiSP_btn_Them.Text = "Thêm";
            this.LoaiSP_btn_Them.UseVisualStyleBackColor = true;
            this.LoaiSP_btn_Them.Click += new System.EventHandler(this.LoaiSP_btn_Them_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.LoaiSP_btn_Tim);
            this.groupBox2.Controls.Add(this.LoaiSP_txt_TenLoaiSP);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Location = new System.Drawing.Point(51, 18);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(518, 91);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Tìm Kiếm";
            // 
            // LoaiSP_btn_Tim
            // 
            this.LoaiSP_btn_Tim.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LoaiSP_btn_Tim.Location = new System.Drawing.Point(412, 31);
            this.LoaiSP_btn_Tim.Name = "LoaiSP_btn_Tim";
            this.LoaiSP_btn_Tim.Size = new System.Drawing.Size(75, 28);
            this.LoaiSP_btn_Tim.TabIndex = 4;
            this.LoaiSP_btn_Tim.Text = "Tìm Kiếm";
            this.LoaiSP_btn_Tim.UseVisualStyleBackColor = true;
            this.LoaiSP_btn_Tim.Click += new System.EventHandler(this.LoaiSP_btn_Tim_Click);
            // 
            // LoaiSP_txt_TenLoaiSP
            // 
            this.LoaiSP_txt_TenLoaiSP.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LoaiSP_txt_TenLoaiSP.Location = new System.Drawing.Point(182, 33);
            this.LoaiSP_txt_TenLoaiSP.Name = "LoaiSP_txt_TenLoaiSP";
            this.LoaiSP_txt_TenLoaiSP.Size = new System.Drawing.Size(203, 26);
            this.LoaiSP_txt_TenLoaiSP.TabIndex = 1;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(20, 36);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(156, 20);
            this.label6.TabIndex = 0;
            this.label6.Text = "Tên Loại Sản Phẩm: ";
            // 
            // dataLoaiSP
            // 
            this.dataLoaiSP.AutoGenerateColumns = false;
            this.dataLoaiSP.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataLoaiSP.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idDataGridViewTextBoxColumn1,
            this.tenLoaiSPDataGridViewTextBoxColumn,
            this.dataGridViewTextBoxColumn3});
            this.dataLoaiSP.DataSource = this.loaiSanPhamEntityBindingSource;
            this.dataLoaiSP.Location = new System.Drawing.Point(51, 127);
            this.dataLoaiSP.Name = "dataLoaiSP";
            this.dataLoaiSP.Size = new System.Drawing.Size(610, 291);
            this.dataLoaiSP.TabIndex = 0;
            this.dataLoaiSP.CellMouseDoubleClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dataLoaiSP_CellMouseDoubleClick);
            // 
            // idDataGridViewTextBoxColumn1
            // 
            this.idDataGridViewTextBoxColumn1.DataPropertyName = "id";
            this.idDataGridViewTextBoxColumn1.HeaderText = "Mã Loại";
            this.idDataGridViewTextBoxColumn1.Name = "idDataGridViewTextBoxColumn1";
            // 
            // tenLoaiSPDataGridViewTextBoxColumn
            // 
            this.tenLoaiSPDataGridViewTextBoxColumn.DataPropertyName = "tenLoaiSP";
            this.tenLoaiSPDataGridViewTextBoxColumn.FillWeight = 200F;
            this.tenLoaiSPDataGridViewTextBoxColumn.HeaderText = "Tên Loại Sản Phẩm";
            this.tenLoaiSPDataGridViewTextBoxColumn.Name = "tenLoaiSPDataGridViewTextBoxColumn";
            this.tenLoaiSPDataGridViewTextBoxColumn.Width = 200;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "mieuTa";
            this.dataGridViewTextBoxColumn3.FillWeight = 300F;
            this.dataGridViewTextBoxColumn3.HeaderText = "Mô Tả";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.Width = 300;
            // 
            // loaiSanPhamEntityBindingSource
            // 
            this.loaiSanPhamEntityBindingSource.DataSource = typeof(WinFormQuanLy.LoaiSanPhamServiceReference.LoaiSanPhamEntity);
            // 
            // tabDonHang
            // 
            this.tabDonHang.Controls.Add(this.dataDonHang);
            this.tabDonHang.Controls.Add(this.DH_btn_Refresh);
            this.tabDonHang.Controls.Add(this.DH_btn_TaoHoaDon);
            this.tabDonHang.Controls.Add(this.groupBox4);
            this.tabDonHang.Location = new System.Drawing.Point(4, 34);
            this.tabDonHang.Name = "tabDonHang";
            this.tabDonHang.Size = new System.Drawing.Size(993, 442);
            this.tabDonHang.TabIndex = 2;
            this.tabDonHang.Text = "Đơn Hàng";
            this.tabDonHang.UseVisualStyleBackColor = true;
            // 
            // dataDonHang
            // 
            this.dataDonHang.AutoGenerateColumns = false;
            this.dataDonHang.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataDonHang.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idDataGridViewTextBoxColumn2,
            this.idKhachHangDataGridViewTextBoxColumn,
            this.tenKHDataGridViewTextBoxColumn,
            this.ngayDHDataGridViewTextBoxColumn,
            this.idTrangThaiDataGridViewTextBoxColumn,
            this.thanhTienDataGridViewTextBoxColumn,
            this.trangThaiDHDataGridViewTextBoxColumn,
            this.khachHangDataGridViewTextBoxColumn});
            this.dataDonHang.DataSource = this.donHangEntityBindingSource;
            this.dataDonHang.Location = new System.Drawing.Point(404, 38);
            this.dataDonHang.Name = "dataDonHang";
            this.dataDonHang.Size = new System.Drawing.Size(568, 351);
            this.dataDonHang.TabIndex = 12;
            this.dataDonHang.CellMouseDoubleClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dataDonHang_CellMouseDoubleClick);
            // 
            // idDataGridViewTextBoxColumn2
            // 
            this.idDataGridViewTextBoxColumn2.DataPropertyName = "id";
            this.idDataGridViewTextBoxColumn2.FillWeight = 50F;
            this.idDataGridViewTextBoxColumn2.HeaderText = "Mã Đơn Hàng";
            this.idDataGridViewTextBoxColumn2.Name = "idDataGridViewTextBoxColumn2";
            this.idDataGridViewTextBoxColumn2.Width = 50;
            // 
            // idKhachHangDataGridViewTextBoxColumn
            // 
            this.idKhachHangDataGridViewTextBoxColumn.DataPropertyName = "idKhachHang";
            this.idKhachHangDataGridViewTextBoxColumn.HeaderText = "idKhachHang";
            this.idKhachHangDataGridViewTextBoxColumn.Name = "idKhachHangDataGridViewTextBoxColumn";
            this.idKhachHangDataGridViewTextBoxColumn.Visible = false;
            // 
            // tenKHDataGridViewTextBoxColumn
            // 
            this.tenKHDataGridViewTextBoxColumn.DataPropertyName = "tenKH";
            this.tenKHDataGridViewTextBoxColumn.FillWeight = 150F;
            this.tenKHDataGridViewTextBoxColumn.HeaderText = "Tên Khách Hàng";
            this.tenKHDataGridViewTextBoxColumn.Name = "tenKHDataGridViewTextBoxColumn";
            this.tenKHDataGridViewTextBoxColumn.Width = 150;
            // 
            // ngayDHDataGridViewTextBoxColumn
            // 
            this.ngayDHDataGridViewTextBoxColumn.DataPropertyName = "ngayDH";
            this.ngayDHDataGridViewTextBoxColumn.HeaderText = "Ngày Đơn Hàng";
            this.ngayDHDataGridViewTextBoxColumn.Name = "ngayDHDataGridViewTextBoxColumn";
            // 
            // idTrangThaiDataGridViewTextBoxColumn
            // 
            this.idTrangThaiDataGridViewTextBoxColumn.DataPropertyName = "idTrangThai";
            this.idTrangThaiDataGridViewTextBoxColumn.HeaderText = "Trạng Thái Đơn Hàng";
            this.idTrangThaiDataGridViewTextBoxColumn.Name = "idTrangThaiDataGridViewTextBoxColumn";
            // 
            // thanhTienDataGridViewTextBoxColumn
            // 
            this.thanhTienDataGridViewTextBoxColumn.DataPropertyName = "thanhTien";
            this.thanhTienDataGridViewTextBoxColumn.FillWeight = 150F;
            this.thanhTienDataGridViewTextBoxColumn.HeaderText = "Thành Tiền";
            this.thanhTienDataGridViewTextBoxColumn.Name = "thanhTienDataGridViewTextBoxColumn";
            this.thanhTienDataGridViewTextBoxColumn.Width = 150;
            // 
            // trangThaiDHDataGridViewTextBoxColumn
            // 
            this.trangThaiDHDataGridViewTextBoxColumn.DataPropertyName = "TrangThaiDH";
            this.trangThaiDHDataGridViewTextBoxColumn.HeaderText = "TrangThaiDH";
            this.trangThaiDHDataGridViewTextBoxColumn.Name = "trangThaiDHDataGridViewTextBoxColumn";
            this.trangThaiDHDataGridViewTextBoxColumn.Visible = false;
            // 
            // khachHangDataGridViewTextBoxColumn
            // 
            this.khachHangDataGridViewTextBoxColumn.DataPropertyName = "KhachHang";
            this.khachHangDataGridViewTextBoxColumn.HeaderText = "KhachHang";
            this.khachHangDataGridViewTextBoxColumn.Name = "khachHangDataGridViewTextBoxColumn";
            this.khachHangDataGridViewTextBoxColumn.Visible = false;
            // 
            // donHangEntityBindingSource
            // 
            this.donHangEntityBindingSource.DataSource = typeof(WinFormQuanLy.DonHangServiceReference.DonHangEntity);
            // 
            // DH_btn_Refresh
            // 
            this.DH_btn_Refresh.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DH_btn_Refresh.Location = new System.Drawing.Point(209, 38);
            this.DH_btn_Refresh.Name = "DH_btn_Refresh";
            this.DH_btn_Refresh.Size = new System.Drawing.Size(95, 34);
            this.DH_btn_Refresh.TabIndex = 10;
            this.DH_btn_Refresh.Text = "Refresh";
            this.DH_btn_Refresh.UseVisualStyleBackColor = true;
            this.DH_btn_Refresh.Click += new System.EventHandler(this.DH_btn_Refresh_Click);
            // 
            // DH_btn_TaoHoaDon
            // 
            this.DH_btn_TaoHoaDon.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DH_btn_TaoHoaDon.Location = new System.Drawing.Point(40, 38);
            this.DH_btn_TaoHoaDon.Name = "DH_btn_TaoHoaDon";
            this.DH_btn_TaoHoaDon.Size = new System.Drawing.Size(133, 34);
            this.DH_btn_TaoHoaDon.TabIndex = 11;
            this.DH_btn_TaoHoaDon.Text = "Tạo Hóa Đơn";
            this.DH_btn_TaoHoaDon.UseVisualStyleBackColor = true;
            this.DH_btn_TaoHoaDon.Click += new System.EventHandler(this.DH_btn_TaoHoaDon_Click);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.DH_btn_TimKiem);
            this.groupBox4.Controls.Add(this.DH_chk_DaXL);
            this.groupBox4.Controls.Add(this.DH_chk_ChoXL);
            this.groupBox4.Controls.Add(this.DH_dtp_DenNgay);
            this.groupBox4.Controls.Add(this.DH_dtp_TuNgay);
            this.groupBox4.Controls.Add(this.DH_txt_TenKH);
            this.groupBox4.Controls.Add(this.label13);
            this.groupBox4.Controls.Add(this.label12);
            this.groupBox4.Controls.Add(this.label11);
            this.groupBox4.Controls.Add(this.label10);
            this.groupBox4.Location = new System.Drawing.Point(21, 96);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(364, 293);
            this.groupBox4.TabIndex = 0;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Tìm Kiếm";
            // 
            // DH_btn_TimKiem
            // 
            this.DH_btn_TimKiem.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DH_btn_TimKiem.Location = new System.Drawing.Point(119, 236);
            this.DH_btn_TimKiem.Name = "DH_btn_TimKiem";
            this.DH_btn_TimKiem.Size = new System.Drawing.Size(95, 34);
            this.DH_btn_TimKiem.TabIndex = 9;
            this.DH_btn_TimKiem.Text = "Tìm Kiếm";
            this.DH_btn_TimKiem.UseVisualStyleBackColor = true;
            this.DH_btn_TimKiem.Click += new System.EventHandler(this.DH_btn_TimKiem_Click);
            // 
            // DH_chk_DaXL
            // 
            this.DH_chk_DaXL.AutoSize = true;
            this.DH_chk_DaXL.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DH_chk_DaXL.Location = new System.Drawing.Point(259, 185);
            this.DH_chk_DaXL.Name = "DH_chk_DaXL";
            this.DH_chk_DaXL.Size = new System.Drawing.Size(93, 24);
            this.DH_chk_DaXL.TabIndex = 8;
            this.DH_chk_DaXL.Text = "Đã Xử Lý";
            this.DH_chk_DaXL.UseVisualStyleBackColor = true;
            // 
            // DH_chk_ChoXL
            // 
            this.DH_chk_ChoXL.AutoSize = true;
            this.DH_chk_ChoXL.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DH_chk_ChoXL.Location = new System.Drawing.Point(142, 185);
            this.DH_chk_ChoXL.Name = "DH_chk_ChoXL";
            this.DH_chk_ChoXL.Size = new System.Drawing.Size(101, 24);
            this.DH_chk_ChoXL.TabIndex = 7;
            this.DH_chk_ChoXL.Text = "Chờ Xử Lý";
            this.DH_chk_ChoXL.UseVisualStyleBackColor = true;
            // 
            // DH_dtp_DenNgay
            // 
            this.DH_dtp_DenNgay.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DH_dtp_DenNgay.Location = new System.Drawing.Point(142, 137);
            this.DH_dtp_DenNgay.Name = "DH_dtp_DenNgay";
            this.DH_dtp_DenNgay.Size = new System.Drawing.Size(190, 26);
            this.DH_dtp_DenNgay.TabIndex = 6;
            // 
            // DH_dtp_TuNgay
            // 
            this.DH_dtp_TuNgay.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DH_dtp_TuNgay.Location = new System.Drawing.Point(142, 84);
            this.DH_dtp_TuNgay.Name = "DH_dtp_TuNgay";
            this.DH_dtp_TuNgay.Size = new System.Drawing.Size(190, 26);
            this.DH_dtp_TuNgay.TabIndex = 5;
            // 
            // DH_txt_TenKH
            // 
            this.DH_txt_TenKH.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DH_txt_TenKH.Location = new System.Drawing.Point(142, 38);
            this.DH_txt_TenKH.Name = "DH_txt_TenKH";
            this.DH_txt_TenKH.Size = new System.Drawing.Size(190, 26);
            this.DH_txt_TenKH.TabIndex = 4;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(15, 185);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(92, 20);
            this.label13.TabIndex = 3;
            this.label13.Text = "Trạng Thái: ";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(15, 137);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(87, 20);
            this.label12.TabIndex = 2;
            this.label12.Text = "Đến Ngày: ";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(15, 90);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(71, 20);
            this.label11.TabIndex = 1;
            this.label11.Text = "Từ Ngày:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(15, 41);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(105, 20);
            this.label10.TabIndex = 0;
            this.label10.Text = "Khách Hàng: ";
            // 
            // tabKhachHang
            // 
            this.tabKhachHang.Controls.Add(this.dataKhachHang);
            this.tabKhachHang.Controls.Add(this.KH_btn_Refresh);
            this.tabKhachHang.Controls.Add(this.KH_btn_Them);
            this.tabKhachHang.Controls.Add(this.groupBox3);
            this.tabKhachHang.Location = new System.Drawing.Point(4, 34);
            this.tabKhachHang.Name = "tabKhachHang";
            this.tabKhachHang.Size = new System.Drawing.Size(993, 442);
            this.tabKhachHang.TabIndex = 3;
            this.tabKhachHang.Text = "Khách Hàng";
            this.tabKhachHang.UseVisualStyleBackColor = true;
            // 
            // dataKhachHang
            // 
            this.dataKhachHang.AutoGenerateColumns = false;
            this.dataKhachHang.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataKhachHang.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idDataGridViewTextBoxColumn3,
            this.tenKHDataGridViewTextBoxColumn1,
            this.sdtDataGridViewTextBoxColumn,
            this.diaChiDataGridViewTextBoxColumn,
            this.emailDataGridViewTextBoxColumn,
            this.tenDNDataGridViewTextBoxColumn,
            this.matKhauDataGridViewTextBoxColumn});
            this.dataKhachHang.DataSource = this.khachHangEntityBindingSource;
            this.dataKhachHang.Location = new System.Drawing.Point(335, 39);
            this.dataKhachHang.Name = "dataKhachHang";
            this.dataKhachHang.Size = new System.Drawing.Size(637, 367);
            this.dataKhachHang.TabIndex = 9;
            this.dataKhachHang.CellMouseDoubleClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dataKhachHang_CellMouseDoubleClick);
            // 
            // idDataGridViewTextBoxColumn3
            // 
            this.idDataGridViewTextBoxColumn3.DataPropertyName = "id";
            this.idDataGridViewTextBoxColumn3.HeaderText = "id";
            this.idDataGridViewTextBoxColumn3.Name = "idDataGridViewTextBoxColumn3";
            this.idDataGridViewTextBoxColumn3.Visible = false;
            // 
            // tenKHDataGridViewTextBoxColumn1
            // 
            this.tenKHDataGridViewTextBoxColumn1.DataPropertyName = "tenKH";
            this.tenKHDataGridViewTextBoxColumn1.FillWeight = 150F;
            this.tenKHDataGridViewTextBoxColumn1.HeaderText = "Tên Khách Hàng";
            this.tenKHDataGridViewTextBoxColumn1.Name = "tenKHDataGridViewTextBoxColumn1";
            this.tenKHDataGridViewTextBoxColumn1.Width = 150;
            // 
            // sdtDataGridViewTextBoxColumn
            // 
            this.sdtDataGridViewTextBoxColumn.DataPropertyName = "sdt";
            this.sdtDataGridViewTextBoxColumn.HeaderText = "SĐT";
            this.sdtDataGridViewTextBoxColumn.Name = "sdtDataGridViewTextBoxColumn";
            // 
            // diaChiDataGridViewTextBoxColumn
            // 
            this.diaChiDataGridViewTextBoxColumn.DataPropertyName = "diaChi";
            this.diaChiDataGridViewTextBoxColumn.FillWeight = 200F;
            this.diaChiDataGridViewTextBoxColumn.HeaderText = "Địa Chỉ";
            this.diaChiDataGridViewTextBoxColumn.Name = "diaChiDataGridViewTextBoxColumn";
            this.diaChiDataGridViewTextBoxColumn.Width = 200;
            // 
            // emailDataGridViewTextBoxColumn
            // 
            this.emailDataGridViewTextBoxColumn.DataPropertyName = "email";
            this.emailDataGridViewTextBoxColumn.FillWeight = 200F;
            this.emailDataGridViewTextBoxColumn.HeaderText = "Email";
            this.emailDataGridViewTextBoxColumn.Name = "emailDataGridViewTextBoxColumn";
            this.emailDataGridViewTextBoxColumn.Width = 200;
            // 
            // tenDNDataGridViewTextBoxColumn
            // 
            this.tenDNDataGridViewTextBoxColumn.DataPropertyName = "tenDN";
            this.tenDNDataGridViewTextBoxColumn.HeaderText = "tenDN";
            this.tenDNDataGridViewTextBoxColumn.Name = "tenDNDataGridViewTextBoxColumn";
            this.tenDNDataGridViewTextBoxColumn.Visible = false;
            // 
            // matKhauDataGridViewTextBoxColumn
            // 
            this.matKhauDataGridViewTextBoxColumn.DataPropertyName = "matKhau";
            this.matKhauDataGridViewTextBoxColumn.HeaderText = "matKhau";
            this.matKhauDataGridViewTextBoxColumn.Name = "matKhauDataGridViewTextBoxColumn";
            this.matKhauDataGridViewTextBoxColumn.Visible = false;
            // 
            // khachHangEntityBindingSource
            // 
            this.khachHangEntityBindingSource.DataSource = typeof(WinFormQuanLy.KhachHangServiceReference.KhachHangEntity);
            // 
            // KH_btn_Refresh
            // 
            this.KH_btn_Refresh.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.KH_btn_Refresh.Location = new System.Drawing.Point(164, 39);
            this.KH_btn_Refresh.Name = "KH_btn_Refresh";
            this.KH_btn_Refresh.Size = new System.Drawing.Size(96, 40);
            this.KH_btn_Refresh.TabIndex = 7;
            this.KH_btn_Refresh.Text = "Refresh";
            this.KH_btn_Refresh.UseVisualStyleBackColor = true;
            this.KH_btn_Refresh.Click += new System.EventHandler(this.KH_btn_Refresh_Click);
            // 
            // KH_btn_Them
            // 
            this.KH_btn_Them.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.KH_btn_Them.Location = new System.Drawing.Point(34, 39);
            this.KH_btn_Them.Name = "KH_btn_Them";
            this.KH_btn_Them.Size = new System.Drawing.Size(96, 40);
            this.KH_btn_Them.TabIndex = 8;
            this.KH_btn_Them.Text = "Thêm";
            this.KH_btn_Them.UseVisualStyleBackColor = true;
            this.KH_btn_Them.Click += new System.EventHandler(this.KH_btn_Them_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.KH_btn_TimKiem);
            this.groupBox3.Controls.Add(this.KH_txt_Email);
            this.groupBox3.Controls.Add(this.KH_txt_SDT);
            this.groupBox3.Controls.Add(this.KH_txt_TenKH);
            this.groupBox3.Controls.Add(this.label9);
            this.groupBox3.Controls.Add(this.label8);
            this.groupBox3.Controls.Add(this.label7);
            this.groupBox3.Location = new System.Drawing.Point(10, 98);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(305, 308);
            this.groupBox3.TabIndex = 0;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Tìm Kiếm";
            // 
            // KH_btn_TimKiem
            // 
            this.KH_btn_TimKiem.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.KH_btn_TimKiem.Location = new System.Drawing.Point(102, 226);
            this.KH_btn_TimKiem.Name = "KH_btn_TimKiem";
            this.KH_btn_TimKiem.Size = new System.Drawing.Size(96, 40);
            this.KH_btn_TimKiem.TabIndex = 6;
            this.KH_btn_TimKiem.Text = "Tìm Kiếm";
            this.KH_btn_TimKiem.UseVisualStyleBackColor = true;
            this.KH_btn_TimKiem.Click += new System.EventHandler(this.KH_btn_TimKiem_Click);
            // 
            // KH_txt_Email
            // 
            this.KH_txt_Email.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.KH_txt_Email.Location = new System.Drawing.Point(148, 161);
            this.KH_txt_Email.Name = "KH_txt_Email";
            this.KH_txt_Email.Size = new System.Drawing.Size(142, 26);
            this.KH_txt_Email.TabIndex = 5;
            // 
            // KH_txt_SDT
            // 
            this.KH_txt_SDT.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.KH_txt_SDT.Location = new System.Drawing.Point(148, 100);
            this.KH_txt_SDT.Name = "KH_txt_SDT";
            this.KH_txt_SDT.Size = new System.Drawing.Size(142, 26);
            this.KH_txt_SDT.TabIndex = 4;
            this.KH_txt_SDT.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.KhongNhapChu);
            // 
            // KH_txt_TenKH
            // 
            this.KH_txt_TenKH.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.KH_txt_TenKH.Location = new System.Drawing.Point(148, 46);
            this.KH_txt_TenKH.Name = "KH_txt_TenKH";
            this.KH_txt_TenKH.Size = new System.Drawing.Size(142, 26);
            this.KH_txt_TenKH.TabIndex = 3;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(14, 164);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(56, 20);
            this.label9.TabIndex = 2;
            this.label9.Text = "Email: ";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(14, 103);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(117, 20);
            this.label8.TabIndex = 1;
            this.label8.Text = "Số Điện Thoại: ";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(14, 46);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(136, 20);
            this.label7.TabIndex = 0;
            this.label7.Text = "Tên Khách Hàng: ";
            // 
            // tabNhapKho
            // 
            this.tabNhapKho.Controls.Add(this.NK_btn_Them);
            this.tabNhapKho.Controls.Add(this.dataNhapKho);
            this.tabNhapKho.Controls.Add(this.groupBox5);
            this.tabNhapKho.Controls.Add(this.NK_btn_Refresh);
            this.tabNhapKho.Location = new System.Drawing.Point(4, 34);
            this.tabNhapKho.Name = "tabNhapKho";
            this.tabNhapKho.Padding = new System.Windows.Forms.Padding(3);
            this.tabNhapKho.Size = new System.Drawing.Size(993, 442);
            this.tabNhapKho.TabIndex = 4;
            this.tabNhapKho.Text = "Nhập Kho";
            this.tabNhapKho.UseVisualStyleBackColor = true;
            // 
            // NK_btn_Them
            // 
            this.NK_btn_Them.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NK_btn_Them.Location = new System.Drawing.Point(92, 37);
            this.NK_btn_Them.Name = "NK_btn_Them";
            this.NK_btn_Them.Size = new System.Drawing.Size(103, 38);
            this.NK_btn_Them.TabIndex = 4;
            this.NK_btn_Them.Text = "Thêm";
            this.NK_btn_Them.UseVisualStyleBackColor = true;
            this.NK_btn_Them.Click += new System.EventHandler(this.NK_btn_Them_Click);
            // 
            // dataNhapKho
            // 
            this.dataNhapKho.AutoGenerateColumns = false;
            this.dataNhapKho.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataNhapKho.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idDataGridViewTextBoxColumn4,
            this.ngayNhapKhoDataGridViewTextBoxColumn,
            this.tongTienDataGridViewTextBoxColumn});
            this.dataNhapKho.DataSource = this.nhapKhoEntityBindingSource;
            this.dataNhapKho.Location = new System.Drawing.Point(447, 37);
            this.dataNhapKho.Name = "dataNhapKho";
            this.dataNhapKho.Size = new System.Drawing.Size(522, 352);
            this.dataNhapKho.TabIndex = 3;
            this.dataNhapKho.CellMouseDoubleClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dataNhapKho_CellMouseDoubleClick);
            // 
            // idDataGridViewTextBoxColumn4
            // 
            this.idDataGridViewTextBoxColumn4.DataPropertyName = "id";
            this.idDataGridViewTextBoxColumn4.HeaderText = "Mã Phiếu Nhập";
            this.idDataGridViewTextBoxColumn4.Name = "idDataGridViewTextBoxColumn4";
            // 
            // ngayNhapKhoDataGridViewTextBoxColumn
            // 
            this.ngayNhapKhoDataGridViewTextBoxColumn.DataPropertyName = "ngayNhapKho";
            this.ngayNhapKhoDataGridViewTextBoxColumn.FillWeight = 200F;
            this.ngayNhapKhoDataGridViewTextBoxColumn.HeaderText = "Ngày Nhập Kho";
            this.ngayNhapKhoDataGridViewTextBoxColumn.Name = "ngayNhapKhoDataGridViewTextBoxColumn";
            this.ngayNhapKhoDataGridViewTextBoxColumn.Width = 200;
            // 
            // tongTienDataGridViewTextBoxColumn
            // 
            this.tongTienDataGridViewTextBoxColumn.DataPropertyName = "tongTien";
            this.tongTienDataGridViewTextBoxColumn.FillWeight = 200F;
            this.tongTienDataGridViewTextBoxColumn.HeaderText = "Tổng Tiền";
            this.tongTienDataGridViewTextBoxColumn.Name = "tongTienDataGridViewTextBoxColumn";
            this.tongTienDataGridViewTextBoxColumn.Width = 200;
            // 
            // nhapKhoEntityBindingSource
            // 
            this.nhapKhoEntityBindingSource.DataSource = typeof(WinFormQuanLy.NhapKhoServiceReference.NhapKhoEntity);
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.label15);
            this.groupBox5.Controls.Add(this.label14);
            this.groupBox5.Controls.Add(this.NK_btn_Tim);
            this.groupBox5.Controls.Add(this.dateTimePicker2);
            this.groupBox5.Controls.Add(this.dateTimePicker1);
            this.groupBox5.Location = new System.Drawing.Point(22, 111);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(393, 278);
            this.groupBox5.TabIndex = 2;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Tìm Kiếm";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(28, 125);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(83, 20);
            this.label15.TabIndex = 4;
            this.label15.Text = "Đến Ngày:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(28, 54);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(71, 20);
            this.label14.TabIndex = 3;
            this.label14.Text = "Từ Ngày:";
            // 
            // NK_btn_Tim
            // 
            this.NK_btn_Tim.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NK_btn_Tim.Location = new System.Drawing.Point(126, 189);
            this.NK_btn_Tim.Name = "NK_btn_Tim";
            this.NK_btn_Tim.Size = new System.Drawing.Size(121, 37);
            this.NK_btn_Tim.TabIndex = 2;
            this.NK_btn_Tim.Text = "Tìm";
            this.NK_btn_Tim.UseVisualStyleBackColor = true;
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker2.Location = new System.Drawing.Point(126, 119);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(200, 26);
            this.dateTimePicker2.TabIndex = 1;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker1.Location = new System.Drawing.Point(126, 49);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(200, 26);
            this.dateTimePicker1.TabIndex = 0;
            // 
            // NK_btn_Refresh
            // 
            this.NK_btn_Refresh.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NK_btn_Refresh.Location = new System.Drawing.Point(226, 37);
            this.NK_btn_Refresh.Name = "NK_btn_Refresh";
            this.NK_btn_Refresh.Size = new System.Drawing.Size(103, 38);
            this.NK_btn_Refresh.TabIndex = 1;
            this.NK_btn_Refresh.Text = "Refresh";
            this.NK_btn_Refresh.UseVisualStyleBackColor = true;
            this.NK_btn_Refresh.Click += new System.EventHandler(this.NK_btn_Refresh_Click);
            // 
            // tabThongKe
            // 
            this.tabThongKe.Controls.Add(this.TK_btn_Refresh);
            this.tabThongKe.Controls.Add(this.dataThongKe);
            this.tabThongKe.Controls.Add(this.groupBox6);
            this.tabThongKe.Location = new System.Drawing.Point(4, 34);
            this.tabThongKe.Name = "tabThongKe";
            this.tabThongKe.Padding = new System.Windows.Forms.Padding(3);
            this.tabThongKe.Size = new System.Drawing.Size(993, 442);
            this.tabThongKe.TabIndex = 5;
            this.tabThongKe.Text = "Thống Kê";
            this.tabThongKe.UseVisualStyleBackColor = true;
            // 
            // TK_btn_Refresh
            // 
            this.TK_btn_Refresh.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TK_btn_Refresh.Location = new System.Drawing.Point(417, 6);
            this.TK_btn_Refresh.Name = "TK_btn_Refresh";
            this.TK_btn_Refresh.Size = new System.Drawing.Size(99, 36);
            this.TK_btn_Refresh.TabIndex = 5;
            this.TK_btn_Refresh.Text = "Refresh";
            this.TK_btn_Refresh.UseVisualStyleBackColor = true;
            this.TK_btn_Refresh.Click += new System.EventHandler(this.TK_btn_Refresh_Click);
            // 
            // dataThongKe
            // 
            this.dataThongKe.AutoGenerateColumns = false;
            this.dataThongKe.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataThongKe.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idDataGridViewTextBoxColumn5,
            this.idLoaiSPDataGridViewTextBoxColumn1,
            this.idMauSacDataGridViewTextBoxColumn1,
            this.tenSPDataGridViewTextBoxColumn1,
            this.soLuongDataGridViewTextBoxColumn1,
            this.giaNiemYetDataGridViewTextBoxColumn1,
            this.giaGiamDataGridViewTextBoxColumn1,
            this.hinhAnhDataGridViewTextBoxColumn1,
            this.kichThuocDataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn5,
            this.spDBDataGridViewCheckBoxColumn1,
            this.spMoiDataGridViewCheckBoxColumn1,
            this.loaiSanPhamDataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn4});
            this.dataThongKe.DataSource = this.sanPhamEntityBindingSource1;
            this.dataThongKe.Location = new System.Drawing.Point(398, 48);
            this.dataThongKe.Name = "dataThongKe";
            this.dataThongKe.Size = new System.Drawing.Size(587, 357);
            this.dataThongKe.TabIndex = 1;
            // 
            // idDataGridViewTextBoxColumn5
            // 
            this.idDataGridViewTextBoxColumn5.DataPropertyName = "id";
            this.idDataGridViewTextBoxColumn5.HeaderText = "Mã Sản Phẩm";
            this.idDataGridViewTextBoxColumn5.Name = "idDataGridViewTextBoxColumn5";
            // 
            // idLoaiSPDataGridViewTextBoxColumn1
            // 
            this.idLoaiSPDataGridViewTextBoxColumn1.DataPropertyName = "idLoaiSP";
            this.idLoaiSPDataGridViewTextBoxColumn1.HeaderText = "idLoaiSP";
            this.idLoaiSPDataGridViewTextBoxColumn1.Name = "idLoaiSPDataGridViewTextBoxColumn1";
            this.idLoaiSPDataGridViewTextBoxColumn1.Visible = false;
            // 
            // idMauSacDataGridViewTextBoxColumn1
            // 
            this.idMauSacDataGridViewTextBoxColumn1.DataPropertyName = "idMauSac";
            this.idMauSacDataGridViewTextBoxColumn1.HeaderText = "idMauSac";
            this.idMauSacDataGridViewTextBoxColumn1.Name = "idMauSacDataGridViewTextBoxColumn1";
            this.idMauSacDataGridViewTextBoxColumn1.Visible = false;
            // 
            // tenSPDataGridViewTextBoxColumn1
            // 
            this.tenSPDataGridViewTextBoxColumn1.DataPropertyName = "tenSP";
            this.tenSPDataGridViewTextBoxColumn1.FillWeight = 150F;
            this.tenSPDataGridViewTextBoxColumn1.HeaderText = "Tên Sản Phẩm";
            this.tenSPDataGridViewTextBoxColumn1.Name = "tenSPDataGridViewTextBoxColumn1";
            this.tenSPDataGridViewTextBoxColumn1.Width = 150;
            // 
            // soLuongDataGridViewTextBoxColumn1
            // 
            this.soLuongDataGridViewTextBoxColumn1.DataPropertyName = "soLuong";
            this.soLuongDataGridViewTextBoxColumn1.HeaderText = "Số Lượng Bán Được";
            this.soLuongDataGridViewTextBoxColumn1.Name = "soLuongDataGridViewTextBoxColumn1";
            // 
            // giaNiemYetDataGridViewTextBoxColumn1
            // 
            this.giaNiemYetDataGridViewTextBoxColumn1.DataPropertyName = "giaNiemYet";
            this.giaNiemYetDataGridViewTextBoxColumn1.HeaderText = "Giá Niêm Yết";
            this.giaNiemYetDataGridViewTextBoxColumn1.Name = "giaNiemYetDataGridViewTextBoxColumn1";
            // 
            // giaGiamDataGridViewTextBoxColumn1
            // 
            this.giaGiamDataGridViewTextBoxColumn1.DataPropertyName = "giaGiam";
            this.giaGiamDataGridViewTextBoxColumn1.HeaderText = "Giá Giảm";
            this.giaGiamDataGridViewTextBoxColumn1.Name = "giaGiamDataGridViewTextBoxColumn1";
            // 
            // hinhAnhDataGridViewTextBoxColumn1
            // 
            this.hinhAnhDataGridViewTextBoxColumn1.DataPropertyName = "hinhAnh";
            this.hinhAnhDataGridViewTextBoxColumn1.HeaderText = "Hình Ảnh";
            this.hinhAnhDataGridViewTextBoxColumn1.Name = "hinhAnhDataGridViewTextBoxColumn1";
            this.hinhAnhDataGridViewTextBoxColumn1.Visible = false;
            // 
            // kichThuocDataGridViewTextBoxColumn1
            // 
            this.kichThuocDataGridViewTextBoxColumn1.DataPropertyName = "kichThuoc";
            this.kichThuocDataGridViewTextBoxColumn1.HeaderText = "Kích Thước";
            this.kichThuocDataGridViewTextBoxColumn1.Name = "kichThuocDataGridViewTextBoxColumn1";
            this.kichThuocDataGridViewTextBoxColumn1.Visible = false;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "mieuTa";
            this.dataGridViewTextBoxColumn5.HeaderText = "Miêu Tả";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.Visible = false;
            // 
            // spDBDataGridViewCheckBoxColumn1
            // 
            this.spDBDataGridViewCheckBoxColumn1.DataPropertyName = "spDB";
            this.spDBDataGridViewCheckBoxColumn1.HeaderText = "spDB";
            this.spDBDataGridViewCheckBoxColumn1.Name = "spDBDataGridViewCheckBoxColumn1";
            this.spDBDataGridViewCheckBoxColumn1.Visible = false;
            // 
            // spMoiDataGridViewCheckBoxColumn1
            // 
            this.spMoiDataGridViewCheckBoxColumn1.DataPropertyName = "spMoi";
            this.spMoiDataGridViewCheckBoxColumn1.HeaderText = "spMoi";
            this.spMoiDataGridViewCheckBoxColumn1.Name = "spMoiDataGridViewCheckBoxColumn1";
            this.spMoiDataGridViewCheckBoxColumn1.Visible = false;
            // 
            // loaiSanPhamDataGridViewTextBoxColumn1
            // 
            this.loaiSanPhamDataGridViewTextBoxColumn1.DataPropertyName = "LoaiSanPham";
            this.loaiSanPhamDataGridViewTextBoxColumn1.HeaderText = "LoaiSanPham";
            this.loaiSanPhamDataGridViewTextBoxColumn1.Name = "loaiSanPhamDataGridViewTextBoxColumn1";
            this.loaiSanPhamDataGridViewTextBoxColumn1.Visible = false;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "MauSac";
            this.dataGridViewTextBoxColumn4.HeaderText = "MauSac";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.Visible = false;
            // 
            // sanPhamEntityBindingSource1
            // 
            this.sanPhamEntityBindingSource1.DataSource = typeof(WinFormQuanLy.SanPhamServiceReference.SanPhamEntity);
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.TK_btn_thongke);
            this.groupBox6.Controls.Add(this.TK_dtp_DenNgay);
            this.groupBox6.Controls.Add(this.TK_dtp_TuNgay);
            this.groupBox6.Controls.Add(this.label17);
            this.groupBox6.Controls.Add(this.label16);
            this.groupBox6.Location = new System.Drawing.Point(20, 38);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(365, 367);
            this.groupBox6.TabIndex = 0;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Thống Kê Theo thời gian";
            // 
            // TK_btn_thongke
            // 
            this.TK_btn_thongke.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TK_btn_thongke.Location = new System.Drawing.Point(133, 167);
            this.TK_btn_thongke.Name = "TK_btn_thongke";
            this.TK_btn_thongke.Size = new System.Drawing.Size(99, 38);
            this.TK_btn_thongke.TabIndex = 4;
            this.TK_btn_thongke.Text = "Thống Kê";
            this.TK_btn_thongke.UseVisualStyleBackColor = true;
            this.TK_btn_thongke.Click += new System.EventHandler(this.TK_btn_thongke_Click);
            // 
            // TK_dtp_DenNgay
            // 
            this.TK_dtp_DenNgay.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TK_dtp_DenNgay.Location = new System.Drawing.Point(133, 106);
            this.TK_dtp_DenNgay.Name = "TK_dtp_DenNgay";
            this.TK_dtp_DenNgay.Size = new System.Drawing.Size(200, 26);
            this.TK_dtp_DenNgay.TabIndex = 3;
            // 
            // TK_dtp_TuNgay
            // 
            this.TK_dtp_TuNgay.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TK_dtp_TuNgay.Location = new System.Drawing.Point(133, 48);
            this.TK_dtp_TuNgay.Name = "TK_dtp_TuNgay";
            this.TK_dtp_TuNgay.Size = new System.Drawing.Size(200, 26);
            this.TK_dtp_TuNgay.TabIndex = 2;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(24, 111);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(83, 20);
            this.label17.TabIndex = 1;
            this.label17.Text = "Đến Ngày:";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(24, 54);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(75, 20);
            this.label16.TabIndex = 0;
            this.label16.Text = "Từ Ngày: ";
            // 
            // GiaoDien
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1002, 478);
            this.Controls.Add(this.tabControl);
            this.Name = "GiaoDien";
            this.Text = "Giao Diện Quản Lý Bán Giày Dép";
            this.tabControl.ResumeLayout(false);
            this.tabSanPham.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataSanPham)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sanPhamEntityBindingSource)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tabLoaiSP.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataLoaiSP)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.loaiSanPhamEntityBindingSource)).EndInit();
            this.tabDonHang.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataDonHang)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.donHangEntityBindingSource)).EndInit();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.tabKhachHang.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataKhachHang)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.khachHangEntityBindingSource)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.tabNhapKho.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataNhapKho)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nhapKhoEntityBindingSource)).EndInit();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.tabThongKe.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataThongKe)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sanPhamEntityBindingSource1)).EndInit();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl;
        private System.Windows.Forms.TabPage tabSanPham;
        private System.Windows.Forms.TabPage tabLoaiSP;
        private System.Windows.Forms.Button SP_btn_Them;
        private System.Windows.Forms.Button SP_btn_Refresh;
        private System.Windows.Forms.DataGridView dataSanPham;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button SP_btn_TimKiem;
        private System.Windows.Forms.ComboBox SP_cb_MauSac;
        private System.Windows.Forms.ComboBox SP_cb_Gia;
        private System.Windows.Forms.ComboBox SP_cb_LoaiSP;
        private System.Windows.Forms.TextBox SP_txt_KichThuoc;
        private System.Windows.Forms.TextBox SP_txt_TenSP;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dataLoaiSP;
        private System.Windows.Forms.DataGridViewTextBoxColumn loaiSPDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn giaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn giamGiaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn mauSacDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn mieutaDataGridViewTextBoxColumn;
        private System.Windows.Forms.Button LoaiSP_btn_Refresh;
        private System.Windows.Forms.Button LoaiSP_btn_Them;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox LoaiSP_txt_TenLoaiSP;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button LoaiSP_btn_Tim;
        private System.Windows.Forms.TabPage tabDonHang;
        private System.Windows.Forms.TabPage tabKhachHang;
        private System.Windows.Forms.DataGridView dataKhachHang;
        private System.Windows.Forms.Button KH_btn_Refresh;
        private System.Windows.Forms.Button KH_btn_Them;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button KH_btn_TimKiem;
        private System.Windows.Forms.TextBox KH_txt_Email;
        private System.Windows.Forms.TextBox KH_txt_SDT;
        private System.Windows.Forms.TextBox KH_txt_TenKH;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.DataGridView dataDonHang;
        private System.Windows.Forms.Button DH_btn_Refresh;
        private System.Windows.Forms.Button DH_btn_TaoHoaDon;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Button DH_btn_TimKiem;
        private System.Windows.Forms.CheckBox DH_chk_DaXL;
        private System.Windows.Forms.CheckBox DH_chk_ChoXL;
        private System.Windows.Forms.DateTimePicker DH_dtp_DenNgay;
        private System.Windows.Forms.DateTimePicker DH_dtp_TuNgay;
        private System.Windows.Forms.TextBox DH_txt_TenKH;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.DataGridViewTextBoxColumn trangThaiDataGridViewTextBoxColumn;
        private System.Windows.Forms.TabPage tabNhapKho;
        private System.Windows.Forms.DataGridViewTextBoxColumn idDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn tenLoaiSPDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.BindingSource loaiSanPhamEntityBindingSource;
        private System.Windows.Forms.BindingSource khachHangEntityBindingSource;
        private System.Windows.Forms.BindingSource sanPhamEntityBindingSource;
        private System.Windows.Forms.DataGridViewTextBoxColumn idDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn idLoaiSPDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn idMauSacDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn tenSPDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn giaNiemYetDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn giaGiamDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn kichThuocDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn soLuongDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn hinhAnhDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewCheckBoxColumn spDBDataGridViewCheckBoxColumn;
        private System.Windows.Forms.DataGridViewCheckBoxColumn spMoiDataGridViewCheckBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn loaiSanPhamDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn idDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn idKhachHangDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn tenKHDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn ngayDHDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn idTrangThaiDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn thanhTienDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn trangThaiDHDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn khachHangDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource donHangEntityBindingSource;
        private System.Windows.Forms.DataGridViewTextBoxColumn idDataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn tenKHDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn sdtDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn diaChiDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn emailDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn tenDNDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn matKhauDataGridViewTextBoxColumn;
        private System.Windows.Forms.Button NK_btn_Them;
        private System.Windows.Forms.DataGridView dataNhapKho;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Button NK_btn_Tim;
        private System.Windows.Forms.DateTimePicker dateTimePicker2;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Button NK_btn_Refresh;
        private System.Windows.Forms.DataGridViewTextBoxColumn idDataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn ngayNhapKhoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn tongTienDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource nhapKhoEntityBindingSource;
        private System.Windows.Forms.TabPage tabThongKe;
        private System.Windows.Forms.Button TK_btn_Refresh;
        private System.Windows.Forms.DataGridView dataThongKe;
        private System.Windows.Forms.DataGridViewTextBoxColumn idDataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn idLoaiSPDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn idMauSacDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn tenSPDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn soLuongDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn giaNiemYetDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn giaGiamDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn hinhAnhDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn kichThuocDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewCheckBoxColumn spDBDataGridViewCheckBoxColumn1;
        private System.Windows.Forms.DataGridViewCheckBoxColumn spMoiDataGridViewCheckBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn loaiSanPhamDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.BindingSource sanPhamEntityBindingSource1;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Button TK_btn_thongke;
        private System.Windows.Forms.DateTimePicker TK_dtp_DenNgay;
        private System.Windows.Forms.DateTimePicker TK_dtp_TuNgay;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
    }
}

