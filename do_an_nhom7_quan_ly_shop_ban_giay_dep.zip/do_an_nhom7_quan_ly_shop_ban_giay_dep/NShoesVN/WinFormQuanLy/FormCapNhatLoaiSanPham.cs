﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WinFormQuanLy.LoaiSanPhamServiceReference;

namespace WinFormQuanLy
{
    public partial class FormCapNhatLoaiSanPham : Form
    {
        private LoaiSanPhamServiceClient loaiSanPham_Client = new LoaiSanPhamServiceClient();
        private LoaiSanPhamEntity obj = new LoaiSanPhamEntity();
        public FormCapNhatLoaiSanPham(LoaiSanPhamEntity obj)
        {
            this.obj = obj;
            InitializeComponent();
            LoadTrang();
        }


        private void LoadTrang()
        {
            txt_TenLoaiSP.Text = obj.tenLoaiSP;
            rtxt_MoTa.Text = obj.mieuTa;
        }

        /// <summary>
        /// Lưu Thông tin Loại Sản phẩm
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btn_Luu_Click(object sender, EventArgs e)
        {
            if (txt_TenLoaiSP.Text.Trim() == "")
            {
                MessageBox.Show("Tên Loại Giày Dép Không Được để trống!");
                return;
            }
            if (rtxt_MoTa.Text.Trim() == "")
            {
                MessageBox.Show("Mô tả về loại giày dép không được để trống!");
                return;
            }
            LoaiSanPhamEntity item = new LoaiSanPhamEntity()
            {
                id = obj.id,
                tenLoaiSP = txt_TenLoaiSP.Text,
                mieuTa = rtxt_MoTa.Text
            };

            try
            {
                loaiSanPham_Client.CapNhatLoaiSP(item);
                MessageBox.Show("Cập Nhật Loại Sản Phẩm Thành Công!");
                txt_TenLoaiSP.Text = "";
                rtxt_MoTa.Text = "";
            }
            catch
            {
                MessageBox.Show("Lỗi trong quá trình cập nhật loại sản phẩm!");
            }
        }

        private void btn_LamLai_Click(object sender, EventArgs e)
        {
            LoadTrang();
        }
    }
}
