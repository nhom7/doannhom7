﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WinFormQuanLy.LoaiSanPhamServiceReference;

namespace WinFormQuanLy
{
    public partial class FormThemLoaiSanPham : Form
    {
        private LoaiSanPhamServiceClient loaiSP_Client = new LoaiSanPhamServiceClient();
        public FormThemLoaiSanPham()
        {
            InitializeComponent();
        }

        private void btn_Luu_Click(object sender, EventArgs e)
        {
            if(txt_TenLoaiSP.Text.Trim()=="")
            {
                MessageBox.Show("Tên Loại Giày Dép Không Được để trống!");
                return;
            }
            if(rtxt_MoTa.Text.Trim() == "")
            {
                MessageBox.Show("Mô tả về loại giày dép không được để trống!");
                return;
            }
            LoaiSanPhamEntity item = new LoaiSanPhamEntity()
            {
                id = loaiSP_Client.SoLuong()+1,
                tenLoaiSP = txt_TenLoaiSP.Text,
                mieuTa = rtxt_MoTa.Text
            };

            try
            {
                loaiSP_Client.ThemLoaiSP(item);
                MessageBox.Show("Thêm Loại Sản Phẩm Thành Công!");
                btn_LamLai_Click(this,e);
            }
            catch
            {
                MessageBox.Show("Lỗi trong quá trình thêm loại sản phẩm!");
            }


        }

        private void btn_LamLai_Click(object sender, EventArgs e)
        {
            txt_TenLoaiSP.Text = "";
            rtxt_MoTa.Text = "";
        }
    }
}
