﻿namespace WinFormQuanLy
{
    partial class FormChiTietDonHang
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lbl_ThanhTien = new System.Windows.Forms.Label();
            this.lbl_TienGiam = new System.Windows.Forms.Label();
            this.lbl_TongTien = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txt_NgayDat = new System.Windows.Forms.TextBox();
            this.txt_TenKH = new System.Windows.Forms.TextBox();
            this.dataChiTietDH = new System.Windows.Forms.DataGridView();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.idDHDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.idSPDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tenSanPhamDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.soLuongDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.giaNiemYetDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.giaGiamDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.donHangDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sanPhamDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cTDHEntityBindingSource = new System.Windows.Forms.BindingSource(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.dataChiTietDH)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cTDHEntityBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // lbl_ThanhTien
            // 
            this.lbl_ThanhTien.AutoSize = true;
            this.lbl_ThanhTien.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ThanhTien.Location = new System.Drawing.Point(251, 428);
            this.lbl_ThanhTien.Name = "lbl_ThanhTien";
            this.lbl_ThanhTien.Size = new System.Drawing.Size(50, 20);
            this.lbl_ThanhTien.TabIndex = 53;
            this.lbl_ThanhTien.Text = "lbltien";
            // 
            // lbl_TienGiam
            // 
            this.lbl_TienGiam.AutoSize = true;
            this.lbl_TienGiam.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_TienGiam.Location = new System.Drawing.Point(251, 384);
            this.lbl_TienGiam.Name = "lbl_TienGiam";
            this.lbl_TienGiam.Size = new System.Drawing.Size(50, 20);
            this.lbl_TienGiam.TabIndex = 52;
            this.lbl_TienGiam.Text = "lbltien";
            // 
            // lbl_TongTien
            // 
            this.lbl_TongTien.AutoSize = true;
            this.lbl_TongTien.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_TongTien.Location = new System.Drawing.Point(251, 337);
            this.lbl_TongTien.Name = "lbl_TongTien";
            this.lbl_TongTien.Size = new System.Drawing.Size(50, 20);
            this.lbl_TongTien.TabIndex = 51;
            this.lbl_TongTien.Text = "lbltien";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.Blue;
            this.label11.Location = new System.Drawing.Point(360, 384);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(43, 20);
            this.label11.TabIndex = 50;
            this.label11.Text = "VNĐ";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Blue;
            this.label10.Location = new System.Drawing.Point(360, 428);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(43, 20);
            this.label10.TabIndex = 49;
            this.label10.Text = "VNĐ";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(121, 384);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(85, 20);
            this.label9.TabIndex = 48;
            this.label9.Text = "Tiền Giảm:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(121, 428);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(92, 20);
            this.label8.TabIndex = 47;
            this.label8.Text = "Thành Tiền:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Blue;
            this.label7.Location = new System.Drawing.Point(360, 344);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(43, 20);
            this.label7.TabIndex = 46;
            this.label7.Text = "VNĐ";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(121, 344);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(83, 20);
            this.label6.TabIndex = 45;
            this.label6.Text = "Tổng Tiền:";
            // 
            // txt_NgayDat
            // 
            this.txt_NgayDat.Enabled = false;
            this.txt_NgayDat.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_NgayDat.Location = new System.Drawing.Point(152, 80);
            this.txt_NgayDat.Name = "txt_NgayDat";
            this.txt_NgayDat.Size = new System.Drawing.Size(190, 26);
            this.txt_NgayDat.TabIndex = 41;
            // 
            // txt_TenKH
            // 
            this.txt_TenKH.Enabled = false;
            this.txt_TenKH.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_TenKH.Location = new System.Drawing.Point(154, 34);
            this.txt_TenKH.Name = "txt_TenKH";
            this.txt_TenKH.Size = new System.Drawing.Size(188, 26);
            this.txt_TenKH.TabIndex = 40;
            // 
            // dataChiTietDH
            // 
            this.dataChiTietDH.AutoGenerateColumns = false;
            this.dataChiTietDH.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataChiTietDH.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idDHDataGridViewTextBoxColumn,
            this.idSPDataGridViewTextBoxColumn,
            this.tenSanPhamDataGridViewTextBoxColumn,
            this.soLuongDataGridViewTextBoxColumn,
            this.giaNiemYetDataGridViewTextBoxColumn,
            this.giaGiamDataGridViewTextBoxColumn,
            this.donHangDataGridViewTextBoxColumn,
            this.sanPhamDataGridViewTextBoxColumn});
            this.dataChiTietDH.DataSource = this.cTDHEntityBindingSource;
            this.dataChiTietDH.Enabled = false;
            this.dataChiTietDH.Location = new System.Drawing.Point(12, 146);
            this.dataChiTietDH.Name = "dataChiTietDH";
            this.dataChiTietDH.Size = new System.Drawing.Size(466, 174);
            this.dataChiTietDH.TabIndex = 33;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(12, 83);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(126, 20);
            this.label2.TabIndex = 32;
            this.label2.Text = "Ngày Đặt Hàng: ";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 37);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(136, 20);
            this.label1.TabIndex = 31;
            this.label1.Text = "Tên Khách Hàng: ";
            // 
            // idDHDataGridViewTextBoxColumn
            // 
            this.idDHDataGridViewTextBoxColumn.DataPropertyName = "idDH";
            this.idDHDataGridViewTextBoxColumn.HeaderText = "idDH";
            this.idDHDataGridViewTextBoxColumn.Name = "idDHDataGridViewTextBoxColumn";
            this.idDHDataGridViewTextBoxColumn.Visible = false;
            // 
            // idSPDataGridViewTextBoxColumn
            // 
            this.idSPDataGridViewTextBoxColumn.DataPropertyName = "idSP";
            this.idSPDataGridViewTextBoxColumn.FillWeight = 50F;
            this.idSPDataGridViewTextBoxColumn.HeaderText = "Mã Sản Phẩm";
            this.idSPDataGridViewTextBoxColumn.Name = "idSPDataGridViewTextBoxColumn";
            this.idSPDataGridViewTextBoxColumn.Width = 50;
            // 
            // tenSanPhamDataGridViewTextBoxColumn
            // 
            this.tenSanPhamDataGridViewTextBoxColumn.DataPropertyName = "tenSanPham";
            this.tenSanPhamDataGridViewTextBoxColumn.FillWeight = 150F;
            this.tenSanPhamDataGridViewTextBoxColumn.HeaderText = "Tên Sản Phẩm";
            this.tenSanPhamDataGridViewTextBoxColumn.Name = "tenSanPhamDataGridViewTextBoxColumn";
            this.tenSanPhamDataGridViewTextBoxColumn.Width = 150;
            // 
            // soLuongDataGridViewTextBoxColumn
            // 
            this.soLuongDataGridViewTextBoxColumn.DataPropertyName = "soLuong";
            this.soLuongDataGridViewTextBoxColumn.FillWeight = 50F;
            this.soLuongDataGridViewTextBoxColumn.HeaderText = "Số Lượng";
            this.soLuongDataGridViewTextBoxColumn.Name = "soLuongDataGridViewTextBoxColumn";
            this.soLuongDataGridViewTextBoxColumn.Width = 50;
            // 
            // giaNiemYetDataGridViewTextBoxColumn
            // 
            this.giaNiemYetDataGridViewTextBoxColumn.DataPropertyName = "giaNiemYet";
            this.giaNiemYetDataGridViewTextBoxColumn.HeaderText = "Giá Niêm Yết";
            this.giaNiemYetDataGridViewTextBoxColumn.Name = "giaNiemYetDataGridViewTextBoxColumn";
            // 
            // giaGiamDataGridViewTextBoxColumn
            // 
            this.giaGiamDataGridViewTextBoxColumn.DataPropertyName = "giaGiam";
            this.giaGiamDataGridViewTextBoxColumn.FillWeight = 75F;
            this.giaGiamDataGridViewTextBoxColumn.HeaderText = "Giá giảm";
            this.giaGiamDataGridViewTextBoxColumn.Name = "giaGiamDataGridViewTextBoxColumn";
            this.giaGiamDataGridViewTextBoxColumn.Width = 75;
            // 
            // donHangDataGridViewTextBoxColumn
            // 
            this.donHangDataGridViewTextBoxColumn.DataPropertyName = "DonHang";
            this.donHangDataGridViewTextBoxColumn.HeaderText = "DonHang";
            this.donHangDataGridViewTextBoxColumn.Name = "donHangDataGridViewTextBoxColumn";
            this.donHangDataGridViewTextBoxColumn.Visible = false;
            // 
            // sanPhamDataGridViewTextBoxColumn
            // 
            this.sanPhamDataGridViewTextBoxColumn.DataPropertyName = "SanPham";
            this.sanPhamDataGridViewTextBoxColumn.HeaderText = "SanPham";
            this.sanPhamDataGridViewTextBoxColumn.Name = "sanPhamDataGridViewTextBoxColumn";
            this.sanPhamDataGridViewTextBoxColumn.Visible = false;
            // 
            // cTDHEntityBindingSource
            // 
            this.cTDHEntityBindingSource.DataSource = typeof(WinFormQuanLy.CTDHServiceReference.CTDHEntity);
            // 
            // FormChiTietDonHang
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(500, 461);
            this.Controls.Add(this.lbl_ThanhTien);
            this.Controls.Add(this.lbl_TienGiam);
            this.Controls.Add(this.lbl_TongTien);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txt_NgayDat);
            this.Controls.Add(this.txt_TenKH);
            this.Controls.Add(this.dataChiTietDH);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "FormChiTietDonHang";
            this.Text = "Chi Tiết Đơn Hàng";
            ((System.ComponentModel.ISupportInitialize)(this.dataChiTietDH)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cTDHEntityBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.BindingSource cTDHEntityBindingSource;
        private System.Windows.Forms.DataGridViewTextBoxColumn donHangDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn giaGiamDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn giaNiemYetDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn soLuongDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn tenSanPhamDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn idSPDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn idDHDataGridViewTextBoxColumn;
        private System.Windows.Forms.Label lbl_ThanhTien;
        private System.Windows.Forms.Label lbl_TienGiam;
        private System.Windows.Forms.Label lbl_TongTien;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.DataGridViewTextBoxColumn sanPhamDataGridViewTextBoxColumn;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txt_NgayDat;
        private System.Windows.Forms.TextBox txt_TenKH;
        private System.Windows.Forms.DataGridView dataChiTietDH;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
    }
}