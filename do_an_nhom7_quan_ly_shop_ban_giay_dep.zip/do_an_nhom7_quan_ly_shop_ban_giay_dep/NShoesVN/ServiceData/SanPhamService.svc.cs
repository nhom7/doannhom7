﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace ServiceData
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "SanPhamService" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select SanPhamService.svc or SanPhamService.svc.cs at the Solution Explorer and start debugging.
    public class SanPhamService : ISanPhamService
    {
        /// <summary>
        /// Lấy Toàn Bộ DS Sản phẩm
        /// </summary>
        /// <returns></returns>
        public List<SanPhamEntity> LayDSSP()
        {
            using (var db = new WebShopEntities())
            {
                var list = db.SanPhams.ToList();
                List<SanPhamEntity> result = new List<SanPhamEntity>();
                foreach (var i in list)
                {
                    SanPhamEntity item = new SanPhamEntity()
                    {
                        id = i.id,
                        tenSP = i.tenSP,
                        idLoaiSP = i.idLoaiSP,
                        giaNiemYet = i.giaNiemYet,
                        giaGiam = i.giaGiam,
                        idMauSac = i.idMauSac,
                        kichThuoc = i.kichThuoc,
                        mieuTa = i.mieuTa,
                        spDB = i.spDB,
                        spMoi = i.spMoi,
                        hinhAnh = i.hinhAnh,
                        soLuong = i.soLuong

                    };
                    result.Add(item);
                }
                return result;
            }
        }

        /// <summary>
        /// Thêm 1 Sản phẩm
        /// </summary>
        /// <param name="obj"></param>
        public void ThemSP(SanPhamEntity obj)
        {
            using (var db = new WebShopEntities())
            {
                SanPham item = new SanPham()
                {
                    id = obj.id,
                    tenSP = obj.tenSP,
                    idLoaiSP = obj.idLoaiSP,
                    giaNiemYet = obj.giaNiemYet,
                    giaGiam = obj.giaGiam,
                    idMauSac = obj.idMauSac,
                    kichThuoc = obj.kichThuoc,
                    mieuTa = obj.mieuTa,
                    spDB = obj.spDB,
                    spMoi = obj.spMoi,
                    hinhAnh = obj.hinhAnh,
                    soLuong = obj.soLuong
                };
                db.SanPhams.Add(item);
                db.SaveChanges();
            }
        }

        /// <summary>
        /// Cập Nhật thông tin sản phẩm
        /// </summary>
        /// <param name="obj"></param>
        public void SuaSP(SanPhamEntity obj)
        {
            using (var db = new WebShopEntities())
            {
                var item = db.SanPhams.Where(p => p.id == obj.id).FirstOrDefault();
                {
                    item.id = obj.id;
                    item.tenSP = obj.tenSP;
                    item.idLoaiSP = obj.idLoaiSP;
                    item.giaNiemYet = obj.giaNiemYet;
                    item.giaGiam = obj.giaGiam;
                    item.idMauSac = obj.idMauSac;
                    item.kichThuoc = obj.kichThuoc;
                    item.mieuTa = obj.mieuTa;
                    item.spDB = obj.spDB;
                    item.spMoi = obj.spMoi;
                    item.hinhAnh = obj.hinhAnh;
                    item.soLuong = obj.soLuong;
                }
                db.SaveChanges();
            }
        }

        /// <summary>
        /// Đếm số lượng sản phẩm
        /// </summary>
        /// <returns></returns>
        public int SoLuongSP()
        {
            using (var db = new WebShopEntities())
            {
                return db.SanPhams.Count();
            }
        }

        /// <summary>
        /// Lấy Thông tin 1 sản phẩm
        /// </summary>
        /// <param name="idSanPham"></param>
        /// <returns></returns>
        public SanPhamEntity LayMotSP(int idSanPham)
        {
            using (var db = new WebShopEntities())
            {
                var i = db.SanPhams.Where(p => p.id == idSanPham).FirstOrDefault();
                SanPhamEntity item = new SanPhamEntity()
                {
                    id = i.id,
                    tenSP = i.tenSP,
                    idLoaiSP = i.idLoaiSP,
                    giaNiemYet = i.giaNiemYet,
                    giaGiam = i.giaGiam,
                    idMauSac = i.idMauSac,
                    kichThuoc = i.kichThuoc,
                    mieuTa = i.mieuTa,
                    spDB = i.spDB,
                    spMoi = i.spMoi,
                    hinhAnh = i.hinhAnh,
                    soLuong = i.soLuong
                };
                return item;
            }
        }


        public string LayTenSP(int idSP)
        {
            using (var db = new WebShopEntities())
            {
                return db.SanPhams.Where(p => p.id == idSP).FirstOrDefault().tenSP;
            }
        }
        public decimal LayGiaSP(int idSP)
        {
            using (var db = new WebShopEntities())
            {
                return db.SanPhams.Where(p => p.id == idSP).FirstOrDefault().giaNiemYet;
            }
        }
        
        /// <summary>
        /// Lấy số lượng sản phẩm theo id
        /// </summary>
        /// <param name="idSP"></param>
        /// <returns></returns>
        public int SoLuongDVSP(int idSP)
        {
            using (var db = new WebShopEntities())
            {
                return db.SanPhams.Where(p => p.id == idSP).FirstOrDefault().soLuong;
            }
        }

        public double LayGiaGiam(int idSP)
        {
            using (var db = new WebShopEntities())
            {
                var giamgia = db.SanPhams.Where(p => p.id == idSP).FirstOrDefault().giaGiam;
                if (giamgia == null)
                {
                    return 0.0;
                }
                return double.Parse(giamgia.ToString());
            }
        }

        /// <summary>
        /// Cập nhật lại số lượng sản phẩm trong kho
        /// </summary>
        /// <param name="idSP"></param>
        /// <param name="sl"></param>
        public void CapNhatSoLuong(int idSP, int sl)
        {
            using (var db = new WebShopEntities())
            {
                SanPham item = db.SanPhams.Where(p => p.id == idSP).FirstOrDefault();
                item.soLuong += sl;

                db.SaveChanges();
            }
        }

        /// <summary>
        /// Lấy DS sản phẩm theo loại Sản phẩm
        /// </summary>
        /// <param name="idLoaiSP"></param>
        /// <returns></returns>
        public List<SanPhamEntity> LayDSSP_TheoLoai(int idLoaiSP)
        {
            using (var db = new WebShopEntities())
            {
                var list = db.SanPhams.Where(p => p.idLoaiSP == idLoaiSP).ToList();
                List<SanPhamEntity> result = new List<SanPhamEntity>();
                foreach (var i in list)
                {
                    SanPhamEntity item = new SanPhamEntity()
                    {
                        id = i.id,
                        tenSP = i.tenSP,
                        idLoaiSP = i.idLoaiSP,
                        giaNiemYet = i.giaNiemYet,
                        giaGiam = i.giaGiam,
                        idMauSac = i.idMauSac,
                        kichThuoc = i.kichThuoc,
                        mieuTa = i.mieuTa,
                        spDB = i.spDB,
                        spMoi = i.spMoi,
                        hinhAnh = i.hinhAnh,
                        soLuong = i.soLuong
                    };
                    result.Add(item);
                }
                return result;
            }
        }

        // DS Sản phẩm mới
        public List<SanPhamEntity> LayDS_Moi()
        {
            using (var db = new WebShopEntities())
            {
                var list = db.SanPhams.Where(p => p.spMoi == true).ToList();
                List<SanPhamEntity> result = new List<SanPhamEntity>();
                foreach (var i in list)
                {
                    SanPhamEntity item = new SanPhamEntity()
                    {
                        id = i.id,
                        tenSP = i.tenSP,
                        idLoaiSP = i.idLoaiSP,
                        giaNiemYet = i.giaNiemYet,
                        giaGiam = i.giaGiam,
                        idMauSac = i.idMauSac,
                        kichThuoc = i.kichThuoc,
                        mieuTa = i.mieuTa,
                        spDB = i.spDB,
                        spMoi = i.spMoi,
                        hinhAnh = i.hinhAnh,
                        soLuong = i.soLuong
                    };
                    result.Add(item);
                }
                return result;
            }
        }

        // Lấy 2 Sản phẩm giảm giá ngẫu nhiên
        public List<SanPhamEntity> LayDS_GiamGia()
        {
            using (var db = new WebShopEntities())
            {
                var list = db.SanPhams.Where(p => p.giaGiam > 0).OrderBy(p => Guid.NewGuid()).Take(2).ToList();
                List<SanPhamEntity> result = new List<SanPhamEntity>();
                foreach (var i in list)
                {
                    SanPhamEntity item = new SanPhamEntity()
                    {
                        id = i.id,
                        tenSP = i.tenSP,
                        idLoaiSP = i.idLoaiSP,
                        giaNiemYet = i.giaNiemYet,
                        giaGiam = i.giaGiam,
                        idMauSac = i.idMauSac,
                        kichThuoc = i.kichThuoc,
                        mieuTa = i.mieuTa,
                        spDB = i.spDB,
                        spMoi = i.spMoi,
                        hinhAnh = i.hinhAnh,
                        soLuong = i.soLuong
                    };
                    result.Add(item);
                }
                return result;
            }
        }

        // Lấy 3 Sản phẩm đặt Biệt ngẫu nhiên
        public List<SanPhamEntity> LayDS_DatBiet()
        {
            using (var db = new WebShopEntities())
            {
                var list = db.SanPhams.Where(p => p.spDB == true).OrderBy(p => Guid.NewGuid()).Take(3).ToList();
                List<SanPhamEntity> result = new List<SanPhamEntity>();
                foreach (var i in list)
                {
                    SanPhamEntity item = new SanPhamEntity()
                    {
                        id = i.id,
                        tenSP = i.tenSP,
                        idLoaiSP = i.idLoaiSP,
                        giaNiemYet = i.giaNiemYet,
                        giaGiam = i.giaGiam,
                        idMauSac = i.idMauSac,
                        kichThuoc = i.kichThuoc,
                        mieuTa = i.mieuTa,
                        spDB = i.spDB,
                        spMoi = i.spMoi,
                        hinhAnh = i.hinhAnh,
                        soLuong = i.soLuong
                    };
                    result.Add(item);
                }
                return result;
            }
        }

        /// <summary>
        /// Tìm Kiếm Sản Phẩm
        /// </summary>
        /// <param name="tenSanPham"></param>
        /// <param name="loaiSanPham"></param>
        /// <param name="giaNiemYet"></param>
        /// <param name="mauSac"></param>
        /// <param name="kichThuoc"></param>
        /// <returns></returns>
        public List<SanPhamEntity> TimKiem(string tenSanPham, int loaiSanPham, int giaNiemYet, int mauSac, int kichThuoc)
        {
            List<SanPhamEntity> list = LayDSSP();

            if(tenSanPham != "")
            {
                List<SanPhamEntity> ls = new List<SanPhamEntity>();
                foreach(var i in list)
                {
                    if(i.tenSP == tenSanPham)
                    {
                        ls.Add(i);
                    }
                }
                list = ls;
            }
            if(loaiSanPham != -1)
            {
                List<SanPhamEntity> ls = new List<SanPhamEntity>();
                foreach (var i in list)
                {
                    if (i.idLoaiSP == loaiSanPham)
                    {
                        ls.Add(i);
                    }
                }
                list = ls;
            }
            if (giaNiemYet != -1)
            {
                List<SanPhamEntity> ls = new List<SanPhamEntity>();
                switch(giaNiemYet)
                {
                    case 0:
                        {
                            foreach (var i in list)
                            {
                                if (i.giaNiemYet <= 100000)
                                {
                                    ls.Add(i);
                                }
                            }
                            break;
                        }
                    case 1:
                        {
                            foreach (var i in list)
                            {
                                if ( 100000 <= i.giaNiemYet && i.giaNiemYet <= 200000)
                                {
                                    ls.Add(i);
                                }
                            }
                            break;
                        }
                    case 2:
                        {
                            foreach (var i in list)
                            {
                                if (200000 <= i.giaNiemYet && i.giaNiemYet <= 300000)
                                {
                                    ls.Add(i);
                                }
                            }
                            break;
                        }
                    case 3:
                        {
                            foreach (var i in list)
                            {
                                if (300000 <= i.giaNiemYet && i.giaNiemYet <= 400000)
                                {
                                    ls.Add(i);
                                }
                            }
                            break;
                        }
                    case 4:
                        {
                            foreach (var i in list)
                            {
                                if (400000 <= i.giaNiemYet && i.giaNiemYet <= 500000)
                                {
                                    ls.Add(i);
                                }
                            }
                            break;
                        }
                    case 5:
                        {
                            foreach (var i in list)
                            {
                                if (500000 < i.giaNiemYet)
                                {
                                    ls.Add(i);
                                }
                            }
                            break;
                        }
                    default:
                        {
                            break;
                        }
                }
                list = ls;
            }
            if (mauSac != -1)
            {
                List<SanPhamEntity> ls = new List<SanPhamEntity>();
                foreach (var i in list)
                {
                    if (i.idMauSac == mauSac)
                    {
                        ls.Add(i);
                    }
                }
                list = ls;
            }
            if (kichThuoc != -1)
            {
                List<SanPhamEntity> ls = new List<SanPhamEntity>();
                foreach (var i in list)
                {
                    if (i.kichThuoc == kichThuoc)
                    {
                        ls.Add(i);
                    }
                }
                list = ls;
            }


            return list;
        }

        /// <summary>
        /// Lấy Danh Sách Sản Phẩm Liên Quan (3)
        /// </summary>
        /// <param name="idLoaiSP"></param>
        /// <returns></returns>
        public List<SanPhamEntity> LayDS_LienQuan(int idLoaiSP)
        {
            using(var db = new WebShopEntities())
            {
                var list = db.SanPhams.Where(p => p.idLoaiSP == idLoaiSP).OrderBy(p => Guid.NewGuid()).Take(4).ToList();
                List<SanPhamEntity> result = new List<SanPhamEntity>();
                foreach (var i in list)
                {
                    SanPhamEntity item = new SanPhamEntity()
                    {
                        id = i.id,
                        tenSP = i.tenSP,
                        idLoaiSP = i.idLoaiSP,
                        giaNiemYet = i.giaNiemYet,
                        giaGiam = i.giaGiam,
                        idMauSac = i.idMauSac,
                        kichThuoc = i.kichThuoc,
                        mieuTa = i.mieuTa,
                        spDB = i.spDB,
                        spMoi = i.spMoi,
                        hinhAnh = i.hinhAnh,
                        soLuong = i.soLuong

                    };
                    result.Add(item);
                }
                return result;
            }
        }


        public List<SanPhamEntity> LayDSSP_TheoTen(string ten)
        {
            using(var db = new WebShopEntities())
            {
                var list = db.SanPhams.Where(p => p.tenSP.ToLower() == ten.ToLower()).ToList();
                List<SanPhamEntity> result = new List<SanPhamEntity>();
                foreach (var i in list)
                {
                    SanPhamEntity item = new SanPhamEntity()
                    {
                        id = i.id,
                        tenSP = i.tenSP,
                        idLoaiSP = i.idLoaiSP,
                        giaNiemYet = i.giaNiemYet,
                        giaGiam = i.giaGiam,
                        idMauSac = i.idMauSac,
                        kichThuoc = i.kichThuoc,
                        mieuTa = i.mieuTa,
                        spDB = i.spDB,
                        spMoi = i.spMoi,
                        hinhAnh = i.hinhAnh,
                        soLuong = i.soLuong

                    };
                    result.Add(item);
                }
                return result; 
            }
        }
    }
}
