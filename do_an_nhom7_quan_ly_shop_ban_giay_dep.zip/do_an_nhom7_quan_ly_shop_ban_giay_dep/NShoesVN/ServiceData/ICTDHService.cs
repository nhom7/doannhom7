﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace ServiceData
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "ICTHDService" in both code and config file together.
    [ServiceContract]
    public interface ICTDHService
    {
        [OperationContract]
        List<CTDHEntity> LayDSChiTiet(int idDonHang);

        [OperationContract]
        CTDHEntity LayMotCTHD(int idDonHang, int idSanPham);

        [OperationContract]
        void ThemChiTiet(CTDHEntity obj);

        [OperationContract]
        void CapNhatChiTiet(CTDHEntity obj);

        [OperationContract]
        int SoLuongSP(int idDonHang);

        [OperationContract]
        void ThemDanhSachCTDH(List<CTDHEntity> list);

        //[OperationContract]
        //void CapNhatDanhSachDH(List<CTDHEntity> oldList, List<CTDHEntity> newList);

        [OperationContract]
        void XoaCTDH(int idHD);

        [OperationContract]
        List<CTDHEntity> LayToanBoDS();

        [OperationContract]
        List<CTDHEntity> LayDSTheoNgay(DateTime tuNgay, DateTime DenNgay);
    }
}
