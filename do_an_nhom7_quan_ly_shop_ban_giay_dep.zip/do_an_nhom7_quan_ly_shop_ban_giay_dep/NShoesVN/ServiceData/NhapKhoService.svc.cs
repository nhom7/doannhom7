﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace ServiceData
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "NhapKhoService" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select NhapKhoService.svc or NhapKhoService.svc.cs at the Solution Explorer and start debugging.
    public class NhapKhoService : INhapKhoService
    {
        public List<NhapKhoEntity> LayDS_PhieuNhap()
        {
           using(var db = new WebShopEntities())
           {
               var list = db.NhapKhoes.ToList();
               List<NhapKhoEntity> result = new List<NhapKhoEntity>();
               foreach(var i in list)
               {
                   NhapKhoEntity item = new NhapKhoEntity()
                   {
                       id = i.id,
                       ngayNhapKho = i.ngayNhapKho,
                       tongTien = i.tongTien
                   };
                   result.Add(item);
               }

               return result;
           }
        }

        public void ThemPhieuNhap(NhapKhoEntity obj)
        {
            using(var db = new WebShopEntities())
            {
                NhapKho item = new NhapKho()
                {
                    id = obj.id,
                    ngayNhapKho = obj.ngayNhapKho,
                    tongTien = obj.tongTien
                };
                db.NhapKhoes.Add(item);
                db.SaveChanges();
            }
        }

        public void CapNhatPhieuNhap(NhapKhoEntity obj)
        {
            using(var db = new WebShopEntities())
            {
                NhapKho item = db.NhapKhoes.Where(p => p.id == obj.id).FirstOrDefault();
                item.ngayNhapKho = obj.ngayNhapKho;
                item.tongTien = obj.tongTien;

                db.SaveChanges();
            }
        }

        public void XoaPhieuNhap(NhapKhoEntity obj)
        {
            throw new NotImplementedException();
        }

        public int SoLuongPhieuNhap()
        {
            using(var db = new WebShopEntities())
            {
                return db.NhapKhoes.Count();
            }
        }


        public NhapKhoEntity LayMotPhieuNhap(int idPN)
        {
            using(var db = new WebShopEntities())
            {
                var item = db.NhapKhoes.Where(p => p.id == idPN).FirstOrDefault();
                NhapKhoEntity result = new NhapKhoEntity();
                result.id = item.id;
                result.ngayNhapKho = item.ngayNhapKho;
                result.tongTien = item.tongTien;

                return result;
            }
        }
    }
}
