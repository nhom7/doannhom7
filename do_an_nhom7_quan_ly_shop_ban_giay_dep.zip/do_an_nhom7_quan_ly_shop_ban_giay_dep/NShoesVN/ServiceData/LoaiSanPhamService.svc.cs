﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace ServiceData
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "LoaiSanPhamService" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select LoaiSanPhamService.svc or LoaiSanPhamService.svc.cs at the Solution Explorer and start debugging.
    public class LoaiSanPhamService : ILoaiSanPhamService
    {
        /// <summary>
        /// Lấy DS Tên loại sản phẩm
        /// </summary>
        /// <returns></returns>
        public List<string> DSTenLoaiSP()
        {
            List<LoaiSanPhamEntity> list = LayDSLoaiSP();
            List<string> result = new List<string>();
            foreach (var i in list)
            {
                string item = i.tenLoaiSP;
                result.Add(item);
            }

            return result;
        }

        /// <summary>
        /// Lấy DS Loại sản phẩm
        /// </summary>
        /// <returns></returns>
        public List<LoaiSanPhamEntity> LayDSLoaiSP()
        {
            using (var db = new WebShopEntities())
            {
                var list = db.LoaiSanPhams.ToList();
                List<LoaiSanPhamEntity> result = new List<LoaiSanPhamEntity>();
                foreach (var i in list)
                {
                    LoaiSanPhamEntity item = new LoaiSanPhamEntity()
                    {
                        id = i.id,
                        mieuTa = i.mieuTa,
                        tenLoaiSP = i.tenLoaiSP
                    };
                    result.Add(item);
                }

                return result;
            }
        }

        /// <summary>
        /// Thêm Mới Loại Sản phẩm
        /// </summary>
        /// <param name="obj"></param>
        public void ThemLoaiSP(LoaiSanPhamEntity obj)
        {
            using (var db = new WebShopEntities())
            {
                LoaiSanPham item = new LoaiSanPham()
                {
                    id = obj.id,
                    tenLoaiSP = obj.tenLoaiSP,
                    mieuTa = obj.mieuTa
                };
                db.LoaiSanPhams.Add(item);
                db.SaveChanges();
            }
        }

        /// <summary>
        /// Đếm số loại sản phẩm
        /// </summary>
        /// <returns></returns>
        public int SoLuong()
        {
            using (var db = new WebShopEntities())
            {
                return db.LoaiSanPhams.Count();
            }
        }

        /// <summary>
        /// Cập Nhật thông tin loại sản phẩm
        /// </summary>
        /// <param name="obj"></param>
        public void CapNhatLoaiSP(LoaiSanPhamEntity obj)
        {
            using (var db = new WebShopEntities())
            {
                LoaiSanPham item = db.LoaiSanPhams.Where(p => p.id == obj.id).FirstOrDefault();
                item.tenLoaiSP = obj.tenLoaiSP;
                item.mieuTa = obj.mieuTa;

                db.SaveChanges();
            }
        }

        /// <summary>
        /// Lấy dữ liệu về 1 loại sản phẩm nhất định
        /// </summary>
        /// <param name="idLoaiSP"></param>
        /// <returns></returns>
        public LoaiSanPhamEntity LayMotLoaiSP(int idLoaiSP)
        {
            using (var db = new WebShopEntities())
            {
                var item = db.LoaiSanPhams.Where(p => p.id == idLoaiSP).FirstOrDefault();
                LoaiSanPhamEntity result = new LoaiSanPhamEntity()
                {
                    id = item.id,
                    tenLoaiSP = item.tenLoaiSP,
                    mieuTa = item.mieuTa
                };
                return result;
            }
        }

        /// <summary>
        /// Tìm Kiếm Sản Phẩm theo Tên
        /// </summary>
        /// <param name="tenLoaiSP"></param>
        /// <returns></returns>
        public List<LoaiSanPhamEntity> TimKiem(string tenLoaiSP)
        {
            List<LoaiSanPhamEntity> list = LayDSLoaiSP();
            List<LoaiSanPhamEntity> result = new List<LoaiSanPhamEntity>();
            foreach(var i in list)
            {
                if(i.tenLoaiSP.Trim().ToLower() == tenLoaiSP.Trim().ToLower())
                {
                    result.Add(i);
                }
            }
            return result;
        }
    }
}
