﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace ServiceData
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IKhachHangService" in both code and config file together.
    [ServiceContract]
    public interface IKhachHangService
    {
        [OperationContract]
        List<KhachHangEntity> LayDSKhachHang();

        [OperationContract]
        KhachHangEntity LayMotKhachHang(int idKhachHang);

        [OperationContract]
        KhachHangEntity LayMotDTKhachHang(string tenDN, string matkhau);

        [OperationContract]
        void ThemKhachHang(KhachHangEntity obj);

        [OperationContract]
        void CapNhatKhachHang(KhachHangEntity obj);

        [OperationContract]
        int SoLuongKH();

        [OperationContract]
        List<KhachHangEntity> TimKhachHang(string ten, string sdt, string email);

        [OperationContract]
        string LayTenKH(int idKhachHang);

        [OperationContract]
        bool KiemTraDN(string tenDN, string matkhau);

        [OperationContract]
        bool KiemTraTenDNHopLe(string tenDN);
    }
}
