﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace ServiceData
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "DonHangService" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select DonHangService.svc or DonHangService.svc.cs at the Solution Explorer and start debugging.
    public class DonHangService : IDonHangService
    {
        private KhachHangService khachHangSer = new KhachHangService();
        public List<DonHangEntity> LayDS_DonHang()
        {
            using (var db = new WebShopEntities())
            {
                var list = db.DonHangs.ToList();
                List<DonHangEntity> result = new List<DonHangEntity>();
                foreach (var i in list)
                {
                    DonHangEntity item = new DonHangEntity()
                    {
                        id = i.id,
                        idKhachHang = i.idKhachHang,
                        ngayDH = i.ngayDH,
                        thanhTien = i.thanhTien,
                        idTrangThai = i.idTrangThai,
                        tenKH = khachHangSer.LayTenKH(i.idKhachHang)
                    };
                    result.Add(item);
                }

                return result;
            }
        }

        public void ThemDonHang(DonHangEntity obj)
        {
            using (var db = new WebShopEntities())
            {
                DonHang item = new DonHang()
                {
                    id = obj.id,
                    idKhachHang = obj.idKhachHang,
                    ngayDH = obj.ngayDH,
                    thanhTien = obj.thanhTien,
                    idTrangThai = obj.idTrangThai
                };
                db.DonHangs.Add(item);
                db.SaveChanges();
            }
        }

        public void CapNhatDonHang(DonHangEntity obj)
        {
            using (var db = new WebShopEntities())
            {
                DonHang item = db.DonHangs.Where(p => p.id == obj.id).FirstOrDefault();
                {
                    item.idKhachHang = obj.idKhachHang;
                    item.ngayDH = obj.ngayDH;
                    item.thanhTien = obj.thanhTien;
                    item.idTrangThai = obj.idTrangThai;
                }
                db.SaveChanges();
            }
        }

        public int SoLuong()
        {
            using (var db = new WebShopEntities())
            {
                return db.DonHangs.Count();
            }
        }

        public DonHangEntity LayMotDonHang(int idDH)
        {
            using (var db = new WebShopEntities())
            {
                DonHang item = db.DonHangs.Where(p => p.id == idDH).FirstOrDefault();
                DonHangEntity result = new DonHangEntity()
                {
                    id = item.id,
                    idKhachHang = item.idKhachHang,
                    ngayDH = item.ngayDH,
                    thanhTien = item.thanhTien,
                    idTrangThai = item.idTrangThai,
                    tenKH = khachHangSer.LayTenKH(item.idKhachHang)
                };

                return result;
            }
        }


        public List<DonHangEntity> LayDSDH_Ngay(DateTime tuNgay, DateTime denNgay)
        {
            using(var db = new WebShopEntities())
            {
                var list = db.DonHangs.Where(p => p.ngayDH <= denNgay && tuNgay <= p.ngayDH).ToList();
                List<DonHangEntity> result = new List<DonHangEntity>();
                foreach (var i in list)
                {
                    DonHangEntity item = new DonHangEntity()
                    {
                        id = i.id,
                        idKhachHang = i.idKhachHang,
                        ngayDH = i.ngayDH,
                        thanhTien = i.thanhTien,
                        idTrangThai = i.idTrangThai,
                        tenKH = khachHangSer.LayTenKH(i.idKhachHang)
                    };
                    result.Add(item);
                }

                return result;
            }
        }
    }
}
