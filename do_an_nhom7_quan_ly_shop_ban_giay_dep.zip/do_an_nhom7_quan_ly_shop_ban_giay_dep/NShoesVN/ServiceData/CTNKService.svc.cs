﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace ServiceData
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "CTNKService" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select CTNKService.svc or CTNKService.svc.cs at the Solution Explorer and start debugging.
    public class CTNKService : ICTNKService
    {
        private SanPhamService sanPhamSer = new SanPhamService();
        public List<CTNKEntity> LayDS_NK(int idNK)
        {
            using(var db = new WebShopEntities())
            {
                var list = db.CTNKs.Where(p => p.idNK == idNK).ToList();
                List<CTNKEntity> result = new List<CTNKEntity>();
                foreach(var i in list)
                {
                    CTNKEntity item = new CTNKEntity()
                    {
                        idNK = i.idNK,
                        giaNhap = i.giaNhap,
                        idMucLoi = i.idMucLoi,
                        idSP = i.idSP,
                        soLuong = i.soLuong,
                        tenSP = sanPhamSer.LayTenSP(i.idSP)
                    };
                    result.Add(item);
                }

                return result;
            }
        }

        public void ThemCTNK(CTNKEntity obj)
        {
            using(var db = new WebShopEntities())
            {
                CTNK item = new CTNK()
                {
                    idNK = obj.idNK,
                    idSP = obj.idSP,
                    idMucLoi = obj.idMucLoi,
                    giaNhap = obj.giaNhap,
                    soLuong = obj.soLuong
                };
                db.CTNKs.Add(item);
                db.SaveChanges();
            }

            sanPhamSer.CapNhatSoLuong(obj.idSP, obj.soLuong);
        }

        public void CapNhatCTNK(CTNKEntity obj)
        {
            using(var db = new WebShopEntities())
            {
                CTNK item = db.CTNKs.Where(p => p.idNK == obj.idNK && p.idSP == obj.idSP).FirstOrDefault();
                item.giaNhap = obj.giaNhap;
                item.idMucLoi = obj.idMucLoi;
                item.soLuong = obj.soLuong;

                db.SaveChanges();
            }
        }
    }
}
