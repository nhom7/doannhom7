﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace ServiceData
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "ISanPhamService" in both code and config file together.
    [ServiceContract]
    public interface ISanPhamService
    {
        [OperationContract]
        List<SanPhamEntity> LayDSSP();

        [OperationContract]
        List<SanPhamEntity> LayDSSP_TheoLoai(int idLoaiSP);

        [OperationContract]
        List<SanPhamEntity> LayDSSP_TheoTen(string ten);

        [OperationContract]
        void ThemSP(SanPhamEntity obj);

        [OperationContract]
        void SuaSP(SanPhamEntity obj);

        /// <summary>
        /// Số Sản Phẩm Trong Danh Sách. 
        /// </summary>
        /// <returns></returns>
        [OperationContract]
        int SoLuongSP();

        /// <summary>
        /// Số Lượng Đơn Vị Của SP
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [OperationContract]
        int SoLuongDVSP(int idSP);

        [OperationContract]
        SanPhamEntity LayMotSP(int id);

        [OperationContract]
        string LayTenSP(int idSP);

        [OperationContract]
        decimal LayGiaSP(int idSP);

        [OperationContract]
        double LayGiaGiam(int idSP);

        [OperationContract]
        void CapNhatSoLuong(int idSP, int sl);

        [OperationContract]
        List<SanPhamEntity> LayDS_Moi();

        [OperationContract]
        List<SanPhamEntity> LayDS_GiamGia();

        [OperationContract]
        List<SanPhamEntity> LayDS_DatBiet();

        [OperationContract]
        List<SanPhamEntity> LayDS_LienQuan(int idLoaiSP);

        [OperationContract]
        List<SanPhamEntity> TimKiem(string tenSanPham, int loaiSanPham, int giaNiemYet, int mauSac, int kichThuoc);

    }
}
