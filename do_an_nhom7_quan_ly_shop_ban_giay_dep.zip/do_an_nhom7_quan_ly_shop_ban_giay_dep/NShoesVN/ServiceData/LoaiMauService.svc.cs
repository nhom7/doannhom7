﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace ServiceData
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "LoaiMauService" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select LoaiMauService.svc or LoaiMauService.svc.cs at the Solution Explorer and start debugging.
    public class LoaiMauService : ILoaiMauService
    {
        public List<MauSacEntity> LayDS_MauSac()
        {
            using (var db = new WebShopEntities())
            {
                var list = db.MauSacs.ToList();
                List<MauSacEntity> result = new List<MauSacEntity>();
                foreach (var i in list)
                {
                    MauSacEntity item = new MauSacEntity()
                    {
                        id = i.id,
                        tenMauSac = i.tenMauSac
                    };
                    result.Add(item);
                }
                return result;
            }
        }

        public string LayTenMau(int idMauSac)
        {
            using (var db = new WebShopEntities())
            {
                return db.MauSacs.Where(p => p.id == idMauSac).FirstOrDefault().tenMauSac;
            }
        }
    }
}
