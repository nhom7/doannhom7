﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace ServiceData
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "INhapKhoService" in both code and config file together.
    [ServiceContract]
    public interface INhapKhoService
    {
        [OperationContract]
        List<NhapKhoEntity> LayDS_PhieuNhap();

        [OperationContract]
        void ThemPhieuNhap(NhapKhoEntity obj);

        [OperationContract]
        void CapNhatPhieuNhap(NhapKhoEntity obj);

        [OperationContract]
        void XoaPhieuNhap(NhapKhoEntity obj);

        [OperationContract]
        int SoLuongPhieuNhap();

        [OperationContract]
        NhapKhoEntity LayMotPhieuNhap(int idPN);
    }
}
