﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace ServiceData
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IDonHangService" in both code and config file together.
    [ServiceContract]
    public interface IDonHangService
    {
        [OperationContract]
        List<DonHangEntity> LayDS_DonHang();

        [OperationContract]
        void ThemDonHang(DonHangEntity obj);

        [OperationContract]
        void CapNhatDonHang(DonHangEntity obj);

        [OperationContract]
        int SoLuong();

        [OperationContract]
        DonHangEntity LayMotDonHang(int idDH);

        [OperationContract]
        List<DonHangEntity> LayDSDH_Ngay(DateTime tuNgay, DateTime denNgay);
    }
}
