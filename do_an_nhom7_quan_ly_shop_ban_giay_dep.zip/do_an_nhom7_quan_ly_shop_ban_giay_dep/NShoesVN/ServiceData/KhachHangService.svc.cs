﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace ServiceData
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "KhachHangService" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select KhachHangService.svc or KhachHangService.svc.cs at the Solution Explorer and start debugging.
    public class KhachHangService : IKhachHangService
    {
        /// <summary>
        /// Lấy Toàn bộ danh sách khách hàng
        /// </summary>
        /// <returns></returns>
        public List<KhachHangEntity> LayDSKhachHang()
        {
            using (var db = new WebShopEntities())
            {
                var list = db.KhachHangs.ToList();
                List<KhachHangEntity> result = new List<KhachHangEntity>();
                foreach (var i in list)
                {
                    KhachHangEntity item = new KhachHangEntity()
                    {
                        id = i.id,
                        tenKH = i.tenKH,
                        sdt = i.sdt,
                        email = i.email,
                        diaChi = i.diaChi,
                        tenDN = i.tenDN,
                        matKhau = i.matKhau
                    };
                    result.Add(item);
                }

                return result;
            }
        }

        /// <summary>
        /// Lấy Thông tin về 1 khách hàng
        /// </summary>
        /// <param name="idKhachHang"></param>
        /// <returns></returns>
        public KhachHangEntity LayMotKhachHang(int idKhachHang)
        {
            using (var db = new WebShopEntities())
            {
                var item = db.KhachHangs.Where(p => p.id == idKhachHang).FirstOrDefault();
                KhachHangEntity obj = new KhachHangEntity()
                {
                    id = item.id,
                    tenKH = item.tenKH,
                    sdt = item.sdt,
                    email = item.email,
                    diaChi = item.diaChi,
                    tenDN = item.tenDN,
                    matKhau = item.matKhau
                };

                return obj;
            }
        }

        /// <summary>
        /// Thêm mới Một Khách Hàng vào CSDL
        /// </summary>
        /// <param name="obj"></param>
        public void ThemKhachHang(KhachHangEntity obj)
        {
            using (var db = new WebShopEntities())
            {
                KhachHang item = new KhachHang()
                {
                    id = obj.id,
                    tenKH = obj.tenKH,
                    sdt = obj.sdt,
                    email = obj.email,
                    diaChi = obj.diaChi,
                    tenDN = obj.tenDN,
                    matKhau = obj.matKhau
                };
                db.KhachHangs.Add(item);
                db.SaveChanges();
            }
        }

        /// <summary>
        /// Cập nhật thông tin khách hàng vào CSDL
        /// </summary>
        /// <param name="obj"></param>
        public void CapNhatKhachHang(KhachHangEntity obj)
        {
            using (var db = new WebShopEntities())
            {
                KhachHang item = db.KhachHangs.Where(p => p.id == obj.id).FirstOrDefault();
                {
                    item.tenKH = obj.tenKH;
                    item.sdt = obj.sdt;
                    item.email = obj.email;
                    item.diaChi = obj.diaChi;
                    item.tenDN = obj.tenDN;
                    item.matKhau = obj.matKhau;
                }
                db.SaveChanges();
            }
        }

        /// <summary>
        /// Đếm Số Lượng Khách Hàng trong CSDL
        /// </summary>
        /// <returns></returns>
        public int SoLuongKH()
        {
            using (var db = new WebShopEntities())
            {
                return db.KhachHangs.Count();
            }
        }

        /// <summary>
        /// Tìm Khách Hàng
        /// </summary>
        /// <param name="ten"></param>
        /// <param name="sdt"></param>
        /// <param name="email"></param>
        /// <returns></returns>
        public List<KhachHangEntity> TimKhachHang(string ten, string sdt, string email)
        {
            using (var db = new WebShopEntities())
            {
                List<KhachHangEntity> list = LayDSKhachHang().ToList();

                List<KhachHangEntity> result = new List<KhachHangEntity>();
                if (ten != "")
                {
                    foreach (var i in list)
                    {
                        if (i.tenKH == ten)
                        {
                            result.Add(i);
                        }
                    }
                    list = result;
                }
                if (sdt != "")
                {
                    result.Clear();
                    foreach (var i in list)
                    {
                        if (i.sdt == sdt)
                        {
                            result.Add(i);
                        }
                    }
                    list = result;
                }
                if (email != "")
                {
                    result.Clear();
                    foreach (var i in list)
                    {
                        if (i.email == email)
                        {
                            result.Add(i);
                        }
                    }
                    list = result;
                }

                return result;
            }
        }

        /// <summary>
        /// Lấy Tên Khách Hàng (Theo Mã)
        /// </summary>
        /// <param name="idKhachHang"></param>
        /// <returns></returns>
        public string LayTenKH(int idKhachHang)
        {
            using (var db = new WebShopEntities())
            {
                return db.KhachHangs.Where(p => p.id == idKhachHang).FirstOrDefault().tenKH;
            }
        }


        public bool KiemTraDN(string tenDN, string matkhau)
        {
            using(var db = new WebShopEntities())
            {
                var kh = db.KhachHangs.Where(p => p.tenDN == tenDN && p.matKhau == matkhau).FirstOrDefault();
                if(kh == null)
                {
                    return false;
                }
                return true;
            }
        }


        public bool KiemTraTenDNHopLe(string tenDN)
        {
            using(var db = new WebShopEntities())
            {
                var kh = db.KhachHangs.Where(p => p.tenDN == tenDN).FirstOrDefault();
                if(kh == null)
                {
                    return true;
                }
                return false;
            }
        }


        public KhachHangEntity LayMotDTKhachHang(string tenDN, string matkhau)
        {
            using(var db = new WebShopEntities())
            {
                var item =  db.KhachHangs.Where(p => p.tenDN == tenDN && p.matKhau == matkhau).FirstOrDefault();
                KhachHangEntity obj = new KhachHangEntity()
                {
                    id = item.id,
                    tenKH = item.tenKH,
                    sdt = item.sdt,
                    email = item.email,
                    diaChi = item.diaChi,
                    tenDN = item.tenDN,
                    matKhau = item.matKhau
                };

                return obj;
            }
        }
    }
}
