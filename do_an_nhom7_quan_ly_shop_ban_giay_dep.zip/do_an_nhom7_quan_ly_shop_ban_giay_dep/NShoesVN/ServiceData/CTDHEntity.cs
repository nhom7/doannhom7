﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Web;

namespace ServiceData
{
    [DataContract]
    public class CTDHEntity :CTDH
    {
        [DataMember]
        public string tenSanPham { get; set; }

        [DataMember]
        public decimal giaNiemYet { get; set; }

        [DataMember]
        public double giaGiam { get; set; }
    }
}