﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace ServiceData
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "MucLoiService" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select MucLoiService.svc or MucLoiService.svc.cs at the Solution Explorer and start debugging.
    public class MucLoiService : IMucLoiService
    {

        public double LayGiaTri(int id)
        {
            using(var db = new WebShopEntities())
            {
                return db.MucLois.Where(p => p.id == id).FirstOrDefault().tiLe;
            }
        }
    }
}
