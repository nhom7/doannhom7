﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace ServiceData
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "ILoaiSanPhamService" in both code and config file together.
    [ServiceContract]
    public interface ILoaiSanPhamService
    {
        [OperationContract]
        List<string> DSTenLoaiSP();

        [OperationContract]
        List<LoaiSanPhamEntity> LayDSLoaiSP();

        [OperationContract]
        LoaiSanPhamEntity LayMotLoaiSP(int idLoaiSP);

        [OperationContract]
        void ThemLoaiSP(LoaiSanPhamEntity obj);

        [OperationContract]
        int SoLuong();

        [OperationContract]
        void CapNhatLoaiSP(LoaiSanPhamEntity obj);

        [OperationContract]
        List<LoaiSanPhamEntity> TimKiem(string tenLoaiSP);
    }
}
