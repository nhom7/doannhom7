﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace ServiceData
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "CTHDService" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select CTHDService.svc or CTHDService.svc.cs at the Solution Explorer and start debugging.
    public class CTHDService : ICTDHService
    {
        private SanPhamService sanPhamSer = new SanPhamService();
        private DonHangService donHangSer = new DonHangService();
        public List<CTDHEntity> LayDSChiTiet(int idDonHang)
        {
            using (var db = new WebShopEntities())
            {
                var list = db.CTDHs.Where(p => p.idDH == idDonHang).ToList();
                List<CTDHEntity> result = new List<CTDHEntity>();
                foreach (var i in list)
                {
                    CTDHEntity item = new CTDHEntity()
                    {
                        idDH = i.idDH,
                        idSP = i.idSP,
                        soLuong = i.soLuong,
                        tenSanPham = sanPhamSer.LayTenSP(i.idSP),
                        giaGiam = sanPhamSer.LayGiaGiam(i.idSP),
                        giaNiemYet = sanPhamSer.LayGiaSP(i.idSP)
                    };
                    result.Add(item);
                }

                return result;
            }
        }

        public void ThemChiTiet(CTDHEntity obj)
        {
            using (var db = new WebShopEntities())
            {
                CTDH item = new CTDH()
                {
                    idDH = obj.idDH,
                    idSP = obj.idSP,
                    soLuong = obj.soLuong
                };
                db.CTDHs.Add(item);
                db.SaveChanges();
            }

            sanPhamSer.CapNhatSoLuong(obj.idSP, -obj.soLuong);
        }

        public void CapNhatChiTiet(CTDHEntity obj)
        {
            using (var db = new WebShopEntities())
            {
                CTDH item = db.CTDHs.Where(p => p.idDH == obj.idDH && p.idSP == obj.idSP).FirstOrDefault();
                {
                    if (item != null)
                    {
                        int bien = item.soLuong - obj.soLuong;
                        sanPhamSer.CapNhatSoLuong(item.idSP, bien);
                        item.soLuong = obj.soLuong;
                    }

                }
                db.SaveChanges();
            }


        }

        public int SoLuongSP(int idDonHang)
        {
            using (var db = new WebShopEntities())
            {
                return db.CTDHs.Where(p => p.idDH == idDonHang).Count();
            }
        }


        public void ThemDanhSachCTDH(List<CTDHEntity> list)
        {
            foreach (var i in list)
            {
                ThemChiTiet(i);
            }
        }


        public CTDHEntity LayMotCTHD(int idDonHang, int idSanPham)
        {
            List<CTDHEntity> list = LayDSChiTiet(idDonHang);
            foreach (var i in list)
            {
                if (i.idSP == idSanPham)
                {
                    return i;
                }
            }
            return null;
        }


        public void XoaCTDH(int idHD)
        {
            using(var db = new WebShopEntities())
            {
                var list = db.CTDHs.Where(p => p.idDH == idHD).ToList();
                foreach(var i in list)
                {
                    sanPhamSer.CapNhatSoLuong(i.idSP, i.soLuong);
                    db.CTDHs.Remove(i);
                }
                db.SaveChanges();
            }
        }

        public List<CTDHEntity> LayToanBoDS()
        {
            using(var db = new WebShopEntities())
            {
                var list = db.CTDHs.ToList();
                List<CTDHEntity> result = new List<CTDHEntity>();
                foreach (var i in list)
                {
                    CTDHEntity item = new CTDHEntity()
                    {
                        idDH = i.idDH,
                        idSP = i.idSP,
                        soLuong = i.soLuong,
                        tenSanPham = sanPhamSer.LayTenSP(i.idSP),
                        giaGiam = sanPhamSer.LayGiaGiam(i.idSP),
                        giaNiemYet = sanPhamSer.LayGiaSP(i.idSP)
                    };
                    result.Add(item);
                }

                return result;
            }
        }


        public List<CTDHEntity> LayDSTheoNgay(DateTime tuNgay, DateTime denNgay)
        {
            var listDH = donHangSer.LayDSDH_Ngay(tuNgay, denNgay).ToList();
            var listCTDH = LayToanBoDS();
            List<CTDHEntity> result = new List<CTDHEntity>();
            foreach(var i in listDH)
            {
                foreach(var j in listCTDH)
                {
                    if(i.id == j.idDH)
                    {
                        result.Add(j);
                    }
                }
            }
            return result;
        }
    }
}
